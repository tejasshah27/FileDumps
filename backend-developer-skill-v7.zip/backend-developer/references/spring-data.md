# Spring Boot — Data Layer (Entities, Repositories, JPA, Queries)

## Entity design

```java
@Entity
@Table(name = "orders",
    indexes = { @Index(name = "idx_orders_customer", columnList = "customer_id, status") })
class Order {

    @Id @GeneratedValue(strategy = GenerationType.UUID)
    private UUID id;

    @Column(nullable = false)
    private String customerId;

    @Column(nullable = false)
    @Enumerated(EnumType.STRING)    // always STRING — ordinal breaks on reordering
    private OrderStatus status;

    @Column(nullable = false, updatable = false)
    private Instant createdAt = Instant.now();

    Order() {}   // JPA requires no-arg constructor; package-private hides it from app code

    Order(String customerId, long amountCents) {
        this.customerId  = Objects.requireNonNull(customerId);
        this.amountCents = amountCents;
        this.status      = OrderStatus.PENDING;
    }

    // State transitions as methods — not setters; enforce business rules
    void confirm() {
        if (status != OrderStatus.PENDING)
            throw new IllegalStateException("Only PENDING orders can be confirmed, was: " + status);
        this.status    = OrderStatus.CONFIRMED;
        this.updatedAt = Instant.now();
    }

    void cancel() {
        if (status == OrderStatus.SHIPPED || status == OrderStatus.DELIVERED)
            throw new IllegalStateException("Cannot cancel after shipment");
        this.status = OrderStatus.CANCELLED;
    }
}
```

---

## Repository patterns

```java
interface OrderRepository extends JpaRepository<Order, UUID> {

    // Derived queries — simple; no SQL risk; readable
    Optional<Order> findByIdAndCustomerId(UUID id, String customerId);
    List<Order>     findByCustomerIdAndStatus(String customerId, OrderStatus status);
    boolean         existsByCustomerIdAndStatus(String customerId, OrderStatus status);
    long            countByCustomerId(String customerId);

    // Sort via Sort parameter — dynamic sort without Specification
    List<Order> findByCustomerId(String customerId, Sort sort);

    // Projection interface — read-only; loads only selected columns; no cache overhead
    interface OrderSummary {
        UUID    getId();
        String  getStatus();
        long    getAmountCents();
        Instant getCreatedAt();
    }
    List<OrderSummary> findSummariesByCustomerId(String customerId);

    // Complex JPQL — text block; readable multi-line query
    @Query("""
            SELECT o FROM Order o
            WHERE o.customerId = :customerId
              AND o.status IN :statuses
              AND o.createdAt >= :since
            ORDER BY o.createdAt DESC
            """)
    List<Order> findRecentByStatuses(
        @Param("customerId") String customerId,
        @Param("statuses")   Collection<OrderStatus> statuses,
        @Param("since")      Instant since);

    // EntityGraph — pre-load associations; avoids N+1; works with pagination (JOIN FETCH doesn't)
    @EntityGraph(attributePaths = {"items", "shippingAddress"})
    Optional<Order> findWithDetailsById(UUID id);

    // Native query — window functions, CTE, JSONB ops JPQL can't express
    @Query(value = """
            SELECT DATE_TRUNC('day', created_at) AS day,
                   COUNT(*)                      AS cnt,
                   SUM(amount_cents)             AS revenue
            FROM   orders
            WHERE  customer_id = :customerId
            GROUP  BY 1
            ORDER  BY 1
            """, nativeQuery = true)
    List<Object[]> dailyStats(@Param("customerId") String customerId);
}
```

---

## Full entity vs projection — choose deliberately

| Use case | Load |
|---|---|
| Mutate and save | Full entity |
| Read-only list / search / report | Projection (interface or record) |
| Need specific associations | Full entity with `@EntityGraph` |
| Complex aggregate / reporting | Native query |

**Projection is lighter:** no first-level cache entry, no dirty-check overhead, only selected columns.

```java
// Full entity — you'll mutate and save
Order order = repo.findById(id).orElseThrow(() -> new NotFoundException(id.toString()));
order.confirm();

// Projection — read-only list endpoint
List<OrderSummary> list = repo.findSummariesByCustomerId(customerId);

// Record projection via JPQL constructor expression
record OrderView(UUID id, String status, long amount) {}

@Query("SELECT new com.example.OrderView(o.id, o.status, o.amountCents) FROM Order o WHERE ...")
List<OrderView> findViews(...);
```

---

## N+1 query problem

Calling a lazy association inside a loop fires a separate SELECT per element.
```java
// BAD — 1 query for orders + N queries for items = N+1 round trips
for (Order o : orders) {
    System.out.println(o.getItems().size());   // each .getItems() triggers a SELECT
}

// FIX 1 — JOIN FETCH in query (one query)
@Query("SELECT o FROM Order o JOIN FETCH o.items WHERE o.customerId = :id")
List<Order> findWithItems(@Param("id") String id);

// FIX 2 — @EntityGraph (works with pagination; JOIN FETCH + Pageable = incorrect count)
@EntityGraph(attributePaths = {"items"})
Page<Order> findByCustomerId(String customerId, Pageable pageable);
```

Detect N+1: enable Hibernate statistics (`spring.jpa.properties.hibernate.generate_statistics=true`)
or use p6spy / datasource-proxy to log all SQL.

---

## Cascade and bulk delete

`CascadeType.REMOVE` on a large collection fires one DELETE per child — N round trips.
```java
// BAD — 10,000 children = 10,000 DELETE statements
@OneToMany(cascade = CascadeType.REMOVE)
private List<Item> items;

// GOOD — one DELETE statement
@Modifying
@Query("DELETE FROM Item i WHERE i.order.id = :orderId")
void deleteItemsByOrderId(@Param("orderId") UUID orderId);
```

---

## @Transactional — default and override pattern
```java
@Service
@Transactional(readOnly = true)    // default: all methods; skip dirty-check; enables read-replica routing
class OrderService {

    @Transactional                  // override for writes: readOnly = false
    public OrderResponse create(CreateOrderRequest req) { ... }

    @Transactional
    public OrderResponse confirm(UUID id) { ... }

    public Optional<OrderResponse> findById(UUID id) { ... }   // inherits readOnly = true
}
```

**`@Transactional` rules:**
- Must be `public` — Spring AOP proxy doesn't intercept `private` or `protected` methods
- Must be called from **outside** the bean — self-invocation bypasses proxy
- `readOnly = true` — tells Hibernate to skip dirty-check flush; signals DB driver for read replica
- `readOnly = false` (default) — enables dirty-check; use only on write methods

---

## Enum as JPA column
```java
@Enumerated(EnumType.STRING)   // always STRING
private OrderStatus status;
// EnumType.ORDINAL is dangerous — adding/reordering enum values corrupts stored data
```

---

## Gotchas

**`@Transactional` on private method** — silently not applied; no error at startup.

**`CascadeType.REMOVE` on large collections** — N DELETE statements. Use bulk JPQL delete.

**N+1 in loops** — always use `JOIN FETCH` or `@EntityGraph` when iterating and accessing associations.

**`JOIN FETCH` + `Pageable`** — Hibernate issues warning and loads all in memory, then paginates in-memory.
Fix: use `@EntityGraph` for paginated queries that need associations.

**Loading full entity for read-only endpoints** — wastes memory and dirty-check CPU.
Fix: projections for all read/list endpoints.

---

See also: `examples/springboot/OrderServiceStack.java`
