# JDK 7 — Project Coin: Small Language Fixes

**Diamond `<>`** — never repeat generic type on RHS
```java
Map<String, List<Integer>> map = new HashMap<>();
```

**try-with-resources** — any `AutoCloseable`; no finally needed
```java
try (var in = new FileInputStream(f); var out = new FileOutputStream(g)) { ... }
```

**Multi-catch** — one handler for unrelated exceptions
```java
catch (IOException | SQLException e) { throw new AppException(e); }
```

**String switch** — replaces if-else chains on strings

**Binary literals + numeric underscores** — readability for constants
```java
int mask   = 0b1111_0000;
long limit = 1_000_000_000L;
```

**`Objects` utility** — null-safe helpers
```java
Objects.requireNonNull(param, "param must not be null");
Objects.requireNonNullElse(value, fallback);    // JDK 9
Objects.toString(obj, "default");
boolean eq = Objects.equals(a, b);              // null-safe equals
int h      = Objects.hash(a, b, c);             // multi-field hashCode
Objects.checkIndex(i, list.size());             // JDK 9
```

**NIO.2** (`java.nio.file`) — replace `java.io.File` completely
```java
Path p = Path.of("dir", "file.txt");            // Path.of = JDK 11; Paths.get = JDK 7+
Files.copy(src, dst, StandardCopyOption.REPLACE_EXISTING);
Files.move(src, dst, StandardCopyOption.ATOMIC_MOVE);
Files.createDirectories(path);
Files.walk(dir).filter(Files::isRegularFile).forEach(...);
Files.lines(path, UTF_8).filter(...).collect(toList());
Files.readAllBytes(path);                        // whole file as byte[]
try (var watcher = FileSystems.getDefault().newWatchService()) { ... }
```

**Fork/Join** — divide-and-conquer parallelism
```java
class SumTask extends RecursiveTask<Long> {
    protected Long compute() {
        if (size < THRESHOLD) return computeDirectly();
        var left = new SumTask(...); left.fork();
        return new SumTask(...).compute() + left.join();
    }
}
ForkJoinPool.commonPool().invoke(task);
```

**`ThreadLocalRandom`** — lock-free per-thread random; prefer over `Math.random()` and `new Random()`
```java
int n = ThreadLocalRandom.current().nextInt(0, 100);
```

**`Phaser`** — flexible barrier; prefer over `CyclicBarrier` when party count is dynamic

---
See also: `examples/jdk7/Jdk7Features.java`
