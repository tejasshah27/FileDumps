# Decision Guide — When to Use What

Read this when choosing between competing patterns or APIs.
For full API details, read the relevant concept reference file.
Every decision below is a scenario, not a feature listing.

Cross-reference: `collections.md` · `streams-and-functional.md` · `concurrency.md` · `types-and-oop.md` · `optional-and-errors.md` · `spring-data.md` · `spring-core.md` · `jvm-and-performance.md`

---

## Table of Contents

1. [Stream vs for-loop](#stream-vs-for-loop)
2. [Stream pipeline vs Gatherers (JDK 24+)](#stream-pipeline-vs-gatherers-jdk-24)
3. [CompletableFuture vs StructuredTaskScope](#completablefuture-vs-structuredtaskscope)
4. [record vs class](#record-vs-class)
5. [sealed interface vs enum](#sealed-interface-vs-enum)
6. [Optional vs throw exception](#optional-vs-throw-exception)
7. [Virtual threads vs Platform thread pool](#virtual-threads-vs-platform-thread-pool)
8. [Text block vs String.format vs concatenation](#text-block-vs-stringformat-vs-concatenation)
9. [switch expression vs if-else](#switch-expression-vs-if-else)
10. [ScopedValue vs ThreadLocal vs method parameter](#scopedvalue-vs-threadlocal-vs-method-parameter)
11. [Collections: which to choose](#collections-which-to-choose)
12. [Concurrency primitives: which to choose](#concurrency-primitives-which-to-choose)
13. [Repository: full entity vs projection](#repository-full-entity-vs-projection)
14. [@ConfigurationProperties vs @Value](#configurationproperties-vs-value)
15. [Exception: when to use which type](#exception-when-to-use-which-type)
16. [String checks: isBlank vs isEmpty vs null-check](#string-checks-isblank-vs-isempty-vs-null-check)
17. [Immutability: which mechanism to use](#immutability-which-mechanism-to-use)

---

## Stream vs for-loop

**Use Stream when:**
- Transforming, filtering, grouping, or aggregating a collection
- Building a declarative pipeline where each step is independent
- Result needs to be collected (list, map, set, count, join)
- Parallelism is desired (`.parallelStream()`)

**Use for-loop when:**
- Need to throw checked exceptions inside the body
- Multiple mutable variables updated per iteration (stream would require array/holder hacks)
- Early exit depends on accumulated state across iterations
- Debugging priority — stack traces from streams are noisy
- Tight loop over primitives where boxing would hurt (use IntStream instead)
- Writing to an external structure that is not a final result (side-effectful loops)

```java
// STREAM — transform + collect
List<String> names = users.stream()
    .filter(User::isActive)
    .map(User::name)
    .sorted()
    .toList();

// LOOP — multiple mutable state vars, complex exit
int sum = 0, count = 0;
for (User u : users) {
    if (u.isActive()) { sum += u.score(); count++; }
    if (sum > LIMIT) break;   // conditional early exit with accumulated state
}
```

---

## Stream pipeline vs Gatherers (JDK 24+)

**Use plain Stream pipeline when:**
- Standard transform/filter/collect — no state needed between elements
- Grouping, partitioning, joining — Collectors handle it
- flatMap, distinct, sorted cover the operation

**Use Gatherers when:**
- Need a **sliding window** over consecutive elements (e.g. moving average)
- Need **non-overlapping batches** (previously: awkward groupingBy + AtomicInteger counter)
- Need **running accumulation** (cumulative sum, running max) — previously: reduce loses intermediates
- Need **stateful deduplication** by custom key across elements
- Need **bounded parallel map** with preserved order (`mapConcurrent`)
- The intermediate operation does not fit any existing stream op

```java
// BEFORE Gatherers — sliding window of 3 (ugly, error-prone)
AtomicInteger idx = new AtomicInteger();
stream.collect(Collectors.groupingBy(e -> idx.getAndIncrement() / 3))
      .values().stream()...

// AFTER — intent is clear
stream.gather(Gatherers.windowSliding(3))
      .map(window -> average(window))
      .toList();

// BEFORE — running sum required external array trick
int[] acc = {0};
stream.map(n -> { acc[0] += n; return acc[0]; }).toList();

// AFTER
stream.gather(Gatherers.scan(() -> 0, Integer::sum)).toList();
```

---

## CompletableFuture vs StructuredTaskScope

**Use StructuredTaskScope (JDK 21+) when:**
- Fan-out: calling N independent services in parallel and need ALL results
- Fan-out: calling N services and want FIRST success (e.g. cache + DB fallback)
- Cancellation must be automatic — if one subtask fails, others should be cancelled
- Subtasks have a clear parent-child relationship (scoped lifetime)
- Using virtual threads (StructuredTaskScope is designed for them)

**Use CompletableFuture when:**
- Sequential async chain: A completes → triggers B → triggers C
- Single async operation with recovery (`.exceptionally`, `.handle`)
- Integrating with legacy async code or libraries that return CompletableFuture
- JDK < 21

```java
// StructuredTaskScope — fan-out, cancel all on first failure
try (var scope = new StructuredTaskScope.ShutdownOnFailure()) {
    var user   = scope.fork(() -> fetchUser(id));
    var orders = scope.fork(() -> fetchOrders(id));
    scope.join().throwIfFailed();
    return new Profile(user.get(), orders.get());
}

// CompletableFuture — sequential async chain
CompletableFuture
    .supplyAsync(() -> fetchUser(id))
    .thenCompose(user -> enrich(user))
    .thenApply(UserDto::from)
    .exceptionally(ex -> UserDto.unknown());
```

---

## record vs class

**Use record when:**
- Pure data carrier: DTO, API request/response, projection, value object, event
- All fields set at construction, never mutated afterward
- Need `equals`/`hashCode`/`toString` to be value-based (not identity-based)
- No inheritance required (records are implicitly `final`)

**Use class when:**
- JPA `@Entity` (requires no-arg constructor, mutable fields for Hibernate)
- Mutable domain object with state-transition methods
- Inheritance hierarchy needed
- Framework requires JavaBean conventions (getters/setters)

```java
// record — DTO, value object
record MoneyAmount(long cents, String currency) {
    MoneyAmount { if (cents < 0) throw new IllegalArgumentException(); }
}

// class — JPA entity (must be mutable, identity-based)
@Entity class Order {
    @Id UUID id;
    OrderStatus status;        // mutated by confirm(), cancel() etc.
    void confirm() { this.status = CONFIRMED; }
}
```

---

## sealed interface vs enum

**Use sealed interface when:**
- Variants carry **different data** (each subtype has different fields)
- Want pattern-matching exhaustiveness on a type hierarchy
- Variants have methods with different implementations
- Subtypes may themselves be records or classes

**Use enum when:**
- Variants are **stateless labels** (no per-variant data beyond name/ordinal)
- Need `values()`, `ordinal()`, `name()`, or `EnumSet`/`EnumMap`
- Need singleton semantics
- Used as DB column (`@Enumerated`)

```java
// sealed — variants carry different data
sealed interface PaymentResult permits Success, Failure, Pending {
    record Success(String txId, Instant at) implements PaymentResult {}
    record Failure(String reason, int code) implements PaymentResult {}
    record Pending(String ref, Instant expires) implements PaymentResult {}
}

// enum — stateless labels, need EnumMap, used in JPA
enum OrderStatus { PENDING, CONFIRMED, SHIPPED, DELIVERED, CANCELLED }
Map<OrderStatus, Integer> countByStatus = new EnumMap<>(OrderStatus.class);
```

---

## Optional vs throw exception

**Return Optional when:**
- "Not found" is a **normal, expected** outcome (lookup by ID, search by criteria)
- Caller should decide what to do with absence
- Method name implies a search (findBy, lookup, resolve)

**Throw exception when:**
- Absence is a **contract violation** or programming error
- The caller already validated the input exists
- Domain rule: the entity MUST exist at this point

**Never use Optional for:**
- Field declarations
- Constructor/method parameters
- Collection elements

```java
// Optional — expected absence: caller decides
Optional<User> findByEmail(String email) { ... }

// Throw — contract: must exist at this call site
User getRequiredById(UUID id) {
    return repo.findById(id)
        .orElseThrow(() -> new EntityNotFoundException("User not found: " + id));
}

// BAD — Optional as parameter
void send(Optional<String> email) { ... }   // ← just use @Nullable or two methods
```

---

## Virtual threads vs Platform thread pool

**Use virtual threads when:**
- Work is **I/O-bound**: DB queries, HTTP calls, file I/O, `Thread.sleep`
- Per-request server model (Spring Boot 3.2+ with `spring.threads.virtual.enabled=true`)
- Many concurrent tasks that mostly wait (thousands of concurrent connections)
- Replacing bulkhead patterns that existed only to limit blocking

**Use platform thread pool (ForkJoinPool, fixed pool) when:**
- Work is **CPU-bound**: computation, image processing, compression, cryptography
- Need to limit resource use precisely (e.g. max 4 threads for CPU work)
- Library uses `synchronized` extensively (virtual threads would pin carrier)

**Never:**
- Pool virtual threads (`newFixedThreadPool` with virtual threads defeats the purpose)
- Use virtual threads for tight CPU loops (no benefit, wastes scheduler)

```java
// I/O-bound — virtual threads shine
try (var exec = Executors.newVirtualThreadPerTaskExecutor()) {
    ids.forEach(id -> exec.submit(() -> repo.findById(id)));  // thousands = fine
}

// CPU-bound — platform pool
var pool = Executors.newFixedThreadPool(Runtime.getRuntime().availableProcessors());
pool.submit(() -> computeHash(largePayload));
```

---

## Text block vs String.format vs concatenation

**Use text block (`"""`) when:**
- Content spans multiple lines: SQL, JSON, XML, HTML, email body, log message
- Embedding quotes would require heavy escaping
- Indentation readability matters

**Use `.formatted()` when:**
- Multi-line template with runtime values (combine with text block)

**Use `+` operator when:**
- Simple single-line concatenation (JIT optimises this via `invokedynamic`)

**Use `StringBuilder` when:**
- Building a string in a loop (each `+=` allocates; StringBuilder does not)

**Use `Collectors.joining()` when:**
- Concatenating stream elements with delimiter/prefix/suffix

```java
// Text block — SQL (clear, no escaping)
String sql = """
        SELECT id, name FROM users
        WHERE active = true AND role = :role
        ORDER BY name
        """;

// .formatted() — parameterised multi-line
String body = """
        Dear %s,
        Your order #%d is confirmed.
        """.formatted(name, orderId);

// + — simple single-line
String key = prefix + ":" + id;

// StringBuilder — loop
var sb = new StringBuilder(items.size() * 16);
for (var item : items) sb.append(item).append(',');

// Collectors.joining — stream
items.stream().collect(Collectors.joining(", ", "[", "]"));
```

---

## switch expression vs if-else

**Use switch expression when:**
- Multiple branches on a **single value** (type, status, code, enum)
- Working with sealed types (exhaustiveness checked by compiler)
- Value is being returned or assigned (switch as expression)
- Replacing long if-else-if chains on the same variable

**Use if-else when:**
- Conditions involve **multiple independent variables**
- Range checks (`if (x > 0 && y < MAX)`)
- Complex boolean compositions
- Only 1–2 branches (switch overhead not worth it)

```java
// switch expression — single value, exhaustive, clean
String label = switch (status) {
    case PENDING   -> "Awaiting confirmation";
    case CONFIRMED -> "Confirmed";
    case SHIPPED   -> "In transit";
    case DELIVERED -> "Delivered";
    case CANCELLED -> "Cancelled";
};

// if-else — multiple variables, range check
if (amount > 0 && amount < limit && user.isVerified()) {
    approve();
} else if (amount >= limit) {
    escalate();
}
```

---

## ScopedValue vs ThreadLocal vs method parameter

**Use ScopedValue (JDK 21+) when:**
- Cross-cutting context needs to flow through a call tree: trace ID, current user, tenant ID
- Using virtual threads (ThreadLocal can leak across thread reuse; ScopedValue cannot)
- Value is **immutable** for the duration of the request/scope
- Passing the context as a method parameter would pollute every method signature

**Use method parameter when:**
- Context is directly relevant to the method's contract (not cross-cutting)
- Only 1–2 call levels deep

**Use ThreadLocal only when:**
- Legacy code or library compatibility
- JDK < 21

```java
// ScopedValue — cross-cutting, immutable, virtual-thread safe
static final ScopedValue<RequestContext> CTX = ScopedValue.newInstance();

void handleRequest(RequestContext ctx) {
    ScopedValue.where(CTX, ctx).run(() -> {
        service.process();           // CTX.get() works anywhere in call tree
    });
}

// Method param — when context IS the contract
Money convert(Money amount, Currency target, ExchangeRates rates) { ... }
```

---

## Collections: which to choose

**List:**
| Scenario | Choice |
|---|---|
| Default ordered list | `ArrayList` |
| Frequent head/tail insert/remove | `ArrayDeque` (not LinkedList) |
| Thread-safe, read-heavy | `CopyOnWriteArrayList` |
| Immutable literal | `List.of(...)` |
| Immutable copy of mutable | `List.copyOf(mutable)` |

**Map:**
| Scenario | Choice |
|---|---|
| Default | `HashMap` |
| Maintain insertion order | `LinkedHashMap` |
| Sorted by key | `TreeMap` |
| Enum keys | `EnumMap` — always; fastest, minimal memory |
| Thread-safe | `ConcurrentHashMap` |
| Immutable literal (≤10 pairs) | `Map.of(...)` |

**Set:**
| Scenario | Choice |
|---|---|
| Default | `HashSet` |
| Maintain insertion order | `LinkedHashSet` |
| Sorted | `TreeSet` |
| Enum values | `EnumSet` — always; bit-vector backed |
| Immutable literal | `Set.of(...)` |

```java
// Enum keys — always EnumMap, never HashMap<OrderStatus, ...>
Map<OrderStatus, List<Order>> byStatus = new EnumMap<>(OrderStatus.class);

// Frequent head insert — ArrayDeque, not LinkedList
Deque<Task> queue = new ArrayDeque<>();
queue.addFirst(priorityTask);

// Pre-size HashMap to avoid rehash at 0.75 load factor
Map<String, User> cache = new HashMap<>(expectedSize * 2);
```

---

## Concurrency primitives: which to choose

| Scenario | Choice |
|---|---|
| Simple increment, read rarely | `AtomicLong` |
| High-write counter (metrics, stats) | `LongAdder` — segments reduce contention |
| Accumulate max/min | `LongAccumulator` |
| Read-heavy, occasional write | `StampedLock` optimistic read |
| Read/write balanced | `ReentrantReadWriteLock` |
| Mutual exclusion with virtual threads | `ReentrantLock` (not `synchronized`) |
| Lock-free field update (CAS) | `VarHandle` |
| One-shot lazy init | `AtomicReference` + CAS, or `Supplier` + DCL |

```java
// HIGH-CONTENTION counter: LongAdder beats AtomicLong
// AtomicLong — all threads CAS the same cell → contention
// LongAdder  — each thread updates its own cell → sum at read time
LongAdder requestCount = new LongAdder();
requestCount.increment();   // thread-local cell, no CAS collision
long total = requestCount.sum();

// VIRTUAL THREAD + lock — must use ReentrantLock
// synchronized pins the carrier OS thread; ReentrantLock unmounts the virtual thread
private final ReentrantLock lock = new ReentrantLock();
lock.lock(); try { ... } finally { lock.unlock(); }
```

---

## Repository: full entity vs projection

**Use full entity when:**
- You will modify and save the entity
- You need associations that are loaded lazily
- Domain behaviour lives on the entity

**Use projection (interface or record) when:**
- Read-only: list view, report, search result, API response
- Only a subset of columns is needed (avoids loading unused data)
- High-volume query (projections are lighter — no first-level cache overhead)

**Use native query when:**
- JPQL cannot express the query (window functions, CTE, JSONB ops)
- Aggregate reporting where performance matters

```java
// Full entity — you'll call order.confirm() and repo.save()
Order order = repo.findById(id).orElseThrow();
order.confirm();
repo.save(order);

// Projection — read-only list view
interface OrderSummary { UUID getId(); String getStatus(); long getAmountCents(); }
List<OrderSummary> summaries = repo.findSummariesByCustomerId(customerId, sort);

// Record projection (JDK 16+)
record OrderView(UUID id, String status, long amount) {}
@Query("SELECT new com.example.OrderView(o.id, o.status, o.amountCents) FROM Order o ...")
List<OrderView> findViews(...);
```

---

## @ConfigurationProperties vs @Value

**Use `@ConfigurationProperties` + record when:**
- Multiple related properties form a group (database config, API config, limits)
- Want validation annotations (`@NotBlank`, `@Min`, `@Max`) at startup
- Config is injected into multiple classes

**Use `@Value` when:**
- Single isolated property
- SpEL expression needed
- Quick prototype / legacy code integration

```java
// @ConfigurationProperties — group, validated, record
@ConfigurationProperties(prefix = "app.gateway")
record GatewayConfig(
    @NotNull URI endpoint,
    @Positive int maxRetries,
    @NotNull Duration timeout
) {}

// @Value — single isolated value
@Value("${app.feature.new-checkout:false}")
private boolean newCheckoutEnabled;
```

---

## Exception: when to use which type

| Scenario | Use |
|---|---|
| Invalid input from caller (programming error) | `IllegalArgumentException` |
| Object in wrong state for this operation | `IllegalStateException` |
| Entity not found (expected absence) | custom `NotFoundException extends RuntimeException` |
| Domain rule violation | custom sealed hierarchy |
| Must signal to caller but don't want checked | `RuntimeException` subclass |
| API boundary (Spring controller) | `@ExceptionHandler` + `ProblemDetail` |

```java
// Fail fast — validate at entry point, not deep in logic
void process(List<Order> orders) {
    Objects.requireNonNull(orders, "orders");
    if (orders.isEmpty()) throw new IllegalArgumentException("orders must not be empty");
    ...
}

// Domain error as sealed type — forces exhaustive handling at call site
sealed interface TransferResult permits TransferResult.Ok, TransferResult.InsufficientFunds, TransferResult.LimitExceeded {}
```

---

## String checks: isBlank vs isEmpty vs null-check

```java
// isEmpty()   — length == 0 only; "  " is NOT empty
// isBlank()   — empty OR only Unicode whitespace; "  " IS blank
// == null     — reference check only

// WRONG: won't catch "   " (spaces only)
if (name == null || name.isEmpty()) throw ...

// CORRECT: catches null, "", "   "
if (name == null || name.isBlank()) throw ...

// In streams — use Predicate.not for method refs
stream.filter(Predicate.not(String::isBlank))  // not: filter(s -> !s.isBlank())

// strip() vs trim():
// trim() — removes only ASCII chars ≤ 0x20
// strip() — removes Unicode whitespace (e.g. \u2000 non-breaking space)
// Always prefer strip() over trim()
```

---

## Immutability: which mechanism to use

| Need | Mechanism |
|---|---|
| Immutable literal list/set/map in code | `List.of` / `Set.of` / `Map.of` |
| Immutable snapshot of mutable input | `List.copyOf` / `Map.copyOf` |
| Immutable data object | `record` |
| Immutable complex object (many fields, validation) | `record` with compact constructor |
| Immutable object requiring builder | `record` + nested `Builder` class |
| Immutable field in class | `private final` |
| Immutable thread-shared context | `ScopedValue` |

Never use `Collections.unmodifiableList(new ArrayList<>(...))` — prefer `List.copyOf`.
Never use `final` on a mutable object reference as a substitute for immutability — it only prevents reassignment of the reference, not mutation of the object.
