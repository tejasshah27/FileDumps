package examples.jdk12_17;

import java.util.*;
import java.util.random.*;
import java.util.stream.Collectors;

/**
 * JDK 12–17 — Switch expressions, text blocks, records, sealed classes,
 *              pattern instanceof, helpful NPE, String.indent/transform,
 *              Collectors.teeing, mapMulti, Stream.toList()
 */
public class Jdk12To17Features {

    // ═══════════════════════════════════════════════════════════════════════
    // Switch expressions (JDK 14 final, JEP 361)
    // ═══════════════════════════════════════════════════════════════════════

    // BEFORE: int result; switch(x) { case A: result=1; break; ... }
    // AFTER (arrow form — no fall-through, no break, exhaustive):
    enum Priority { LOW, MEDIUM, HIGH, CRITICAL }

    int slaHours(Priority p) {
        return switch (p) {
            case LOW      -> 72;
            case MEDIUM   -> 24;
            case HIGH     ->  4;
            case CRITICAL ->  1;
            // no default needed — enum is exhaustive
        };
    }

    // Block form with yield — when you need statements
    String describe(Object obj) {
        return switch (obj) {
            case null     -> "null";
            case Integer i when i < 0 -> "negative int";
            case Integer i -> {
                String suffix = i % 2 == 0 ? "even" : "odd";
                yield "int " + i + " (" + suffix + ")";   // yield exits block with value
            }
            case String s  -> "string of length " + s.length();
            default        -> obj.getClass().getSimpleName();
        };
    }

    // Switch as expression embedded in larger expression
    boolean isWeekend(java.time.DayOfWeek day) {
        return switch (day) {
            case SATURDAY, SUNDAY -> true;
            default               -> false;
        };
    }

    // ═══════════════════════════════════════════════════════════════════════
    // Text blocks (JDK 15 final, JEP 378)
    // ═══════════════════════════════════════════════════════════════════════

    // BEFORE:
    // String json = "{\n" +
    //     "  \"name\": \"" + name + "\",\n" +
    //     "  \"active\": true\n" +
    //     "}";
    // AFTER:
    String buildJson(String name, int age) {
        return """
                {
                  "name": "%s",
                  "age": %d,
                  "active": true
                }
                """.formatted(name, age);
        // closing """ indentation = baseline; all lines trimmed by that many spaces
    }

    // SQL — the original motivation for text blocks
    static final String FIND_ACTIVE_USERS = """
            SELECT u.id,
                   u.email,
                   r.name        AS role,
                   u.created_at
            FROM   users u
            JOIN   roles r ON r.id = u.role_id
            WHERE  u.active = true
              AND  u.created_at > :since
            ORDER  BY u.created_at DESC
            LIMIT  :limit OFFSET :offset
            """;

    // HTML email template
    String emailTemplate(String firstName, String actionUrl) {
        return """
                <!DOCTYPE html>
                <html>
                  <body>
                    <p>Hi %s,</p>
                    <p>Click <a href="%s">here</a> to confirm your account.</p>
                  </body>
                </html>
                """.formatted(firstName, actionUrl);
    }

    // Line continuation: \ suppresses the embedded newline
    String singleLine() {
        return """
                This is all \
                one line.""";    // → "This is all one line."
    }

    // \s preserves trailing whitespace that would otherwise be stripped
    String fixedWidth() {
        return """
                Alice  \s
                Bob    \s
                Charlie\s
                """;             // each line ends with a preserved space
    }

    // ═══════════════════════════════════════════════════════════════════════
    // Records (JDK 16 final, JEP 395)
    // ═══════════════════════════════════════════════════════════════════════

    // Minimal record — compiler generates: constructor, accessors, equals, hashCode, toString
    record Point(double x, double y) {}

    // Compact canonical constructor — validation + normalization (no this.x = x needed)
    record Money(long amount, String currency) {
        Money {
            if (amount < 0)   throw new IllegalArgumentException("amount must be >= 0");
            Objects.requireNonNull(currency, "currency");
            currency = currency.toUpperCase().strip();   // normalize in compact constructor
        }

        // Additional constructor must delegate to canonical
        Money(long amount) { this(amount, "USD"); }

        // Derived values
        Money add(Money other) {
            if (!currency.equals(other.currency))
                throw new IllegalArgumentException("currency mismatch");
            return new Money(amount + other.amount, currency);
        }

        boolean isZero() { return amount == 0L; }

        static Money zero(String currency) { return new Money(0, currency); }
    }

    // Record implementing interface
    interface Displayable { String display(); }

    record User(java.util.UUID id, String name, String email) implements Displayable {
        User {
            Objects.requireNonNull(id,    "id");
            Objects.requireNonNull(name,  "name");
            Objects.requireNonNull(email, "email");
            if (!email.contains("@")) throw new IllegalArgumentException("invalid email: " + email);
        }

        // Static factory preferred over direct constructor exposure
        static User create(String name, String email) {
            return new User(java.util.UUID.randomUUID(), name, email);
        }

        @Override
        public String display() { return "%s <%s>".formatted(name, email); }
    }

    // Generic record
    record Page<T>(List<T> content, int page, int size, long total) {
        Page { content = List.copyOf(content); }   // defensive copy in compact constructor

        boolean hasNext()     { return (long) page * size + content.size() < total; }
        boolean isEmpty()     { return content.isEmpty(); }
        int totalPages()      { return (int) Math.ceil((double) total / size); }
    }

    // ═══════════════════════════════════════════════════════════════════════
    // Sealed classes (JDK 17 final, JEP 409)
    // ═══════════════════════════════════════════════════════════════════════

    // Model domain states as closed hierarchy — compiler enforces exhaustiveness
    sealed interface PaymentResult
        permits PaymentResult.Success, PaymentResult.Failure, PaymentResult.Pending {

        record Success(String txId, Money amount, java.time.Instant timestamp)
            implements PaymentResult {}

        record Failure(String reason, int errorCode)
            implements PaymentResult {
            boolean isRetryable() { return errorCode >= 500; }
        }

        record Pending(String reference, java.time.Instant expiresAt)
            implements PaymentResult {}
    }

    // Exhaustive switch — compiler rejects if any permit subtype is missing
    String renderResult(PaymentResult result) {
        return switch (result) {
            case PaymentResult.Success s  ->
                "Payment %s processed: %s".formatted(s.txId(), s.amount());
            case PaymentResult.Failure f  ->
                "Payment failed (%d): %s".formatted(f.errorCode(), f.reason());
            case PaymentResult.Pending p  ->
                "Payment pending until %s".formatted(p.expiresAt());
            // No default needed — compiler knows all permits
        };
    }

    // Sealed interface + pattern matching in switch = algebraic data types in Java
    sealed interface Expr permits Expr.Num, Expr.Add, Expr.Mul {
        record Num(double value)      implements Expr {}
        record Add(Expr left, Expr right) implements Expr {}
        record Mul(Expr left, Expr right) implements Expr {}
    }

    double eval(Expr expr) {
        return switch (expr) {
            case Expr.Num(double v)         -> v;
            case Expr.Add(var l, var r)     -> eval(l) + eval(r);
            case Expr.Mul(var l, var r)     -> eval(l) * eval(r);
        };
    }

    // ═══════════════════════════════════════════════════════════════════════
    // Pattern matching instanceof (JDK 16 final, JEP 394)
    // ═══════════════════════════════════════════════════════════════════════

    // BEFORE:
    // if (obj instanceof String) { String s = (String) obj; ... }
    // AFTER:
    String format(Object obj) {
        if (obj instanceof String s && !s.isBlank()) return s.strip();
        if (obj instanceof Integer i)               return "%,d".formatted(i);
        if (obj instanceof Double d)                return "%.4f".formatted(d);
        if (obj instanceof List<?> list)            return "list[" + list.size() + "]";
        return Objects.toString(obj, "null");
    }

    // Negation form — s in scope after the if (because null check passed)
    void requireString(Object obj) {
        if (!(obj instanceof String s))
            throw new IllegalArgumentException("Expected String, got: " +
                (obj == null ? "null" : obj.getClass().getSimpleName()));
        // s is in scope here
        System.out.println("String length: " + s.length());
    }

    // ═══════════════════════════════════════════════════════════════════════
    // Stream additions (JDK 12-16)
    // ═══════════════════════════════════════════════════════════════════════

    // Stream.toList() — JDK 16, unmodifiable, no null elements
    // BEFORE: .collect(Collectors.toUnmodifiableList())
    // AFTER:
    List<String> activeNames(List<User> users) {
        return users.stream().map(User::name).toList();
    }

    // mapMulti — push-based flatMap; better for conditional/variable-count expansion
    // BEFORE: flatMap(u -> u.active() ? Stream.of(u.email()) : Stream.empty())
    // AFTER:
    List<String> activeEmails(List<User> users) {
        return users.stream()
            .<String>mapMulti((user, push) -> {
                // push nothing, one, or many — no Stream allocation per element
                push.accept(user.email());
                if (user.name().length() > 10) push.accept("[long-name]");
            })
            .toList();
    }

    // Collectors.teeing — two collectors in one stream pass
    record Stats(long sum, long count) {
        double average() { return count == 0 ? 0 : (double) sum / count; }
    }

    Stats orderStats(List<Long> amounts) {
        return amounts.stream()
            .collect(Collectors.teeing(
                Collectors.summingLong(Long::longValue),
                Collectors.counting(),
                Stats::new));
    }

    // ═══════════════════════════════════════════════════════════════════════
    // String additions (JDK 12-15)
    // ═══════════════════════════════════════════════════════════════════════

    // String.indent(n) — add/remove leading whitespace; ensures trailing newline
    String indentBlock(String block, int spaces) {
        return block.indent(spaces);           // n>0 add, n<0 remove, 0 normalize newline only
    }

    // String.transform(Function) — pipe into function; fluent chain
    String normalizeInput(String raw) {
        return raw
            .transform(String::strip)
            .transform(String::toLowerCase)
            .transform(s -> s.replaceAll("\\s+", "_"));
    }

    // ═══════════════════════════════════════════════════════════════════════
    // Enhanced pseudo-random (JDK 17, JEP 356)
    // ═══════════════════════════════════════════════════════════════════════

    // Algorithm-pluggable; all implement RandomGenerator interface
    RandomGenerator rng = RandomGeneratorFactory.of("L64X128MixRandom").create();

    List<Integer> randomSample(int count, int bound) {
        return rng.ints(count, 0, bound).boxed().toList();
    }

    // Seeded for reproducible tests
    RandomGenerator seeded(long seed) {
        return RandomGeneratorFactory.of("Xoshiro256PlusPlus").create(seed);
    }
}
