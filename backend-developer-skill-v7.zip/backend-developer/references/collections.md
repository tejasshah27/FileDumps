# Collections

## Which type to use

| Scenario | Choice | Why |
|---|---|---|
| Default ordered list | `ArrayList` | O(1) index access, cache-friendly iteration |
| Frequent head/tail insert/remove | `ArrayDeque` | Never `LinkedList` — poor cache locality |
| Thread-safe, read-heavy | `CopyOnWriteArrayList` | Lock-free reads; copy-on-write |
| Immutable literal | `List.of(...)` | Zero-copy, null-hostile, compact |
| Immutable copy of mutable | `List.copyOf(mutable)` | Defensive snapshot; throws on null element |
| Default map | `HashMap` | O(1) get/put average |
| Insertion-order iteration | `LinkedHashMap` | Predictable iteration order |
| Sorted by key | `TreeMap` | `NavigableMap`; ceiling/floor/range ops |
| Enum keys — always | `EnumMap` | Bit-array backed; fastest map possible; minimal memory |
| Thread-safe map | `ConcurrentHashMap` | Segment-locked writes; lock-free reads |
| Immutable map literal (≤10 pairs) | `Map.of(...)` | |
| Default set | `HashSet` | |
| Insertion-order set | `LinkedHashSet` | |
| Enum values — always | `EnumSet` | Bit-vector; `contains()` is a single bit-AND |
| Sorted set | `TreeSet` | |
| Immutable set literal | `Set.of(...)` | |

**Pre-size `HashMap` to avoid rehash** — default load factor is 0.75; rehash at 75% capacity:
```java
// For expectedSize entries, allocate capacity = expectedSize * 2 (avoids rehash entirely)
Map<String, User> cache = new HashMap<>(expectedSize * 2);
```

---

## Immutable factory methods (JDK 9)
```java
// Null-hostile — throws NPE on null element/key/value (intentional, catches bugs early)
List.of(a, b, c)                     // ordered, fixed size
Set.of(a, b, c)                      // no guaranteed order, no duplicates
Map.of("k1", v1, "k2", v2)          // up to 10 pairs
Map.ofEntries(                        // unbounded
    Map.entry("k1", v1),
    Map.entry("k2", v2)
)

// Defensive copy (JDK 10) — snapshot mutable input; also null-hostile
List.copyOf(mutableList)
Set.copyOf(mutableSet)
Map.copyOf(mutableMap)
```

Use `List.copyOf` in record compact constructors:
```java
record Batch(List<Order> orders) {
    Batch { orders = List.copyOf(orders); }   // caller can't mutate after construction
}
```

---

## List & Deque operations (JDK 8)
```java
list.removeIf(s -> s.isBlank())      // in-place filter
list.replaceAll(String::trim)        // in-place transform
list.sort(comparator)                // in-place stable mergesort

// JDK 21 — SequencedCollection (List, Deque, LinkedHashMap, TreeMap all implement)
list.getFirst() / list.getLast()     // replaces get(0) / get(size()-1)
list.addFirst(e) / list.addLast(e)
list.removeFirst() / list.removeLast()
list.reversed()                      // reversed VIEW — not a copy; mutations reflected both ways

deque.getFirst() / deque.getLast()
map.firstEntry() / map.lastEntry()
map.sequencedKeySet() / map.sequencedValues() / map.sequencedEntrySet()
```

---

## Map atomic operations (JDK 8)
```java
// AVOID: if (!map.containsKey(k)) map.put(k, v)  — race condition in concurrent code
// USE:
map.putIfAbsent(key, value)                      // atomic check-then-put
map.computeIfAbsent(key, k -> new ArrayList<>()) // canonical cache-miss pattern
map.computeIfPresent(key, (k, v) -> transform(v))
map.compute(key, (k, v) -> v == null ? 1 : v + 1) // null-safe atomic update
map.merge(key, 1, Integer::sum)                  // frequency count idiom
map.getOrDefault(key, fallback)
map.forEach((k, v) -> ...)
map.replaceAll((k, v) -> transform(v))
map.remove(key, specificValue)                   // conditional remove — returns boolean
map.replace(key, oldValue, newValue)             // CAS-style conditional replace
```

---

## Comparator fluent API (JDK 8)
```java
Comparator.comparing(User::lastName)
    .thenComparing(User::firstName)
    .thenComparingInt(User::age)
    .reversed()
Comparator.naturalOrder() / Comparator.reverseOrder()
Comparator.nullsFirst(Comparator.naturalOrder())
Comparator.comparingInt(String::length)
```

---

## toArray without unchecked cast (JDK 11)
```java
String[] arr = list.toArray(String[]::new);   // no cast, no new String[0] idiom
```

---

## Gotchas

**Mutable object as HashMap key** — if key's `hashCode()`/`equals()` depend on mutable fields
and the key is mutated after insertion, the entry is permanently lost — can't be found or removed.
Use only immutable objects as map keys. Records are ideal map keys.

**Missing `hashCode()` when overriding `equals()`** — objects that are `equals()` MUST have same
`hashCode()`. Violation → `HashSet` stores duplicates, `HashMap` silently loses entries.
Always override both. IDEs and Sonar catch this. Records implement both correctly by default.

**`LinkedList` instead of `ArrayDeque`** — `LinkedList` allocates a node object per element;
poor cache locality; slower iteration. `ArrayDeque` is backed by a resizable array — always prefer
for queue/stack use cases.

**Static collection that grows forever** — `static Map<String, Object> cache = new HashMap<>()`
is a GC root; entries never collected. Heap climbs silently.
Fix: bounded cache with LRU eviction (`LinkedHashMap` with `removeEldestEntry`) or Guava/Caffeine.

**`StringBuffer` instead of `StringBuilder`** — `StringBuffer` synchronises every method.
For local string building (never shared), this is pure overhead. Always use `StringBuilder`.

---

See also: `examples/jdk7/Jdk7Features.java`, `examples/jdk8/Jdk8Features.java`, `examples/jdk21/Jdk21Features.java`
