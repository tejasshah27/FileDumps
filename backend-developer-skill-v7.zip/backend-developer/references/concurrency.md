# Concurrency

## Choose the right tool

| Scenario | Tool |
|---|---|
| I/O-bound per-task parallelism | Virtual threads (JDK 21+) |
| CPU-bound divide-and-conquer | `ForkJoinPool` / `RecursiveTask` |
| Fan-out N calls, need all results | `StructuredTaskScope.ShutdownOnFailure` (JDK 21+) |
| Fan-out N calls, need first success | `StructuredTaskScope.ShutdownOnSuccess` (JDK 21+) |
| Async sequential chain | `CompletableFuture` |
| Fire-and-forget async | `CompletableFuture` or `@Async` |
| Scheduled repeating task | `ScheduledExecutorService` (not `Timer` — not thread-safe) |
| High-contention write counter | `LongAdder` / `LongAccumulator` |
| Single atomic counter with CAS | `AtomicLong` / `AtomicInteger` |
| Read-heavy shared state | `StampedLock` optimistic read |
| Read/write balanced shared state | `ReentrantReadWriteLock` |
| Mutual exclusion (virtual threads) | `ReentrantLock` — never `synchronized` |
| Lock-free field CAS | `VarHandle` |
| Cross-cutting request context | `ScopedValue` (JDK 21+) — not `ThreadLocal` |

---

## Virtual Threads (JDK 21)
M:N threading: millions of virtual threads multiplexed onto OS threads.
Blocking I/O causes virtual thread to **unmount** (carrier freed); not park.

```java
// Per-task executor — never pool virtual threads
try (var exec = Executors.newVirtualThreadPerTaskExecutor()) {
    ids.forEach(id -> exec.submit(() -> repo.findById(id)));  // thousands = fine
}

// Named virtual thread (for debugging)
Thread.ofVirtual().name("order-processor-", 0).start(() -> processOrder(order));

// Spring Boot 3.2+ — one property enables globally
// spring.threads.virtual.enabled=true
// Covers: Tomcat request threads, @Async, @Scheduled, task executors
```

**Virtual thread rules:**
1. Never pool them — create one per task; pooling defeats the point
2. No benefit for CPU-bound tight loops — only helps blocking I/O
3. Replace `synchronized` with `ReentrantLock` — `synchronized` **pins** carrier thread
4. Replace `ThreadLocal` with `ScopedValue` — `ThreadLocal` leaks in reused threads
5. `Thread.sleep(Duration)` on virtual thread = cheap yield, not OS park

**Detect carrier pinning** with JFR event `jdk.VirtualThreadPinned`.

---

## synchronized vs ReentrantLock with virtual threads
```java
// BAD with virtual threads — pins carrier OS thread; blocks other virtual threads
synchronized (this) { doWork(); }

// GOOD — virtual thread unmounts from carrier while waiting; carrier freed
private final ReentrantLock lock = new ReentrantLock();
lock.lock();
try { doWork(); } finally { lock.unlock(); }   // always unlock in finally
```

---

## Structured Concurrency (JDK 21)
Fan-out with automatic cancellation. Designed for virtual threads.

```java
// ShutdownOnFailure — cancel all when any subtask fails
try (var scope = new StructuredTaskScope.ShutdownOnFailure()) {
    var user   = scope.fork(() -> fetchUser(id));
    var orders = scope.fork(() -> fetchOrders(id));
    var prefs  = scope.fork(() -> fetchPrefs(id));

    scope.join().throwIfFailed();   // waits all; re-throws first failure as ExecutionException

    return new Profile(user.get(), orders.get(), prefs.get());
}   // scope.close() cancels any still-running subtasks

// ShutdownOnSuccess — first result wins; others cancelled
try (var scope = new StructuredTaskScope.ShutdownOnSuccess<String>()) {
    scope.fork(() -> cacheService.get(key));
    scope.fork(() -> dbService.get(key));
    return scope.join().result();
}
```

vs `CompletableFuture.allOf()` — `allOf` has no automatic cancellation; error propagation is manual;
lifetime is not scoped. Use `StructuredTaskScope` when on JDK 21+.

---

## CompletableFuture — async chains (JDK 8)
```java
CompletableFuture
    .supplyAsync(() -> fetchUser(id), executor)
    .thenApply(User::getName)                        // transform, same thread
    .thenApplyAsync(this::enrich, executor)          // transform, different executor
    .thenCompose(name -> lookupProfile(name))        // chain next async step (flatMap)
    .thenCombine(fetchOrders(id), (p, o) -> new View(p, o))   // merge two futures
    .exceptionally(ex -> fallback)                   // recover from any exception
    .handle((result, ex) -> ex != null ? fallback : result)   // always runs
    .whenComplete((r, ex) -> audit(r, ex))           // side-effect, preserves value/exception
    .orTimeout(5, SECONDS)                           // JDK 9 — completes exceptionally
    .completeOnTimeout(fallback, 5, SECONDS);        // JDK 9 — completes with fallback value

CompletableFuture.allOf(f1, f2, f3).join();         // wait all; get results via f1.get() etc.
CompletableFuture.anyOf(f1, f2, f3).join();         // first to complete, any type
CompletableFuture.failedFuture(ex);                  // JDK 9
```

---

## ScopedValue — cross-cutting context (JDK 21)
```java
static final ScopedValue<RequestContext> CTX = ScopedValue.newInstance();

// Bind — immutable for duration of the run() call tree
ScopedValue.where(CTX, ctx).run(() -> service.handle(request));

// With return value
Result r = ScopedValue.where(CTX, ctx).call(() -> service.process());

// Read anywhere in call tree — no parameter drilling
RequestContext ctx = CTX.get();
```

**ScopedValue vs ThreadLocal:**
- `ThreadLocal` — mutable; leaks in thread pools if `.remove()` is forgotten; not safe with virtual threads
- `ScopedValue` — immutable; bounded to the `where().run()` block; automatically inherited by child virtual threads in `StructuredTaskScope`

Use `ScopedValue` for: trace ID, current user/tenant, request context, security principal.
Use `ThreadLocal` only for: legacy code or library compatibility.

---

## LongAdder vs AtomicLong
```java
// AtomicLong — all threads CAS the SAME memory cell → contention under high write load
AtomicLong counter = new AtomicLong();
counter.incrementAndGet();   // CAS loop on shared cell

// LongAdder — each thread updates its OWN cell; merged at read time
// No CAS collision; dramatically faster under high concurrency
LongAdder hits = new LongAdder();
hits.increment();           // thread-local cell
long total = hits.sum();    // merge all cells

// LongAccumulator — generalised: any commutative+associative binary op
LongAccumulator max = new LongAccumulator(Long::max, Long.MIN_VALUE);
max.accumulate(value);
```
Use `LongAdder` for: metrics, request counters, hit counters — anything written frequently from many threads.
Use `AtomicLong` when: you need atomic compare-and-swap semantics (not just counting).

---

## StampedLock — optimistic read (JDK 8)
```java
private final StampedLock sl = new StampedLock();
private double x, y;

// Optimistic read — no lock acquired; validate after read
double[] readPoint() {
    long stamp = sl.tryOptimisticRead();
    double cx = x, cy = y;
    if (!sl.validate(stamp)) {      // a writer ran concurrently — fall back to real read lock
        stamp = sl.readLock();
        try { cx = x; cy = y; } finally { sl.unlockRead(stamp); }
    }
    return new double[]{cx, cy};
}

void writePoint(double nx, double ny) {
    long stamp = sl.writeLock();
    try { x = nx; y = ny; } finally { sl.unlockWrite(stamp); }
}
```
Use when: shared object is read far more than written (config, coordinate state, rate limiter).

---

## VarHandle — lock-free field ops (JDK 9)
```java
static final VarHandle VALUE;
static {
    try {
        VALUE = MethodHandles.lookup()
            .findVarHandle(Node.class, "value", int.class);
    } catch (ReflectiveOperationException e) { throw new ExceptionInInitializerError(e); }
}

// Atomic operations
VALUE.compareAndSet(instance, expected, update);  // CAS
VALUE.getAndAdd(instance, 1);                     // atomic increment
VALUE.getVolatile(instance);                      // volatile read
```
Use `VarHandle` over `AtomicFieldUpdater` (slow reflection) and over `Unsafe` (unsafe, breaks modules).

---

## Fork/Join — CPU-bound divide-and-conquer (JDK 7)
```java
class SumTask extends RecursiveTask<Long> {
    private static final int THRESHOLD = 10_000;

    protected Long compute() {
        if (to - from <= THRESHOLD) return computeDirectly();
        int mid = (from + to) / 2;
        var left = new SumTask(data, from, mid); left.fork();
        return new SumTask(data, mid, to).compute() + left.join();
    }
}
ForkJoinPool.commonPool().invoke(new SumTask(data, 0, data.length));
```
Use for: parallel sort, parallel scan, recursive computation on large arrays.
Do NOT use for I/O-bound work — use virtual threads.

---

## Thread safety gotchas

**`volatile` misunderstood** — `volatile` guarantees visibility only; NOT atomicity.
`volatile int count++` is still a race (read-modify-write = 3 ops).
Fix: `AtomicInteger` for CAS; `LongAdder` for counting; `ReentrantLock` for compound actions.

**`HashMap` in multi-threaded context** — not thread-safe; concurrent structural modification →
infinite loop (JDK < 8) or data corruption (JDK 8+).
Fix: `ConcurrentHashMap` — segment-locked writes, lock-free reads.

**`new Thread()` directly** — no lifecycle control, rejection policy, monitoring, or shutdown.
Fix: always use `ExecutorService`. For I/O-bound: `newVirtualThreadPerTaskExecutor()`. For CPU-bound: `newFixedThreadPool(nCores)`.

**`ExecutorService` never shut down** — threads stay alive, JVM won't exit in tests.
Fix: `exec.shutdown()` in `finally`, or use try-with-resources (`AutoCloseable` since JDK 19).

**`ThreadLocal` not removed** — in thread-pool environments (Tomcat, Jetty), threads are reused.
`ThreadLocal` set per-request but never `.remove()`'d leaks request objects for the thread's lifetime.
Fix: `finally { tl.remove(); }`. Better: use `ScopedValue` (JDK 21+) — can't leak.

**Compound check-then-act without atomicity** — `if (!map.containsKey(k)) map.put(k, v)` is a
race in concurrent code. Fix: `map.putIfAbsent(k, v)` or `map.computeIfAbsent(k, factory)`.

---

See also: `examples/jdk7/Jdk7Features.java`, `examples/jdk8/Jdk8Features.java`, `examples/jdk9/Jdk9Features.java`, `examples/jdk21/Jdk21Features.java`
