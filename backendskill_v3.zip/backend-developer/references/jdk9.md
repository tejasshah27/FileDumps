# JDK 9 — Modules, Factories, Stream/Optional Polish

**Immutable collection factories** — zero-copy, null-hostile; prefer everywhere for literals
```java
List.of(a, b, c)                           // ordered, fixed-size
Set.of(a, b, c)                            // no guaranteed order, no duplicates
Map.of("k1", v1, "k2", v2)               // up to 10 pairs
Map.ofEntries(
    Map.entry("k1", v1),
    Map.entry("k2", v2)                    // unbounded; Map.entry = JDK 9 immutable Entry
)
```

**try-with-resources on effectively final vars** — no re-declaration needed (JDK 9+)
```java
// JDK 7-8: must declare new var in try(...)
// JDK 9+:
try (existingAutoCloseable) { ... }
```

**Stream additions**
```java
Stream.iterate(seed, predicate, step)      // bounded: Stream.iterate(0, n->n<10, n->n+1)
Stream.ofNullable(maybeNull)               // 0 or 1 element; replaces null-check + Stream.of
stream.takeWhile(pred)                     // ordered: elements until pred fails
stream.dropWhile(pred)                     // ordered: skip while pred holds
```

**Optional additions**
```java
opt.ifPresentOrElse(consumer, emptyAction)
opt.or(() -> Optional.of(fallback))        // chain Optional alternatives
opt.stream()                               // Stream<T> of 0 or 1; use in flatMap
```

**Collectors additions**
```java
Collectors.flatMapping(fn, downstream)     // flatMap then collect in one pass
Collectors.filtering(pred, downstream)     // filter inside groupingBy downstream collector
```

**Private interface methods** — extract shared logic from default methods
```java
interface Parser {
    default int parsePositive(String s) { return validated(parse(s)); }
    default int parseNegative(String s) { return validated(-parse(s)); }
    private int parse(String s) { return Integer.parseInt(s.strip()); }
    private int validated(int n) { if (n == 0) throw new IllegalArgumentException(); return n; }
}
```

**`@Deprecated` enriched**
```java
@Deprecated(since = "9", forRemoval = true)    // document lifecycle intent
```

**`VarHandle`** — atomic field ops without `Unsafe`
```java
static final VarHandle VALUE =
    MethodHandles.lookup().findVarHandle(Node.class, "value", int.class);
VALUE.compareAndSet(instance, expected, update);  // CAS
VALUE.getAndAdd(instance, 1);                     // atomic increment
```

**`StackWalker`** — cheap lazy stack inspection; replaces `Thread.currentThread().getStackTrace()`
```java
Optional<String> caller = StackWalker.getInstance()
    .walk(s -> s.skip(1).findFirst().map(StackWalker.StackFrame::getClassName));
```

**Reactive `Flow` API** — `Publisher`, `Subscriber`, `Subscription`, `Processor`; use Reactor/RxJava on top

**Multi-release JARs** — version-specific classes under `META-INF/versions/N/`

---
See also: `examples/jdk9/Jdk9Features.java`
