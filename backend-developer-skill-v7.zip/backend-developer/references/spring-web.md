# Spring Boot — Web Layer (Controllers, DTOs, Validation, Exception Handling)

## Controllers

Always constructor injection. Never `@Autowired` on fields (Sonar S3016, untestable, hides deps).
```java
@RestController
@RequestMapping("/api/v1/orders")
@Validated                          // enables @Min/@Max on method params
class OrderController {

    private final OrderService service;   // final — immutable after construction

    OrderController(OrderService service) { this.service = service; }

    @PostMapping
    @ResponseStatus(HttpStatus.CREATED)
    OrderResponse create(@RequestBody @Valid CreateOrderRequest req) {
        return service.create(req);
    }

    @GetMapping("/{id}")
    OrderResponse getById(@PathVariable UUID id) {
        return service.findById(id)
            .orElseThrow(() -> new NotFoundException("Order not found: " + id));
    }

    @GetMapping
    PagedResponse<OrderResponse> list(
        @RequestParam String customerId,
        @RequestParam(defaultValue = "0")  @Min(0)   int page,
        @RequestParam(defaultValue = "20") @Min(1) @Max(100) int size) {
        return service.listByCustomer(customerId, page, size);
    }

    @PatchMapping("/{id}/confirm")
    OrderResponse confirm(@PathVariable UUID id) {
        return service.confirm(id);
    }
}
```

---

## DTOs — use records (JDK 16+)
```java
// Request — validation annotations on record components
record CreateOrderRequest(
    @NotBlank String customerId,
    @Positive long amountCents,
    @NotBlank String currencyCode
) {}

// Response — static factory from entity keeps mapping in DTO, not service
record OrderResponse(UUID id, String customerId, String status, long amountCents, Instant createdAt) {
    static OrderResponse from(Order o) {
        return new OrderResponse(o.getId(), o.getCustomerId(),
            o.getStatus().name(), o.getAmountCents(), o.getCreatedAt());
    }
}

// Paged response
record PagedResponse<T>(List<T> content, int page, int size, long totalElements, int totalPages, boolean last) {
    static <T> PagedResponse<T> from(Page<T> p) {
        return new PagedResponse<>(p.getContent(), p.getNumber(), p.getSize(),
            p.getTotalElements(), p.getTotalPages(), p.isLast());
    }
}
```

**DTO decision:** use `record` for all DTOs. Immutable. Compact. No boilerplate.
Do NOT use `record` for JPA entities — Hibernate requires mutable class with no-arg constructor.

---

## Exception handling — ProblemDetail (RFC 7807, Spring 6 / Boot 3)
```java
@RestControllerAdvice
public class GlobalExceptionHandler extends ResponseEntityExceptionHandler {

    @ExceptionHandler(NotFoundException.class)
    ProblemDetail handleNotFound(NotFoundException ex, HttpServletRequest req) {
        var pd = ProblemDetail.forStatusAndDetail(HttpStatus.NOT_FOUND, ex.getMessage());
        pd.setInstance(URI.create(req.getRequestURI()));
        pd.setTitle("Resource Not Found");
        return pd;
    }

    @ExceptionHandler(IllegalStateException.class)
    @ResponseStatus(HttpStatus.CONFLICT)
    ProblemDetail handleConflict(IllegalStateException ex) {
        return ProblemDetail.forStatusAndDetail(HttpStatus.CONFLICT, ex.getMessage());
    }

    @ExceptionHandler(MethodArgumentNotValidException.class)
    ProblemDetail handleValidation(MethodArgumentNotValidException ex) {
        var pd = ProblemDetail.forStatusAndDetail(HttpStatus.BAD_REQUEST, "Validation failed");
        pd.setProperty("errors", ex.getBindingResult().getFieldErrors().stream()
            .map(e -> e.getField() + ": " + e.getDefaultMessage())
            .toList());
        return pd;
    }
}
```

Use `ProblemDetail` over custom error bodies — standard format, client-agnostic.

---

## REST design decisions

**Status codes:**
- `200 OK` — successful GET, PATCH, PUT
- `201 Created` — successful POST creating a resource
- `204 No Content` — successful DELETE
- `400 Bad Request` — validation failure, malformed input
- `404 Not Found` — resource doesn't exist
- `409 Conflict` — state transition violation, duplicate
- `422 Unprocessable Entity` — business rule violation
- `500 Internal Server Error` — unexpected error

**Endpoint naming:** plural nouns, no verbs in path.
`POST /orders` — create order
`GET /orders/{id}` — get by ID
`PATCH /orders/{id}/confirm` — state transition as sub-resource action

---

## Gotchas

**`@Autowired` on static field** — Spring doesn't inject static fields; stays `null` at runtime.
No startup error. Fix: constructor injection only.

**`@Transactional` on private method** — Spring AOP proxy doesn't intercept private methods.
Transaction silently not applied. No error. Fix: method must be `public` and called from another bean.

---

See also: `examples/springboot/OrderServiceStack.java`
