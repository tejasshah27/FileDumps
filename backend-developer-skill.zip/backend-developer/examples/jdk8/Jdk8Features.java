package examples.jdk8;

import java.time.*;
import java.time.format.DateTimeFormatter;
import java.time.temporal.TemporalAdjusters;
import java.util.*;
import java.util.concurrent.*;
import java.util.function.*;
import java.util.stream.*;

/**
 * JDK 8 — Lambdas, Streams, Optional, java.time, CompletableFuture
 */
public class Jdk8Features {

    // ── Method references — all 4 forms ─────────────────────────────────────
    void methodReferences(List<String> words) {
        words.forEach(System.out::println);                  // 1. instance on arbitrary obj
        words.stream().map(String::toUpperCase).toList();    // 2. instance on stream element
        words.stream().filter(Objects::nonNull).toList();    // 3. static method
        words.stream().map(StringBuilder::new).toList();     // 4. constructor ref
    }

    // ── Functional composition ───────────────────────────────────────────────
    Function<String, String> pipeline =
        ((Function<String, String>) String::strip)
            .andThen(String::toLowerCase)
            .andThen(s -> s.replace(" ", "_"));

    Predicate<String> notBlankAndShort =
        Predicate.not(String::isBlank).and(s -> s.length() < 50);

    // ── Streams — realistic examples ─────────────────────────────────────────
    record Order(String customerId, String status, double amount) {}

    Map<String, DoubleSummaryStatistics> orderStatsByCustomer(List<Order> orders) {
        return orders.stream()
            .filter(o -> "COMPLETED".equals(o.status()))
            .collect(Collectors.groupingBy(
                Order::customerId,
                Collectors.summarizingDouble(Order::amount)));
    }

    Map<Boolean, List<Order>> partitionBySize(List<Order> orders, double threshold) {
        return orders.stream()
            .collect(Collectors.partitioningBy(o -> o.amount() >= threshold));
    }

    String orderSummary(List<Order> orders) {
        return orders.stream()
            .map(o -> "#%s:%.2f".formatted(o.customerId(), o.amount()))
            .collect(Collectors.joining(", ", "[", "]"));
    }

    // merge fn handles duplicate keys: keep higher amount
    Map<String, Double> highestAmountPerCustomer(List<Order> orders) {
        return orders.stream()
            .collect(Collectors.toMap(
                Order::customerId,
                Order::amount,
                Math::max));
    }

    // flatMap — flatten nested lists
    List<String> allTags(List<List<String>> tagGroups) {
        return tagGroups.stream()
            .flatMap(Collection::stream)
            .distinct()
            .sorted()
            .toList();
    }

    // Primitive streams — avoid boxing in hot paths
    OptionalDouble averageSalary(int[] salaries) {
        return Arrays.stream(salaries)
            .filter(s -> s > 0)
            .average();
    }

    IntSummaryStatistics salaryStats(int[] salaries) {
        return Arrays.stream(salaries).summaryStatistics();
    }

    // ── Optional — proper usage ──────────────────────────────────────────────
    record Address(String city, String country) {}
    record Customer(String id, String name, Address address) {}

    // GOOD: Optional as return type from lookup
    Optional<Customer> findCustomer(String id) {
        return Optional.empty(); // stub
    }

    // GOOD: chain map/flatMap without null checks
    String customerCity(String customerId) {
        return findCustomer(customerId)
            .map(Customer::address)
            .map(Address::city)
            .orElse("Unknown");
    }

    // GOOD: orElseGet is lazy — only called when empty
    Customer resolveCustomer(String id) {
        return findCustomer(id)
            .orElseGet(() -> new Customer(id, "Guest", null));
    }

    // GOOD: orElseThrow with context
    Customer requireCustomer(String id) {
        return findCustomer(id)
            .orElseThrow(() -> new NoSuchElementException("Customer not found: " + id));
    }

    // BAD (shown for contrast) — DON'T DO:
    // optional.get()                                  ← NoSuchElementException blindly
    // if (optional.isPresent()) optional.get()        ← use ifPresent / map instead
    // Optional<T> field;                              ← never as field
    // void method(Optional<String> param)             ← never as param

    // ── Comparator fluent API ────────────────────────────────────────────────
    List<Customer> sortCustomers(List<Customer> customers) {
        return customers.stream()
            .sorted(Comparator.comparing(Customer::name)
                .thenComparing(Customer::id)
                .reversed())
            .toList();
    }

    // ── Map new methods ──────────────────────────────────────────────────────
    // computeIfAbsent — canonical cache miss pattern
    Map<String, List<String>> groupByPrefix(List<String> words) {
        var groups = new HashMap<String, List<String>>();
        for (var word : words) {
            String prefix = word.substring(0, Math.min(3, word.length()));
            groups.computeIfAbsent(prefix, _ -> new ArrayList<>()).add(word);
        }
        return groups;
    }

    // merge — frequency count
    Map<String, Integer> wordFrequency(List<String> words) {
        var freq = new HashMap<String, Integer>();
        words.forEach(w -> freq.merge(w, 1, Integer::sum));
        return freq;
    }

    // ── java.time — replace Date/Calendar/SimpleDateFormat ──────────────────
    static final DateTimeFormatter ISO_FMT = DateTimeFormatter.ISO_OFFSET_DATE_TIME;
    static final DateTimeFormatter DISPLAY  = DateTimeFormatter.ofPattern("dd MMM yyyy HH:mm");

    Instant parseTimestamp(String iso) {
        return OffsetDateTime.parse(iso, ISO_FMT).toInstant();
    }

    String formatForDisplay(Instant ts, ZoneId zone) {
        return ZonedDateTime.ofInstant(ts, zone).format(DISPLAY);
    }

    LocalDate firstMonday(LocalDate from) {
        return from.with(TemporalAdjusters.next(DayOfWeek.MONDAY));
    }

    boolean isWithinSla(Instant created, Instant resolved, Duration sla) {
        return Duration.between(created, resolved).compareTo(sla) <= 0;
    }

    // ── CompletableFuture — async pipelines ──────────────────────────────────
    record UserProfile(String userId, String name, List<String> orders) {}

    CompletableFuture<UserProfile> fetchProfile(String userId, Executor exec) {
        return CompletableFuture
            .supplyAsync(() -> lookupUser(userId), exec)
            .thenApply(user -> user + "_enriched")          // transform same thread
            .thenCombine(
                CompletableFuture.supplyAsync(() -> fetchOrders(userId), exec),
                (user, orders) -> new UserProfile(userId, user, orders))
            .exceptionally(ex -> {                          // recover on any upstream failure
                System.err.println("Profile fetch failed: " + ex.getMessage());
                return new UserProfile(userId, "unknown", List.of());
            })
            .orTimeout(5, TimeUnit.SECONDS);                // JDK9: fail if > 5s
    }

    // Fan-out — wait for all; results gathered after allOf
    CompletableFuture<List<String>> fanOut(List<String> ids, Executor exec) {
        var futures = ids.stream()
            .map(id -> CompletableFuture.supplyAsync(() -> fetchOrders(id).toString(), exec))
            .toList();
        return CompletableFuture
            .allOf(futures.toArray(CompletableFuture[]::new))
            .thenApply(_ -> futures.stream().map(CompletableFuture::join).toList());
    }

    // stubs
    private String lookupUser(String id)     { return "User:" + id; }
    private List<String> fetchOrders(String id) { return List.of(); }

    // ── LongAdder — high-contention counter ──────────────────────────────────
    // BEFORE: AtomicLong counter = new AtomicLong(); counter.incrementAndGet();
    // AFTER (faster under high write contention — segmented cells):
    private final LongAdder requestCount = new LongAdder();
    void recordRequest()  { requestCount.increment(); }
    long totalRequests()  { return requestCount.sum(); }

    // ── StampedLock — optimistic reads ───────────────────────────────────────
    private final java.util.concurrent.locks.StampedLock sl = new java.util.concurrent.locks.StampedLock();
    private double x, y;

    double[] readPoint() {
        long stamp = sl.tryOptimisticRead();
        double cx = x, cy = y;
        if (!sl.validate(stamp)) {              // another thread wrote — fall back to read lock
            stamp = sl.readLock();
            try { cx = x; cy = y; } finally { sl.unlockRead(stamp); }
        }
        return new double[]{cx, cy};
    }

    void writePoint(double nx, double ny) {
        long stamp = sl.writeLock();
        try { x = nx; y = ny; } finally { sl.unlockWrite(stamp); }
    }
}
