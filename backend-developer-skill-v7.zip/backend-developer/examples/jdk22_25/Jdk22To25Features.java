package examples.jdk22_25;

import java.util.*;
import java.util.stream.*;
import java.util.stream.Gatherer;
import java.util.stream.Gatherers;

/**
 * JDK 22–25 — Stream Gatherers, unnamed variables (final), flexible constructors,
 *              primitive patterns in switch, module imports, compact object headers
 *
 * SCENARIO GUIDE — when to use each pattern:
 *
 * Stream Gatherers vs pre-existing stream pipeline patterns
 *
 *   windowFixed(n) — non-overlapping batches
 *     BEFORE: group with AtomicInteger counter trick inside groupingBy; fragile and unreadable.
 *     USE WHEN: batch inserts, bulk API calls, chunked processing.
 *     Example: process 1000 records in batches of 50 → stream.gather(Gatherers.windowFixed(50))
 *
 *   windowSliding(n) — overlapping windows
 *     BEFORE: no clean way; required external state with ArrayDeque or subList loops.
 *     USE WHEN: moving average, anomaly detection over time series, n-gram generation.
 *     Example: 3-day moving average of prices → gather(windowSliding(3)).map(w -> avg(w))
 *
 *   scan(identity, fn) — running accumulation (keeps ALL intermediates)
 *     vs reduce(identity, fn) — reduces to ONE final value (intermediates discarded).
 *     USE scan WHEN: you need the running result at every step (cumulative sum, running max,
 *     balance ledger, progress percentage). reduce() loses the intermediates.
 *     Example: balance ledger: scan(0L, (bal, tx) -> bal + tx.amount())
 *
 *   fold(identity, fn) — same as reduce but as a Gatherer (composable in gather chain).
 *     USE WHEN: you want a single aggregated value but within a gather() pipeline that
 *     chains with other gatherers.
 *
 *   mapConcurrent(n, fn) — bounded parallel map preserving order
 *     BEFORE: CompletableFuture.allOf with manual list collect; order not guaranteed without
 *             extra bookkeeping.
 *     USE WHEN: calling a remote service per element with a concurrency cap (rate limiting,
 *     connection pool limit). Preserves encounter order. n = max in-flight at once.
 *     Example: enrich 500 users via API, max 10 concurrent → gather(mapConcurrent(10, enrichFn))
 *
 *   Custom Gatherer — when to write one
 *     USE WHEN: no built-in gatherer covers the stateful intermediate operation, AND it
 *     would be reused. Examples: deduplicate-by-key, emit-every-nth, group-by-run-length,
 *     zip-with-index, sliding pair (current + previous).
 *     ofSequential() — state is not shared across threads; safe and simpler.
 *     ofConcurrent() — state is thread-safe; needed only for parallel streams.
 *
 * Gatherers vs Collectors
 *   Collectors — TERMINAL: collapses stream to a final result (List, Map, String, count).
 *   Gatherers  — INTERMEDIATE: transforms stream into another stream (like map/filter/flatMap
 *                but with state). Chain multiple gatherers, then collect at the end.
 *   gather(g1).gather(g2).collect(c) — valid pipeline.
 *
 * Flexible constructor bodies (pre-super() statements, JDK 25)
 *   BEFORE: validation/normalization had to go AFTER super() — awkward, sometimes impossible
 *           if super() depended on the validated value.
 *   USE WHEN: subclass constructor must validate or transform args before passing to super().
 *   Common: Objects.requireNonNull(arg) + super(arg.strip()) — now possible in one constructor.
 *
 * Primitive patterns in switch (JDK 25 preview)
 *   BEFORE: switch on primitives required boxing to Object for type patterns.
 *   USE WHEN: routing on primitive int/long/double values with guard conditions.
 *   Eliminates: if (n < 0) ... else if (n == 0) ... else ... chains on primitives.
 *
 * Unnamed variable _ (JDK 22 final)
 *   USE WHEN: a variable is syntactically required but semantically unused.
 *   Key signal to readers: "this is intentionally ignored, not an oversight."
 *   catch (Exception _) — only acceptable for genuinely ignorable exceptions (log in prod).
 *   for (var _ : list)  — iterating for side effects (timer, counter, publish events).
 *   Lambda param: list.stream().map(_ -> generate()) — element ignored, value generated.
 */
public class Jdk22To25Features {

    // ═══════════════════════════════════════════════════════════════════════
    // Unnamed variables _ (JDK 22 final, JEP 456)
    // ═══════════════════════════════════════════════════════════════════════

    void unnamedVariables(List<String> items) {
        // Intentional unused loop variable
        int count = 0;
        for (var _ : items) count++;

        // Intentional swallow — _ documents the intent
        try {
            Integer.parseInt("not-a-number");
        } catch (NumberFormatException _) {
            // intentionally swallowed; return default
        }

        // Unused lambda parameter
        items.stream()
            .map(_ -> UUID.randomUUID().toString())   // discard element, generate new value
            .toList();

        // try-with-resources for side effect only
        // try (var _ = metrics.startTimer()) { doWork(); }
    }

    // ═══════════════════════════════════════════════════════════════════════
    // Stream Gatherers (JDK 24 final, JEP 485)
    // ═══════════════════════════════════════════════════════════════════════

    // Built-in Gatherers: window, scan, fold, mapConcurrent

    // ── windowFixed — non-overlapping batches ────────────────────────────────
    // BEFORE: complex stateful logic with AtomicInteger + groupingBy
    // AFTER:
    List<List<Integer>> batchOf3(List<Integer> nums) {
        return nums.stream()
            .gather(Gatherers.windowFixed(3))   // [0,1,2], [3,4,5], [6,7,8], [9] (last may be partial)
            .toList();
    }

    // ── windowSliding — overlapping windows ─────────────────────────────────
    List<List<Integer>> slidingWindow3(List<Integer> nums) {
        return nums.stream()
            .gather(Gatherers.windowSliding(3))  // [0,1,2], [1,2,3], [2,3,4], ...
            .toList();
    }

    // ── scan — running accumulation (like reduce but keeps all intermediates) ─
    List<Integer> runningSum(List<Integer> nums) {
        return nums.stream()
            .gather(Gatherers.scan(() -> 0, Integer::sum))  // [1, 3, 6, 10, 15, ...]
            .toList();
    }

    List<Double> movingAverageOf3(List<Double> vals) {
        return vals.stream()
            .gather(Gatherers.windowSliding(3))
            .map(w -> w.stream().mapToDouble(Double::doubleValue).average().orElse(0))
            .toList();
    }

    // ── fold — gatherer form of reduce (single result, as gatherer) ──────────
    Optional<String> concatenate(List<String> parts) {
        return parts.stream()
            .gather(Gatherers.fold(() -> "", (a, b) -> a + b))
            .findFirst();
    }

    // ── mapConcurrent — parallel map with bounded concurrency ────────────────
    // Preserves encounter order; limits concurrency to N in-flight tasks
    List<String> parallelEnrich(List<String> ids) {
        return ids.stream()
            .gather(Gatherers.mapConcurrent(4, id -> callRemoteService(id)))
            .toList();
    }

    // ── Custom Gatherer — stateful deduplication ──────────────────────────────
    // Gatherer<T (input), A (state), R (output)>
    static <T> Gatherer<T, Set<T>, T> distinctByEquality() {
        return Gatherer.ofSequential(
            HashSet::new,                           // initializer: state factory
            (seen, element, downstream) -> {        // integrator
                if (seen.add(element)) {            // add returns false if already present
                    return downstream.push(element);// push to next stage
                }
                return true;                        // true = continue, false = stop
            }
            // no combiner (sequential only), no finisher needed
        );
    }

    // ── Custom Gatherer — chunked processing with different output type ───────
    static Gatherer<String, ?, String> surroundWith(String prefix, String suffix) {
        return Gatherer.ofSequential(
            () -> new Object(),                         // unused state
            (_, element, downstream) ->
                downstream.push(prefix + element + suffix),
            (_, downstream) -> {}                       // finisher — nothing to flush
        );
    }

    // ── Custom Gatherer — stateful running max ────────────────────────────────
    static Gatherer<Integer, int[], Integer> runningMax() {
        return Gatherer.ofSequential(
            () -> new int[]{ Integer.MIN_VALUE },
            (state, element, downstream) -> {
                state[0] = Math.max(state[0], element);
                return downstream.push(state[0]);
            }
        );
    }

    // ── Gatherer chaining ────────────────────────────────────────────────────
    List<String> processChain(List<Integer> nums) {
        return nums.stream()
            .gather(Gatherers.windowSliding(3))      // sliding windows
            .map(w -> w.stream().mapToInt(Integer::intValue).sum())  // sum each window
            .gather(runningMax())                    // running max of sums
            .map(n -> "max=" + n)
            .toList();
    }

    // ═══════════════════════════════════════════════════════════════════════
    // Flexible Constructor Bodies (JEP 482 preview ~JDK 25)
    // ═══════════════════════════════════════════════════════════════════════

    // BEFORE: validation had to go into the body AFTER super(), awkward
    // AFTER:  statements before super()/this() are now legal

    static class ValidatedService extends BaseService {
        ValidatedService(String name, int timeout) {
            Objects.requireNonNull(name, "name");               // ← before super()
            if (timeout <= 0) throw new IllegalArgumentException("timeout > 0 required");
            super(name.strip(), timeout);                       // ← super() call
        }
    }

    static class BaseService {
        BaseService(String name, int timeout) {}
    }

    // ═══════════════════════════════════════════════════════════════════════
    // Primitive Types in Patterns (JEP 455 preview)
    // ═══════════════════════════════════════════════════════════════════════

    // BEFORE: Object o = 42; if (o instanceof Integer i) { int val = i; }
    // AFTER:
    String classifyPrimitive(Object obj) {
        return switch (obj) {
            case int i when i < 0   -> "negative int: " + i;
            case int i when i == 0  -> "zero";
            case int i              -> "positive int: " + i;
            case long l             -> "long: " + l;
            case float f            -> "float: %.3f".formatted(f);
            case double d           -> "double: %.6f".formatted(d);
            case byte b             -> "byte: " + b;
            case boolean b          -> "bool: " + b;
            default                 -> "other: " + obj.getClass().getSimpleName();
        };
    }

    // instanceof with primitive unboxing
    void primitiveInstanceof(Object obj) {
        if (obj instanceof int i) {      // unboxes Integer → int; false for null/non-Integer
            System.out.println("int value: " + i);
        }
        if (obj instanceof double d && d > 0) {
            System.out.println("positive double: " + d);
        }
    }

    // ═══════════════════════════════════════════════════════════════════════
    // String Gatherers — practical example combining features
    // ═══════════════════════════════════════════════════════════════════════

    // Process a CSV-like stream in batches and produce SQL inserts via text block
    List<String> csvToInserts(Stream<String> rows, int batchSize) {
        return rows
            .map(r -> r.split(","))
            .gather(Gatherers.windowFixed(batchSize))
            .map(batch -> {
                String values = batch.stream()
                    .map(cols -> "('%s', '%s')".formatted(cols[0].strip(), cols[1].strip()))
                    .collect(Collectors.joining(",\n       "));
                return """
                        INSERT INTO users (name, email)
                        VALUES %s
                        ON CONFLICT (email) DO NOTHING;
                        """.formatted(values);
            })
            .toList();
    }

    // stub
    String callRemoteService(String id) { return "result-" + id; }
    static String UUID.randomUUID() { return java.util.UUID.randomUUID().toString(); } // pseudo-import stub
}
