package examples.jdk7;

import java.io.*;
import java.nio.charset.StandardCharsets;
import java.nio.file.*;
import java.util.*;
import java.util.concurrent.*;

/**
 * JDK 7 — Project Coin + NIO.2
 * Every feature shown with before/after where applicable.
 *
 * SCENARIO GUIDE — when to use each pattern:
 *
 * try-with-resources
 *   USE WHEN: any resource implements AutoCloseable (streams, connections, readers, channels).
 *   Never write try/finally for cleanup — compiler does it correctly every time.
 *   Multiple resources in one try() closed in reverse order automatically.
 *
 * Multi-catch (IOException | SQLException)
 *   USE WHEN: two unrelated checked exceptions share identical handling logic.
 *   DO NOT use to swallow distinct exceptions that need different recovery paths.
 *
 * Diamond <>
 *   USE WHEN: always — never repeat the generic type on the RHS of a declaration.
 *
 * Numeric underscores (1_000_000)
 *   USE WHEN: any literal ≥ 5 digits. Prevents off-by-one-zero bugs in constants.
 *
 * NIO.2 (Path/Files) vs java.io.File
 *   USE Path/Files ALWAYS for new code. java.io.File: no charset support, boolean return codes
 *   instead of exceptions, no atomic operations, poor symlink handling.
 *   Files.walk() for directory traversal — lazy, stream-based, never loads full tree.
 *   Files.move(..., ATOMIC_MOVE) for safe rename — all-or-nothing.
 *
 * Fork/Join
 *   USE WHEN: divide-and-conquer over large data structures (sort, scan, reduce).
 *   DO NOT use for I/O-bound work — use virtual threads (JDK 21) instead.
 *   THRESHOLD tuning: benchmark; typically 1000–50000 elements per leaf task.
 *
 * ThreadLocalRandom vs Math.random() vs new Random()
 *   Math.random()   — calls a shared Random under the lock; contended in multi-thread.
 *   new Random()    — per-instance; safe but heavier; share across calls.
 *   ThreadLocalRandom — no lock, no sharing; use in any multi-threaded context.
 */
public class Jdk7Features {

    // ── Numeric literals ────────────────────────────────────────────────────
    static final int  CACHE_SIZE  = 1_000_000;
    static final int  FILE_MASK   = 0b0110_0100;   // rwxr--r-- in octal = 0644
    static final long MAX_BYTES   = 2_147_483_648L;

    // ── Diamond operator ────────────────────────────────────────────────────
    // BEFORE: Map<String, List<Integer>> map = new HashMap<String, List<Integer>>();
    // AFTER:
    Map<String, List<Integer>> index = new HashMap<>();

    // ── try-with-resources ──────────────────────────────────────────────────
    // BEFORE: InputStream in = null; try { in = ...; } finally { if (in!=null) in.close(); }
    // AFTER:
    String readFile(Path path) throws IOException {
        try (var reader = Files.newBufferedReader(path, StandardCharsets.UTF_8)) {
            var sb = new StringBuilder();
            String line;
            while ((line = reader.readLine()) != null) sb.append(line).append('\n');
            return sb.toString();
        }
        // reader.close() called automatically even on exception
    }

    // Multiple resources — closed in reverse declaration order
    void copyFile(Path src, Path dst) throws IOException {
        try (var in  = new FileInputStream(src.toFile());
             var out = new FileOutputStream(dst.toFile())) {
            in.transferTo(out);  // JDK11 — shown here for contrast
        }
    }

    // ── Multi-catch ─────────────────────────────────────────────────────────
    // BEFORE: } catch (IOException e) { wrap(e); } catch (SQLException e) { wrap(e); }
    // AFTER:
    void multiCatch(String path) {
        try {
            Class.forName(path);
            new FileInputStream(path).close();
        } catch (ClassNotFoundException | IOException e) {   // single handler, no duplication
            throw new RuntimeException("setup failed: " + e.getMessage(), e);
        }
    }

    // ── String switch ────────────────────────────────────────────────────────
    // BEFORE: if ("GET".equals(method)) { ... } else if ("POST".equals(method)) { ... }
    // AFTER:
    int httpMethodPriority(String method) {
        return switch (method) {        // switch expression — JDK14, shown for completeness
            case "GET", "HEAD"          -> 1;
            case "POST", "PUT", "PATCH" -> 2;
            case "DELETE"               -> 3;
            default                     -> 99;
        };
    }

    // ── Objects utility ──────────────────────────────────────────────────────
    record User(String name, String email) {
        User {
            Objects.requireNonNull(name,  "name must not be null");
            Objects.requireNonNull(email, "email must not be null");
        }

        @Override public boolean equals(Object o) {
            if (!(o instanceof User u)) return false;
            return Objects.equals(name, u.name) && Objects.equals(email, u.email);
        }

        @Override public int hashCode() {
            return Objects.hash(name, email);   // varargs, null-safe
        }

        @Override public String toString() {
            return "User[name=%s, email=%s]".formatted(name, email);
        }
    }

    // ── NIO.2 ────────────────────────────────────────────────────────────────
    void nioExamples() throws IOException {
        Path base = Path.of("data", "uploads");           // fluent path building
        Files.createDirectories(base);

        Path target = base.resolve("report.csv");
        Files.writeString(target, "id,name\n1,Alice\n"); // JDK11 — shown here

        long size = Files.size(target);
        boolean exists = Files.exists(target);

        // Walk directory tree
        try (var walk = Files.walk(base)) {
            walk.filter(Files::isRegularFile)
                .filter(p -> p.toString().endsWith(".csv"))
                .forEach(p -> System.out.println("Found: " + p));
        }

        // Atomic move (rename) — all-or-nothing
        Files.move(target, base.resolve("report_final.csv"), StandardCopyOption.ATOMIC_MOVE);

        // WatchService — filesystem events
        try (var watcher = FileSystems.getDefault().newWatchService()) {
            base.register(watcher, StandardWatchEventKinds.ENTRY_CREATE,
                                    StandardWatchEventKinds.ENTRY_MODIFY);
            WatchKey key = watcher.take();  // blocks
            for (var event : key.pollEvents()) {
                System.out.println("Event: " + event.kind() + " on " + event.context());
            }
        } catch (InterruptedException e) {
            Thread.currentThread().interrupt();
        }
    }

    // ── ThreadLocalRandom ────────────────────────────────────────────────────
    // BEFORE: Math.random(), new Random() — not thread-safe or contended
    // AFTER:
    int randomPort() {
        return ThreadLocalRandom.current().nextInt(1024, 65536);
    }

    // ── Fork/Join ────────────────────────────────────────────────────────────
    static class ParallelSum extends RecursiveTask<Long> {
        private static final int THRESHOLD = 10_000;
        private final long[] data;
        private final int from, to;

        ParallelSum(long[] data, int from, int to) {
            this.data = data; this.from = from; this.to = to;
        }

        @Override
        protected Long compute() {
            if (to - from <= THRESHOLD) {
                long sum = 0;
                for (int i = from; i < to; i++) sum += data[i];
                return sum;
            }
            int mid = (from + to) / 2;
            var left  = new ParallelSum(data, from, mid);
            var right = new ParallelSum(data, mid,  to);
            left.fork();                        // async left
            return right.compute() + left.join(); // sync right, then wait left
        }
    }

    long sumArray(long[] data) {
        return ForkJoinPool.commonPool().invoke(new ParallelSum(data, 0, data.length));
    }
}
