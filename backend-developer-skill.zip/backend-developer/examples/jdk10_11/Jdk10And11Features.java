package examples.jdk10_11;

import java.io.*;
import java.net.URI;
import java.net.http.*;
import java.nio.charset.StandardCharsets;
import java.nio.file.*;
import java.time.Duration;
import java.util.*;
import java.util.function.Predicate;
import java.util.regex.Pattern;
import java.util.stream.Stream;

/**
 * JDK 10 — var (local type inference)
 * JDK 11 — String methods, Files one-liners, HTTP Client, Predicate.not, InputStream additions
 */
public class Jdk10And11Features {

    // ═══════════════════════════════════════════════════════════════════════
    // JDK 10 — var
    // ═══════════════════════════════════════════════════════════════════════

    // ── var: use when RHS makes type obvious ─────────────────────────────────
    void varGoodUses() {
        var names    = new ArrayList<String>();               // obvious: ArrayList<String>
        var map      = new HashMap<String, List<Integer>>();  // avoids repeating generics
        var entries  = map.entrySet();                        // Set<Map.Entry<String,List<Integer>>>
        var iterator = entries.iterator();                    // Iterator<...>

        // var in for-each — idiomatic
        for (var entry : map.entrySet()) {
            System.out.println(entry.getKey() + " -> " + entry.getValue());
        }

        // var with complex generics: saves repetition without losing type info
        var stats = new TreeMap<String, Map<String, Long>>();

        // Effectively captures type from factory
        var ids = List.of("a", "b", "c");   // var = List<String>
    }

    // ── var: DON'T use when type is ambiguous ─────────────────────────────────
    void varBadUses() {
        // BAD — reader cannot tell type
        // var result = process();          ← what does process() return?
        // var flag   = check();            ← boolean? int? object?

        // PREFER explicit type when var obscures intent:
        boolean isValid = validate("input");   // intent clear
        int count       = getCount();          // primitive, short, clear

        // var IS OK here (type obvious from literal / constructor):
        var timeout = Duration.ofSeconds(30);  // var = Duration
        var sb      = new StringBuilder(256);  // var = StringBuilder
    }

    boolean validate(String s) { return !s.isBlank(); }
    int getCount() { return 0; }

    // ── JDK 10: defensive copy ────────────────────────────────────────────────
    record UserGroup(List<String> members) {
        UserGroup(List<String> members) {
            // copyOf = unmodifiable snapshot; throws NullPointerException if any element null
            this.members = List.copyOf(members);
        }
    }

    // ═══════════════════════════════════════════════════════════════════════
    // JDK 11 — String methods
    // ═══════════════════════════════════════════════════════════════════════

    // ── isBlank() — Unicode-aware (not just ASCII 0x20) ──────────────────────
    // BEFORE: s == null || s.trim().isEmpty()
    // AFTER:
    boolean hasContent(String s) {
        return s != null && !s.isBlank();
    }

    // ── strip() — Unicode whitespace (e.g. \u2000 stripped; trim() leaves it) ─
    String normalize(String input) {
        return input.strip();           // Unicode-aware; prefer over trim()
    }

    // ── lines() — Stream<String> without split overhead ──────────────────────
    // BEFORE: Arrays.stream(text.split("\\R"))  — regex, allocates array
    // AFTER:
    List<String> nonBlankLines(String text) {
        return text.lines()
            .filter(Predicate.not(String::isBlank))
            .map(String::strip)
            .toList();
    }

    long countLines(String text) {
        return text.lines().count();
    }

    // ── repeat() ─────────────────────────────────────────────────────────────
    String divider(int width) {
        return "-".repeat(width);
    }

    String indent(String text, int spaces) {
        return " ".repeat(spaces) + text;
    }

    // ── stripLeading / stripTrailing ─────────────────────────────────────────
    String trimStart(String s) { return s.stripLeading(); }
    String trimEnd(String s)   { return s.stripTrailing(); }

    // ═══════════════════════════════════════════════════════════════════════
    // JDK 11 — Files one-liners
    // ═══════════════════════════════════════════════════════════════════════

    // BEFORE: BufferedReader/FileReader + loop + close in finally
    // AFTER:
    String readConfig(Path path) throws IOException {
        return Files.readString(path, StandardCharsets.UTF_8);
    }

    void writeReport(Path path, String content) throws IOException {
        Files.writeString(path, content,
            StandardCharsets.UTF_8,
            StandardOpenOption.CREATE,
            StandardOpenOption.TRUNCATE_EXISTING);
    }

    void appendLog(Path path, String line) throws IOException {
        Files.writeString(path, line + System.lineSeparator(),
            StandardCharsets.UTF_8,
            StandardOpenOption.CREATE,
            StandardOpenOption.APPEND);
    }

    // ── Path.of() — replaces Paths.get() ────────────────────────────────────
    Path buildPath(String base, String sub, String file) {
        return Path.of(base, sub, file);   // same as Paths.get(base, sub, file), cleaner name
    }

    // ═══════════════════════════════════════════════════════════════════════
    // JDK 11 — Predicate.not()
    // ═══════════════════════════════════════════════════════════════════════

    // BEFORE: s -> !s.isEmpty()   or   s -> !s.isBlank()
    // AFTER:
    List<String> cleanList(List<String> raw) {
        return raw.stream()
            .filter(Predicate.not(String::isBlank))   // method ref negated cleanly
            .map(String::strip)
            .distinct()
            .sorted()
            .toList();
    }

    // Works with any Predicate, not just method refs
    Set<String> BLACKLIST = Set.of("admin", "root");

    List<String> filterBlacklist(List<String> users) {
        return users.stream()
            .filter(Predicate.not(BLACKLIST::contains))
            .toList();
    }

    // ═══════════════════════════════════════════════════════════════════════
    // JDK 11 — Collection.toArray(IntFunction)
    // ═══════════════════════════════════════════════════════════════════════

    // BEFORE: list.toArray(new String[0])   ← works but relies on runtime type
    // AFTER:
    String[] toStringArray(List<String> list) {
        return list.toArray(String[]::new);   // no cast, no new String[0] idiom
    }

    // ═══════════════════════════════════════════════════════════════════════
    // JDK 11 — InputStream additions
    // ═══════════════════════════════════════════════════════════════════════

    byte[] readAllBytes(InputStream in) throws IOException {
        return in.readAllBytes();                        // reads until EOF; auto-sizes buffer
    }

    byte[] readChunk(InputStream in, int size) throws IOException {
        return in.readNBytes(size);                      // reads exactly size bytes (or EOF)
    }

    long pipe(InputStream in, OutputStream out) throws IOException {
        return in.transferTo(out);                       // copies all bytes; returns count
    }

    // /dev/null equivalents — useful for testing / discarding output
    void discardOutput() throws IOException {
        try (var sink = OutputStream.nullOutputStream()) {
            sink.write("ignored".getBytes());
        }
    }

    Stream<String> emptyLineSource() {
        return new BufferedReader(new InputStreamReader(InputStream.nullInputStream())).lines();
    }

    // ═══════════════════════════════════════════════════════════════════════
    // JDK 11 — HTTP Client (completed from JDK 9 incubator)
    // ═══════════════════════════════════════════════════════════════════════

    static final HttpClient CLIENT = HttpClient.newBuilder()
        .connectTimeout(Duration.ofSeconds(5))
        .followRedirects(HttpClient.Redirect.NORMAL)
        .version(HttpClient.Version.HTTP_2)
        .build();

    // Sync request
    String syncGet(String url) throws IOException, InterruptedException {
        var req = HttpRequest.newBuilder(URI.create(url))
            .header("Accept", "application/json")
            .timeout(Duration.ofSeconds(10))
            .GET()
            .build();
        return CLIENT.send(req, HttpResponse.BodyHandlers.ofString()).body();
    }

    // Async request — non-blocking
    java.util.concurrent.CompletableFuture<Integer> asyncPost(String url, String json) {
        var req = HttpRequest.newBuilder(URI.create(url))
            .header("Content-Type", "application/json")
            .POST(HttpRequest.BodyPublishers.ofString(json))
            .build();
        return CLIENT.sendAsync(req, HttpResponse.BodyHandlers.discarding())
            .thenApply(HttpResponse::statusCode);
    }

    // ── Pattern.asMatchPredicate() ────────────────────────────────────────────
    // asPredicate()      → Matcher.find()    (partial match)
    // asMatchPredicate() → Matcher.matches() (full match)
    static final Pattern UUID_PATTERN =
        Pattern.compile("[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}");

    boolean isValidUuid(String s) {
        return UUID_PATTERN.asMatchPredicate().test(s);   // full-string match
    }

    List<String> filterUuids(List<String> tokens) {
        return tokens.stream()
            .filter(UUID_PATTERN.asMatchPredicate())
            .toList();
    }
}
