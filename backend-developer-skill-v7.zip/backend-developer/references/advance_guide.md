# Advanced Guide — Senior Developer / Architect Gotchas

Grammar sacrificed for concision. Every item is a production-proven trap.

---

## Memory & GC Pressure

**1. Stream on small collections — overkill**
`Spliterator` alloc + lambda capture + internal boxing costs MORE than for-each under ~10 elements.
Stream infra pays off at volume. For tiny lists: plain loop, zero overhead.

**2. Autoboxing in loops — silent GC killer**
`Long sum = 0L; sum += value` → new `Long` object per iteration.
1M iterations = 1M allocations → Eden fills → frequent Minor GC → Stop-The-World pauses.
Fix: use `long sum = 0L` (primitive). Use `LongStream` / `IntStream` in stream pipelines.

**3. `String +=` in loop — exponential heap growth**
Each `+=` allocates a new `String`; grows O(n²). JIT does NOT optimise `+=` inside loops.
Fix: `StringBuilder` (linear). Rule: any string building inside a loop → `StringBuilder`.

**4. `String.format()` on hot path — slowest concat**
Parses format string via regex-like engine on every call. Benchmarks: slowest of all concat methods.
Fix: `StringBuilder.append()` on hot path. `String.format()` / `.formatted()` fine for cold paths (logs, errors).

**5. `static` collection that grows forever — GC root leak**
`static Map<String, Object> cache = new HashMap<>()` is a GC root; entries never collected.
JVM heap climbs slowly, never recovers. Fix: bounded cache with LRU eviction or `WeakHashMap`.

**6. Non-static inner class holds outer reference**
Non-static inner class carries implicit `OuterClass.this` reference → outer never GC'd even when unused.
Fix: make inner class `static` if it doesn't need outer state.

**7. `String.intern()` on external data — string pool bloat**
Interning DB values / user input fills string pool with unbounded unique entries → `OutOfMemoryError`.
`intern()` only on a controlled, finite set of known strings (e.g. enum-like codes).

---

## Resource Leaks

**8. `Files.walk()` and `Files.lines()` — silent file handle leak**
Both return `Stream<T>` that wraps an OS file descriptor. Not closing = descriptor leak.
Eventually: `Too many open files` crash. Fix: always `try (var s = Files.walk(path)) { ... }`.

**9. `Files.list()` — same leak vector**
Returns `DirectoryStream` wrapped in `Stream`. Same rule: must close. Always try-with-resources.

**10. `ThreadLocal` not removed in thread pool — slow memory leak**
Tomcat/Jetty reuse threads. `ThreadLocal` set per request, never `.remove()`'d → request-scoped
objects live for thread lifetime. Heap climbs imperceptibly over days. Fix: `finally { tl.remove(); }`.
Better: replace with `ScopedValue` (JDK 21+) — bounded lifetime by design, can't leak.

**11. `ExecutorService` never shut down**
Threads stay alive → JVM won't exit in tests → resource leak in production.
Fix: `exec.shutdown()` in `finally` or use try-with-resources (`ExecutorService` is `AutoCloseable` JDK 19+).

**12. `HttpClient` / `Connection` / `ResultSet` not closed**
Connection pool exhausts under load. App freezes waiting for a connection that never returns.
Fix: always try-with-resources. Never rely on GC to close connections.

---

## Correctness Traps

**13. Mutable object as `HashMap` key**
Key mutated after insertion → `hashCode()` changes → entry permanently lost (unreachable + un-removable).
Fix: use only immutable objects as map keys. Records are ideal map keys.

**14. Override `equals()` without `hashCode()`**
Objects that are `equals()` MUST have same `hashCode()`. Violation → `HashSet` stores duplicates,
`HashMap` loses entries silently. Fix: always override both. Records do this correctly automatically.

**15. `float`/`double` equality with `==` or `.equals()`**
`0.1 + 0.2 != 0.3` due to IEEE 754. `.equals()` on `Double` has same problem.
Fix: `Math.abs(a - b) < EPSILON` for tolerance checks. `BigDecimal` for financial values.

**16. `synchronized` with virtual threads — carrier pin**
`synchronized` block pins carrier OS thread while virtual thread waits for monitor.
Other virtual threads starve. Fix: replace `synchronized` with `ReentrantLock` throughout.
Detect: JFR event `jdk.VirtualThreadPinned`.

**17. Exception swallowed in `Runnable` / `Callable`**
Exception thrown inside `executor.submit(runnable)` vanishes unless `future.get()` is called.
Tasks appear to succeed silently. Fix: always call `future.get()` or wrap with logging in the task.

**18. `catch (Exception e) {}` — silent swallow**
Hides real bugs; task appears to succeed. At minimum: `log.error("...", e)`.
Better: translate to domain exception and rethrow. Never swallow without a documented reason.

**19. `Optional.get()` without `isPresent()`**
`NoSuchElementException` at runtime. Sonar S2471.
Fix: `orElseThrow()` always. Never call `.get()` naked.

**20. `parallelStream()` misuse**
Uses `ForkJoinPool.commonPool()` — shared across entire JVM. Blocking I/O in parallel stream
starves all other pool users. Parallel overhead only pays off for CPU-bound ops on > ~10k elements.
For I/O-bound: use virtual threads, not `parallelStream()`.

---

## Hot Path / Static Constants

**21. `Pattern.compile()` per call — NFA/DFA rebuilt every time**
Allocates full automaton on every invocation. Called per-request on a busy service = constant alloc.
Fix: `private static final Pattern P = Pattern.compile("...");` — compile once, reuse forever.
Same applies to `String.split("regex")` in loops — extract to `static final Pattern`.

**22. `new DateTimeFormatter` per call**
`DateTimeFormatter` is thread-safe; building it is not cheap. Fix: `static final` field.

**23. `new ObjectMapper()` per request (Jackson)**
One of the most expensive objects in the JVM to instantiate; builds full type cache.
Fix: singleton Spring bean or `private static final ObjectMapper MAPPER = new ObjectMapper()`.

**24. `new Random()` per call**
Seed initialisation overhead + contention. Fix: `ThreadLocalRandom.current()` — lock-free, per-thread.

**25. `LoggerFactory.getLogger(...)` per method**
Should be `private static final Logger log = LoggerFactory.getLogger(MyClass.class)`.
Per-call lookup wastes time and creates objects; also loses class-level context.

**26. Repeated `String.split("regex")` inside loop**
Recompiles regex pattern every call. Fix: `static final Pattern P = ...; P.split(str)` in the loop.

---

## Null Discipline

**27. Null checks deep in business logic — expensive NPEs**
NPE deep in call stack = expensive stack trace allocation + hard to diagnose source.
Fix: validate at entry point — constructor / service method boundary — with `Objects.requireNonNull`.
Null should never travel deep; fail fast at the boundary.

**28. Returning `null` instead of `Optional` or throwing**
Forces callers to guess whether null is possible. Missed null check = NPE far from source.
Fix: `Optional<T>` for expected absence; throw for contract violations. Never return `null` from
public API methods.

**29. `null` in `List.of` / `Set.of` / `Map.of`**
These factories are null-hostile — throw `NullPointerException` immediately.
Not obvious to callers. Fix: document null-hostility; use `List.copyOf` with a pre-filtered source
if nulls are possible.

---

## Concurrency

**30. `HashMap` in multi-threaded context**
Not thread-safe. Concurrent structural modification → infinite loop (JDK < 8) or data corruption (JDK 8+).
Fix: `ConcurrentHashMap`. No global lock — segment-level locking for writes, lock-free for reads.

**31. `StringBuffer` instead of `StringBuilder`**
`StringBuffer` synchronises every method — unnecessary for local string building (never shared).
Fix: always `StringBuilder` for local use. `StringBuffer` only if you genuinely share across threads
(extremely rare).

**32. `new Thread()` directly instead of `ExecutorService`**
No lifecycle control, no rejection policy, no monitoring, no graceful shutdown.
Fix: `Executors.newVirtualThreadPerTaskExecutor()` (JDK 21+) or a managed thread pool.

**33. Compound check-then-act without atomicity**
`if (!map.containsKey(k)) map.put(k, v)` is a race in concurrent code — gap between check and put.
Fix: `map.putIfAbsent(k, v)` or `map.computeIfAbsent(k, factory)` — atomic single operation.

**34. `volatile` misunderstood as synchronisation**
`volatile` guarantees visibility only, not atomicity. `volatile int count++` is still a race
(read-modify-write is 3 operations). Fix: `AtomicInteger` for single counter, `LongAdder` for
high-contention counter, `ReentrantLock` for compound actions.

---

## JPA / Hibernate

**35. N+1 query inside loop**
`for (Order o : orders) { o.getItems(); }` → 1 query for orders + N queries for items = N+1 DB round trips.
Fix: `JOIN FETCH` in `@Query` or `@EntityGraph(attributePaths = {"items"})` on repository method.
Rule: if calling a lazy association inside a loop, you have N+1. Profile with Hibernate statistics or p6spy.

**36. Full entity load for read-only views**
Full entity = all columns + first-level cache entry + dirty-check overhead per flush.
For list/search/report endpoints none of that matters. Fix: interface projection or record projection
via `@Query SELECT new ...`. Lighter, faster, no cache overhead.

**37. `@Transactional` on private method**
Spring AOP proxy intercepts only `public` method calls from outside the bean.
Private method = proxy bypassed = transaction silently not applied. No error at startup.
Fix: must be `public` and called from a different bean (or use AspectJ weaving).

**38. `readOnly = false` as default transaction**
`@Transactional` default is `readOnly = false` → Hibernate runs dirty-check on every flush,
no read-replica routing. Fix: annotate class with `@Transactional(readOnly = true)`;
override mutating methods with `@Transactional` (inherits `readOnly = false`).

**39. `CascadeType.REMOVE` on large collections**
Deletes each child one by one in separate SQL DELETE statements. 10,000 children = 10,000 DELETEs.
Fix: JPQL bulk delete `DELETE FROM Item i WHERE i.order = :order` or native query. One statement.

---

## Logging

**40. String concat in disabled log statement**
`log.debug("Processing: " + obj.toString())` — string built even when DEBUG is off.
Fix: `log.debug("Processing: {}", obj)` — SLF4J parameterised; string built only if level enabled.
In hot paths: guard with `if (log.isDebugEnabled())` for expensive `toString()` calls.

**41. Logging inside tight loop**
One log call per element in a loop of millions = massive I/O pressure + GC from message objects.
Fix: aggregate result, log once after loop. Or log every Nth iteration with `if (i % 1000 == 0)`.

---

## Spring-specific

**42. Prototype bean injected into singleton**
Spring injects prototype once at singleton creation — same instance reused forever.
Defeats the purpose of prototype scope. No error at startup.
Fix: inject `ObjectFactory<MyBean> factory`; call `factory.getObject()` per use. Or `@Lookup`.

**43. `@Autowired` on static field**
Spring doesn't inject static fields — field stays `null` at runtime. No startup error.
Fix: use constructor injection. Static fields and Spring DI don't mix.

**44. Missing `@EnableConfigurationProperties`**
`@ConfigurationProperties` class silently ignored — all fields null or default. No error.
Fix: add `@EnableConfigurationProperties(MyConfig.class)` on a `@Configuration` class,
or annotate the config class itself with `@ConfigurationPropertiesScan` target.
