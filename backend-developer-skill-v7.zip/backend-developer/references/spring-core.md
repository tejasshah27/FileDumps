# Spring Boot — Core (Services, DI, Configuration, Events, Beans)

## Dependency Injection — always constructor injection

```java
@Service
public class OrderService {
    private final OrderRepository     repo;
    private final PaymentGateway      gateway;
    private final ApplicationEventPublisher events;

    // Constructor injection — explicit, testable, immutable, no Spring context needed in tests
    OrderService(OrderRepository repo, PaymentGateway gateway, ApplicationEventPublisher events) {
        this.repo    = repo;
        this.gateway = gateway;
        this.events  = events;
    }
}
```

**Never:**
- `@Autowired` on fields — untestable without Spring context, hides dependencies, Sonar S3016
- `@Autowired` on static fields — Spring doesn't inject static fields; stays `null` silently
- Setter injection for required dependencies — use only for optional dependencies

---

## Configuration — `@ConfigurationProperties` + record

```java
// Group related properties; validated at startup; injected where needed
@ConfigurationProperties(prefix = "app.payment")
record PaymentConfig(
    @NotBlank String apiKey,
    @NotNull URI endpoint,
    @Positive int maxRetries,
    @NotNull Duration timeout
) {}

// Register — one of:
@EnableConfigurationProperties(PaymentConfig.class)   // explicit on @Configuration class
// OR in main class / @ConfigurationPropertiesScan on package

// Inject as constructor param
@Service
class PaymentService {
    PaymentService(PaymentConfig config) { ... }
}
```

**`@ConfigurationProperties` vs `@Value`:**
- `@ConfigurationProperties` — group of related props; validated at startup; record is ideal
- `@Value` — single isolated property; SpEL expressions; legacy integration

Missing `@EnableConfigurationProperties` = config class silently ignored; all fields null. No startup error.

---

## Service layer patterns

```java
@Service
@Transactional(readOnly = true)     // class-level default; read-only = skip dirty check
public class OrderService {

    @Transactional                   // override for writes
    public OrderResponse create(CreateOrderRequest req) {
        Objects.requireNonNull(req, "request");

        var order = new Order(req.customerId(), req.amountCents());
        var saved = repo.save(order);

        // Publish domain event — decouples side effects (email, audit, cache invalidation)
        events.publishEvent(new OrderCreatedEvent(saved.getId(), saved.getCustomerId()));

        return OrderResponse.from(saved);
    }

    @Transactional
    public OrderResponse confirm(UUID id) {
        var order = repo.findById(id)
            .orElseThrow(() -> new NotFoundException("Order not found: " + id));
        order.confirm();      // state transition on entity
        // no explicit save — Hibernate dirty-check flushes on transaction commit
        events.publishEvent(new OrderConfirmedEvent(order.getId()));
        return OrderResponse.from(order);
    }
}
```

---

## Domain events

```java
// Event as record — immutable, carries all context
record OrderCreatedEvent(UUID orderId, String customerId, Instant occurredAt) {
    OrderCreatedEvent(UUID orderId, String customerId) {
        this(orderId, customerId, Instant.now());
    }
}

// Listener — runs in same transaction by default
@EventListener
void onOrderCreated(OrderCreatedEvent event) { sendConfirmationEmail(event.customerId()); }

// @TransactionalEventListener — runs AFTER transaction commits (safe for post-commit side effects)
@TransactionalEventListener(phase = TransactionPhase.AFTER_COMMIT)
void onOrderCreated(OrderCreatedEvent event) { sendEmail(event.customerId()); }
// If email fails, order is already saved — consider outbox pattern for at-least-once delivery
```

Use events when: action triggers side effects in other subsystems (email, audit, cache) without
tight coupling. Primary transaction stays independent of side effects.

---

## Prototype bean in singleton — common gotcha

```java
// BAD — Spring injects prototype once at singleton creation; same instance reused forever
@Service
class ReportService {
    @Autowired private ReportBuilder builder;   // prototype injected once = pointless
}

// GOOD — get a new instance per use
@Service
class ReportService {
    private final ObjectFactory<ReportBuilder> builderFactory;

    ReportService(ObjectFactory<ReportBuilder> factory) { this.builderFactory = factory; }

    void generate() {
        ReportBuilder builder = builderFactory.getObject();   // fresh instance each call
        builder.build();
    }
}
```

---

## Virtual threads — Spring Boot 3.2+

```properties
# application.properties — one property applies globally
spring.threads.virtual.enabled=true
```
Automatically applies to: Tomcat request threads, `@Async` executor, `@Scheduled` tasks,
`TaskExecutor`, `SimpleAsyncTaskExecutor`.

---

## Async and scheduling

```java
// @Async — fire-and-forget; returns CompletableFuture for callers that need result
@Async
CompletableFuture<Void> sendEmailAsync(String to, String body) {
    emailService.send(to, body);
    return CompletableFuture.completedFuture(null);
}

// @Scheduled — cron or fixed delay/rate
@Scheduled(cron = "0 0 2 * * *")              // 2 AM every day
@Scheduled(fixedDelay = 60_000)               // 60s after last completion
@Scheduled(fixedRate = 30_000)                // every 30s regardless of duration
void archiveOldOrders() { ... }
```

Enable: `@EnableAsync` and `@EnableScheduling` on a `@Configuration` class or main class.

---

## @Bean scope decisions

| Scope | When |
|---|---|
| `singleton` (default) | Stateless service / repository / client — always prefer |
| `prototype` | Stateful builder / parser that must not be shared across threads |
| `request` | Request-scoped data (Spring MVC only) |
| `session` | User session state (Spring MVC only) |

Prototype in singleton = subtle bug (see gotcha above).
Spring `@Bean` configured with wrong scope = new bean per request when singleton intended = memory pressure.

---

See also: `examples/springboot/OrderServiceStack.java`

---

## Caching — Spring Cache Abstraction

Enable caching once on a `@Configuration` class (or the main class):

```java
@EnableCaching
@SpringBootApplication
public class Application { ... }
```

### Core annotations

```java
@Service
@CacheConfig(cacheNames = "orders")   // default cache name for all methods in this class
@Transactional(readOnly = true)
public class OrderService {

    // @Cacheable — cache the return value; skip method body on cache hit
    // key uses Spring EL: #id is the method parameter
    @Cacheable(key = "#id")
    public OrderResponse findById(UUID id) {
        return repo.findById(id).map(OrderResponse::from)
            .orElseThrow(() -> new NotFoundException("Order not found: " + id));
    }

    // @CachePut — always runs the method AND updates the cache
    // Use after a write so the cache reflects the new state immediately
    @Transactional
    @CachePut(key = "#result.id()")    // #result refers to the returned value
    public OrderResponse confirm(UUID id) {
        var order = repo.findById(id).orElseThrow();
        order.confirm();
        return OrderResponse.from(order);
    }

    // @CacheEvict — remove entry (or all entries) from cache on write/delete
    @Transactional
    @CacheEvict(key = "#id")
    public void cancel(UUID id) { ... }

    // allEntries = true — flush the entire cache (use for bulk mutations)
    @Transactional
    @CacheEvict(allEntries = true)
    public void cancelAll(String customerId) { ... }

    // Conditional caching — only cache when condition is true
    // condition evaluated before method; unless evaluated after (can inspect #result)
    @Cacheable(key = "#id", condition = "#id != null", unless = "#result == null")
    public OrderResponse findByIdOrNull(UUID id) { ... }

    // Multiple caches — evict from both at once
    @Caching(evict = {
        @CacheEvict(cacheNames = "orders",  key = "#id"),
        @CacheEvict(cacheNames = "summaries", allEntries = true)
    })
    public void delete(UUID id) { ... }
}
```

---

### Cache provider configuration

**Caffeine (in-process, recommended for single-node or read-heavy)**

```xml
<!-- pom.xml -->
<dependency>
    <groupId>com.github.ben-manes.caffeine</groupId>
    <artifactId>caffeine</artifactId>
</dependency>
```

```properties
# application.properties
spring.cache.type=caffeine
# maximumSize: evict LRU entries beyond this count
# expireAfterWrite: TTL from write time (safest default)
# expireAfterAccess: TTL resets on read (risks stale data if rarely-evicted)
spring.cache.caffeine.spec=maximumSize=1000,expireAfterWrite=5m
```

```java
// Per-cache TTL (different caches, different TTLs)
@Bean
public CacheManagerCustomizer<CaffeineCacheManager> caffeineCacheCustomizer() {
    return manager -> {
        manager.registerCustomCache("orders",
            Caffeine.newBuilder().maximumSize(500).expireAfterWrite(5, MINUTES).build());
        manager.registerCustomCache("summaries",
            Caffeine.newBuilder().maximumSize(2000).expireAfterWrite(1, MINUTES).build());
    };
}
```

**Redis (distributed, recommended for multi-node / session-shared data)**

```properties
spring.cache.type=redis
spring.data.redis.host=localhost
spring.data.redis.port=6379
spring.cache.redis.time-to-live=5m
spring.cache.redis.key-prefix=myapp:
spring.cache.redis.use-key-prefix=true
```

---

### Cache key design rules

```java
// Default key — Spring uses all parameters combined; fine for 1-2 params
@Cacheable                            // key = all params
@Cacheable(key = "#id")               // single param
@Cacheable(key = "#req.customerId() + ':' + #req.status()")   // compound

// KeyGenerator — for complex or shared key logic
@Bean
public KeyGenerator orderKeyGen() {
    return (target, method, params) ->
        Arrays.stream(params).map(Object::toString).collect(joining(":"));
}
@Cacheable(keyGenerator = "orderKeyGen")
```

**Key rules:**
- Never use mutable objects or objects without a stable `toString()` as key components
- For Redis: always set `key-prefix` to avoid cross-service collisions
- For compound keys: join with a delimiter that cannot appear in the values (`:` is conventional)

---

### Cache vs no-cache decision

| Use cache when | Skip cache when |
|---|---|
| Data is read far more than written | Data changes frequently (high write rate) |
| Computation or DB query is expensive | Data is cheap to re-fetch |
| Slight staleness is acceptable | Strict consistency is required |
| Single node or shared cache (Redis) | Each node has independent state needs |
| Result is deterministic per key | Result depends on caller context (user-specific) |

**Gotchas:**
- `@Cacheable` on a `@Transactional` method reads from cache *before* the transaction opens — stale reads are possible after a rollback
- `@CacheEvict` runs *after* the method by default (`beforeInvocation = false`); if the method throws, eviction does NOT happen
- Self-invocation (`this.findById(id)` from the same class) bypasses the cache proxy — same as `@Transactional` on private methods; call through a separate bean or use AspectJ
- Serialization: all cached objects must be serializable when using Redis; records and standard JDK types are safe; third-party types may need a custom `RedisSerializer`
