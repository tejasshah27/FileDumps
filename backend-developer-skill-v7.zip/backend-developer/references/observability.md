# Observability — Micrometer, Actuator, Logging, Correlation

Read this file when adding metrics, health checks, structured logging, or distributed tracing
to any Spring Boot service.

Cross-reference: `spring-core.md` · `concurrency.md` (ScopedValue for correlation)

---

## Table of Contents

1. [Micrometer — metric types](#micrometer--metric-types)
2. [@Timed annotation](#timed-annotation)
3. [Custom HealthIndicator](#custom-healthindicator)
4. [Actuator endpoint exposure](#actuator-endpoint-exposure)
5. [Correlation ID — MDC and ScopedValue](#correlation-id--mdc-and-scopedvalue)
6. [Structured logging with Logback](#structured-logging-with-logback)
7. [JFR events (custom application events)](#jfr-events-custom-application-events)
8. [Observability decision table](#observability-decision-table)

---

## Micrometer — metric types

`MeterRegistry` is the single entry point for all metric registration. Inject it via constructor.

```java
@Service
public class OrderService {

    private final MeterRegistry meters;
    private final Counter ordersCreated;
    private final Counter ordersFailed;
    private final Timer  orderLatency;
    private final DistributionSummary orderAmounts;
    private final AtomicLong activeOrders;

    OrderService(MeterRegistry meters, /* other deps */ ...) {
        this.meters = meters;

        // Counter — monotonically increasing; use for counting discrete events
        this.ordersCreated = Counter.builder("orders.created")
            .description("Total orders successfully created")
            .tag("region", "eu-west")        // tags create label dimensions
            .register(meters);

        this.ordersFailed = Counter.builder("orders.failed")
            .description("Total order creation failures")
            .register(meters);

        // Timer — records call count + total time + max; used for latency
        this.orderLatency = Timer.builder("orders.create.latency")
            .description("Time to create an order end-to-end")
            .publishPercentiles(0.5, 0.95, 0.99)       // p50, p95, p99 in Prometheus
            .publishPercentileHistogram()               // histograms for Grafana heatmaps
            .sla(Duration.ofMillis(100), Duration.ofMillis(500))  // SLO boundaries
            .register(meters);

        // DistributionSummary — records distribution of a value (not time)
        this.orderAmounts = DistributionSummary.builder("orders.amount.cents")
            .description("Distribution of order amounts in cents")
            .publishPercentiles(0.5, 0.95, 0.99)
            .register(meters);

        // Gauge — tracks current state (queue depth, cache size, active connections)
        // Gauge holds a WEAK reference to the object — keep a strong ref yourself
        this.activeOrders = new AtomicLong(0);
        Gauge.builder("orders.active", activeOrders, AtomicLong::get)
            .description("Current number of orders in PENDING state")
            .register(meters);
    }

    public OrderResponse create(CreateOrderRequest req) {
        return orderLatency.record(() -> {          // Timer.record wraps the call
            try {
                var order = new Order(req.customerId(), req.amountCents());
                var saved = repo.save(order);
                ordersCreated.increment();
                orderAmounts.record(req.amountCents());
                activeOrders.incrementAndGet();
                events.publishEvent(new OrderCreatedEvent(saved.getId(), saved.getCustomerId()));
                return OrderResponse.from(saved);
            } catch (Exception ex) {
                ordersFailed.increment();
                throw ex;
            }
        });
    }
}
```

**Tag (label) rules:**
- Tags must have **bounded cardinality** — never use user IDs, order IDs, or free-text as tag values. Each unique tag value creates a new time series; high-cardinality tags explode storage.
- Good tags: `region`, `status`, `service`, `version`, `method` (HTTP)
- Bad tags: `userId`, `orderId`, `email`, any UUID

---

## @Timed annotation

For simple method-level timing without manual Timer code. Requires an `AspectJ` or `TimedAspect` bean.

```java
// Register the aspect (once per application)
@Bean
TimedAspect timedAspect(MeterRegistry registry) {
    return new TimedAspect(registry);
}

// Annotate any Spring-managed method
@Service
public class ReportService {

    @Timed(
        value       = "reports.generate.latency",
        description = "Time to generate a report",
        percentiles = {0.5, 0.95, 0.99},
        extraTags   = {"report_type", "summary"}
    )
    public Report generate(ReportRequest req) { ... }
}
```

**When `@Timed` vs manual `Timer`:**
- `@Timed` — simple, declarative; good for single-method timing with static tags
- Manual `Timer.record(...)` — needed when tags depend on the result or exception, or for conditional timing

---

## Custom HealthIndicator

Expose custom health signals through Spring Actuator's `/actuator/health` endpoint.

```java
// Simple health check — checks an external dependency
@Component
public class PaymentGatewayHealthIndicator implements HealthIndicator {

    private final PaymentGatewayClient client;

    PaymentGatewayHealthIndicator(PaymentGatewayClient client) {
        this.client = client;
    }

    @Override
    public Health health() {
        try {
            var pingResult = client.ping();
            if (pingResult.isOk()) {
                return Health.up()
                    .withDetail("latencyMs", pingResult.latencyMs())
                    .withDetail("region",    pingResult.region())
                    .build();
            }
            return Health.down()
                .withDetail("reason", pingResult.errorMessage())
                .build();
        } catch (Exception ex) {
            return Health.down(ex).build();
        }
    }
}

// Reactive health check (for WebFlux or async dependencies)
@Component
public class RedisHealthIndicator implements ReactiveHealthIndicator {

    private final ReactiveRedisConnectionFactory factory;

    @Override
    public Mono<Health> health() {
        return factory.getReactiveConnection()
            .serverCommands()
            .ping()
            .map(pong -> Health.up().withDetail("pong", pong).build())
            .onErrorReturn(Health.down().build());
    }
}
```

**Health response groups** — expose different subsets to different audiences:
```properties
# application.properties
management.endpoint.health.group.readiness.include=db,redis
management.endpoint.health.group.liveness.include=ping
# Kubernetes probes map to: /actuator/health/liveness and /actuator/health/readiness
```

---

## Actuator endpoint exposure

By default, only `/actuator/health` is exposed over HTTP. Explicitly opt-in to others.

```properties
# Expose specific endpoints (prefer explicit allowlist over "*")
management.endpoints.web.exposure.include=health,info,metrics,prometheus,loggers,env
management.endpoints.web.exposure.exclude=shutdown,heapdump,threaddump  # never expose in prod

# Health details — show full details only to authenticated users (or always in dev)
management.endpoint.health.show-details=when-authorized
# management.endpoint.health.show-details=always  ← only for dev/staging

# Separate management port — keeps ops endpoints off the public port
management.server.port=8081

# Metrics endpoint format — Prometheus scrape
management.prometheus.metrics.export.enabled=true

# Info endpoint — show build and git info
management.info.build.enabled=true
management.info.git.enabled=true
management.info.git.mode=full
```

```xml
<!-- pom.xml — Prometheus registry -->
<dependency>
    <groupId>io.micrometer</groupId>
    <artifactId>micrometer-registry-prometheus</artifactId>
</dependency>
```

---

## Correlation ID — MDC and ScopedValue

A correlation / trace ID flows through every log line for a request, enabling log aggregation across services.

### MDC approach (Spring MVC with platform threads)

```java
// Filter — sets MDC at entry, removes at exit
@Component
@Order(Ordered.HIGHEST_PRECEDENCE)
public class CorrelationIdFilter extends OncePerRequestFilter {

    private static final String HEADER = "X-Correlation-Id";
    private static final String MDC_KEY = "correlationId";

    @Override
    protected void doFilterInternal(HttpServletRequest req,
                                    HttpServletResponse res,
                                    FilterChain chain) throws ServletException, IOException {
        var id = Optional.ofNullable(req.getHeader(HEADER))
                         .orElseGet(() -> UUID.randomUUID().toString());
        MDC.put(MDC_KEY, id);
        res.setHeader(HEADER, id);                   // echo back so caller can correlate
        try {
            chain.doFilter(req, res);
        } finally {
            MDC.clear();                             // MUST clear — thread returns to pool
        }
    }
}
```

```xml
<!-- logback-spring.xml — include MDC value in every log line -->
<pattern>%d{ISO8601} [%X{correlationId}] %-5level %logger{36} - %msg%n</pattern>
```

### ScopedValue approach (JDK 21+ virtual threads)

When `spring.threads.virtual.enabled=true`, MDC can leak between virtual threads if carriers are reused with context attached. `ScopedValue` is the correct replacement: bounded by the scope block, auto-inherited by child virtual threads.

```java
public class RequestContext {
    static final ScopedValue<String> CORRELATION_ID = ScopedValue.newInstance();

    static String correlationId() {
        return CORRELATION_ID.isBound() ? CORRELATION_ID.get() : "unset";
    }
}

// In the filter
var id = Optional.ofNullable(req.getHeader("X-Correlation-Id"))
                 .orElseGet(() -> UUID.randomUUID().toString());
res.setHeader("X-Correlation-Id", id);

ScopedValue.where(RequestContext.CORRELATION_ID, id).run(() -> chain.doFilter(req, res));
// Automatically cleared when the run() block exits — no finally required

// In log pattern — call RequestContext.correlationId() from a custom converter
// Or bridge to MDC for Logback compatibility:
ScopedValue.where(RequestContext.CORRELATION_ID, id).run(() -> {
    MDC.put("correlationId", id);
    try { chain.doFilter(req, res); } finally { MDC.remove("correlationId"); }
});
```

---

## Structured logging with Logback

Structured (JSON) logs are parsed by log aggregators (Loki, Splunk, Datadog) without regex.

```xml
<!-- pom.xml -->
<dependency>
    <groupId>net.logstash.logback</groupId>
    <artifactId>logstash-logback-encoder</artifactId>
    <version>7.4</version>
</dependency>
```

```xml
<!-- logback-spring.xml -->
<configuration>
    <springProfile name="prod">
        <appender name="JSON" class="ch.qos.logback.core.ConsoleAppender">
            <encoder class="net.logstash.logback.encoder.LogstashEncoder">
                <includeContext>false</includeContext>
                <fieldNames>
                    <timestamp>@timestamp</timestamp>
                    <message>message</message>
                    <level>severity</level>
                </fieldNames>
                <!-- Include all MDC fields automatically -->
                <includeMdcKeyName>correlationId</includeMdcKeyName>
            </encoder>
        </appender>
        <root level="INFO"><appender-ref ref="JSON"/></root>
    </springProfile>

    <springProfile name="!prod">
        <appender name="CONSOLE" class="ch.qos.logback.core.ConsoleAppender">
            <encoder>
                <pattern>%d{HH:mm:ss.SSS} [%X{correlationId}] %-5level %logger{36} - %msg%n</pattern>
            </encoder>
        </appender>
        <root level="DEBUG"><appender-ref ref="CONSOLE"/></root>
    </springProfile>
</configuration>
```

**Structured log events (key-value pairs beyond MDC):**
```java
// SLF4J 2.x fluent API — key-value pairs attached to a single log event
log.atInfo()
   .addKeyValue("orderId",    orderId)
   .addKeyValue("customerId", customerId)
   .addKeyValue("amountCents", amountCents)
   .log("Order created");
// JSON output: {"message":"Order created","orderId":"...","customerId":"...","amountCents":5000}
```

---

## JFR events (custom application events)

Java Flight Recorder events are zero-overhead when disabled, microsecond-overhead when enabled. Use for high-frequency internal instrumentation that would be too expensive with Micrometer.

```java
@Label("Order Created")
@Category("Application")
@Description("Fired when an order is successfully persisted")
public class OrderCreatedJfrEvent extends Event {
    @Label("Order ID")  String orderId;
    @Label("Amount")    long   amountCents;
    @Label("Customer")  String customerId;
}

// Usage
var event = new OrderCreatedJfrEvent();
event.begin();
// ... do the work ...
event.orderId    = saved.getId().toString();
event.amountCents = saved.getAmountCents();
event.customerId  = saved.getCustomerId();
event.commit();   // no-op if JFR recording is not active
```

---

## Observability decision table

| Need | Tool |
|---|---|
| Count discrete events (requests, errors, retries) | `Counter` |
| Measure latency (p50/p95/p99) | `Timer` with percentiles |
| Track current value (queue depth, cache size, connections) | `Gauge` |
| Measure value distribution (payload size, order amount) | `DistributionSummary` |
| Simple method timing, declarative | `@Timed` + `TimedAspect` |
| External dependency health | `HealthIndicator` / `ReactiveHealthIndicator` |
| Per-request log correlation | `CorrelationIdFilter` + MDC (MVC) or ScopedValue (virtual threads) |
| JSON logs for aggregation | Logstash Logback encoder |
| High-frequency internal events, zero overhead when off | JFR custom event |
| Distributed tracing (spans across services) | Micrometer Tracing + Brave/OpenTelemetry |
| Expose metrics to Prometheus | `micrometer-registry-prometheus` + `/actuator/prometheus` |
