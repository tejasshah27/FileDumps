# JDK 8 — Lambdas, Streams, java.time, CompletableFuture

**Lambdas + method refs** — 4 forms; prefer method ref when it reads naturally
```java
list.forEach(System.out::println);          // instance method on arbitrary object
list.stream().map(String::toUpperCase);     // instance method on stream element
list.stream().filter(Objects::nonNull);     // static method
list.stream().map(User::new);              // constructor ref
```

**Functional interface family** (`java.util.function`) — prefer primitive specializations to avoid boxing
```
Function<T,R>     BiFunction<T,U,R>    UnaryOperator<T>   BinaryOperator<T>
Consumer<T>       BiConsumer<T,U>
Supplier<T>
Predicate<T>      BiPredicate<T,U>
// Primitive: avoids boxing overhead in hot paths
IntFunction<R>    ToIntFunction<T>    IntUnaryOperator    IntBinaryOperator
IntConsumer       IntSupplier         IntPredicate
// same prefixes for Long, Double
```

**Streams — complete reference**
```java
// Factories
Stream.of(a, b, c)
Stream.empty()
Stream.generate(UUID::randomUUID).limit(10)         // infinite
Stream.iterate(0, n -> n + 2).limit(5)              // infinite; JDK9 adds 3-arg with predicate
Stream.concat(s1, s2)
IntStream.range(0, 10)                              // [0,10)
IntStream.rangeClosed(1, 10)                        // [1,10]
Arrays.stream(arr)
collection.stream() / .parallelStream()

// Intermediate (lazy, not evaluated until terminal)
.filter(pred)         .map(fn)           .flatMap(fn)
.mapToInt(fn)         .mapToLong(fn)     .mapToDouble(fn)
.distinct()           .sorted()          .sorted(comparator)
.peek(consumer)       .limit(n)          .skip(n)
.mapMulti(biConsumer)                               // JDK16 push-based flatMap
.takeWhile(pred)      .dropWhile(pred)              // JDK9

// Terminal (triggers evaluation)
.collect(collector)   .toList()                     // toList() = JDK16 unmodifiable
.forEach(consumer)    .forEachOrdered(consumer)
.reduce(identity, fn) .reduce(fn)                   // Optional result
.count()
.min(comparator)      .max(comparator)              // Optional<T>
.sum() / .average() / .summaryStatistics()          // IntStream/LongStream/DoubleStream
.anyMatch(pred)       .allMatch(pred)  .noneMatch(pred)
.findFirst()          .findAny()                    // Optional<T>
.toArray()            .toArray(T[]::new)
```

**Collectors — complete reference**
```java
Collectors.toList()                                 // mutable list
Collectors.toUnmodifiableList()                     // JDK10 immutable
Collectors.toSet() / toUnmodifiableSet()
Collectors.toMap(keyFn, valFn)
Collectors.toMap(keyFn, valFn, mergeOnDup)         // merge fn for duplicate keys
Collectors.toUnmodifiableMap(keyFn, valFn)
Collectors.groupingBy(classifier)                   // Map<K, List<V>>
Collectors.groupingBy(classifier, downstream)       // e.g., counting(), summing...
Collectors.partitioningBy(pred)                     // Map<Boolean, List<V>>
Collectors.partitioningBy(pred, downstream)
Collectors.counting()
Collectors.summingInt(fn) / summingLong / summingDouble
Collectors.averagingInt(fn)
Collectors.joining(delimiter, prefix, suffix)
Collectors.mapping(fn, downstream)
Collectors.flatMapping(fn, downstream)              // JDK9
Collectors.filtering(pred, downstream)              // JDK9
Collectors.collectingAndThen(downstream, finisher)
Collectors.teeing(c1, c2, merger)                   // JDK12 — two collectors at once
Collectors.summarizingInt(fn)                       // IntSummaryStatistics
Collectors.toCollection(ArrayList::new)             // specific mutable collection
```

**Optional — complete reference**
```java
// Construction
Optional.of(nonNullValue)                           // NPE if null
Optional.ofNullable(maybeNull)                      // safe
Optional.empty()

// Transform
opt.map(User::getName)
opt.flatMap(u -> Optional.ofNullable(u.getAddress()))
opt.filter(s -> !s.isBlank())

// Consume
opt.ifPresent(this::send)
opt.ifPresentOrElse(this::send, this::logMissing)   // JDK9

// Extract (never use .get() naked)
opt.orElse("default")
opt.orElseGet(this::computeDefault)                 // lazy — prefer over orElse for non-literals
opt.orElseThrow()                                   // JDK10 — NoSuchElementException
opt.orElseThrow(() -> new NotFoundException(id))    // custom
opt.or(() -> fallbackOptional)                      // JDK9 — returns other Optional

// Stream bridge
opt.stream()                                        // JDK9 — 0 or 1 elements; flatMap-friendly

// Rules
// - Return type ONLY; never field / constructor param / collection element
// - Never Optional.get() without isPresent(); use orElseThrow()
// - opt.isPresent() + opt.get() → replace with opt.ifPresent / orElseThrow / map
```

**Default + static interface methods**
```java
interface Validator<T> {
    boolean validate(T t);
    default Validator<T> and(Validator<T> other) { return t -> validate(t) && other.validate(t); }
    default Validator<T> or(Validator<T> other)  { return t -> validate(t) || other.validate(t); }
    static <T> Validator<T> alwaysTrue() { return t -> true; }
}
```

**`java.time`** — ban `Date`, `Calendar`, `SimpleDateFormat` entirely
```java
LocalDate.now() / .of(2024, 1, 15) / .parse("2024-01-15")
LocalTime.now() / .of(14, 30, 0)
LocalDateTime.now(ZoneId.of("UTC"))
ZonedDateTime.now(ZoneId.of("America/New_York"))
OffsetDateTime.now(ZoneOffset.UTC)
Instant.now()                                       // machine timestamp; use for DB/logs
Duration.ofSeconds(30) / Duration.between(t1, t2)
Period.ofDays(7) / Period.between(d1, d2)
date.plus(1, ChronoUnit.MONTHS)
ChronoUnit.DAYS.between(start, end)
DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss")
DateTimeFormatter.ISO_OFFSET_DATE_TIME              // thread-safe — safe as static final
TemporalAdjusters.firstDayOfMonth()
TemporalAdjusters.next(DayOfWeek.MONDAY)
```

**`CompletableFuture`** — async pipelines
```java
CompletableFuture
    .supplyAsync(() -> fetchUser(id), executor)
    .thenApply(User::getName)                       // transform, same thread
    .thenApplyAsync(this::enrich, executor)         // transform, different executor
    .thenCompose(name -> lookupProfile(name))       // chain async step (flatMap equiv)
    .thenCombine(fetchOrders(id), (p, o) -> new View(p, o))  // merge two futures
    .exceptionally(ex -> fallback)                  // recover from exception
    .handle((result, ex) -> ex != null ? fallback : result)  // always runs
    .whenComplete((r, ex) -> audit(r, ex))          // side-effect, preserves result/exception
    .orTimeout(5, SECONDS)                          // JDK9 — completes exceptionally
    .completeOnTimeout(fallback, 5, SECONDS);       // JDK9 — completes with fallback

CompletableFuture.allOf(f1, f2, f3).join();        // wait all; results via f1.get() etc
CompletableFuture.anyOf(f1, f2, f3).join();        // first to complete (any type)
CompletableFuture.failedFuture(ex);                 // JDK9
CompletableFuture.completedStage(value);            // JDK9
```

**Map new methods** — avoid manual get-then-put
```java
map.getOrDefault(key, fallback)
map.putIfAbsent(key, value)                         // atomic check-then-put
map.computeIfAbsent(key, k -> new ArrayList<>())    // canonical cache-miss pattern
map.computeIfPresent(key, (k, v) -> transform(v))
map.compute(key, (k, v) -> v == null ? 1 : v + 1) // null-safe atomic update
map.merge(key, 1, Integer::sum)                     // frequency count idiom
map.forEach((k, v) -> ...)
map.replaceAll((k, v) -> transform(v))
map.remove(key, specificValue)                      // conditional remove (returns boolean)
map.replace(key, oldValue, newValue)               // CAS-style conditional replace
```

**Comparator fluent API**
```java
Comparator.comparing(User::lastName)
    .thenComparing(User::firstName)
    .thenComparingInt(User::age)
    .reversed()
Comparator.naturalOrder() / Comparator.reverseOrder()
Comparator.nullsFirst(Comparator.naturalOrder())
Comparator.comparingInt(String::length)
```

**Collection new methods**
```java
list.removeIf(s -> s.isBlank())         // in-place filter
list.replaceAll(String::trim)           // in-place transform
list.sort(comparator)                   // in-place sort (mergesort, stable)
```

**`LongAdder` / `LongAccumulator`** — high-contention counters; faster than `AtomicLong` under write contention
```java
LongAdder hits = new LongAdder(); hits.increment(); long total = hits.sum();
LongAccumulator max = new LongAccumulator(Long::max, 0);
```

**`StampedLock`** — optimistic read + write; replaces `ReadWriteLock` for read-heavy shared state
```java
long stamp = lock.tryOptimisticRead();
int x = this.x, y = this.y;
if (!lock.validate(stamp)) {
    stamp = lock.readLock();
    try { x = this.x; y = this.y; } finally { lock.unlockRead(stamp); }
}
```

**Math overflow-checked** — use in financial / safety-critical arithmetic
```java
Math.addExact(a, b); Math.subtractExact(a, b);
Math.multiplyExact(a, b); Math.toIntExact(longVal);
// All throw ArithmeticException on overflow
```

**Base64** — replaces Apache Commons
```java
Base64.getEncoder().encodeToString(bytes);
Base64.getDecoder().decode(encoded);
Base64.getUrlEncoder().withoutPadding();     // URL-safe, no padding
Base64.getMimeEncoder(76, CRLF);             // MIME wrapping
```

**Effectively final in lambdas** — captured locals need not be declared `final` but must not be reassigned

**`@FunctionalInterface`** — document intent; compiler enforces exactly one abstract method

---
See also: `examples/jdk8/Jdk8Features.java`
