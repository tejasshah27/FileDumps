---
name: backend-developer
description: >
  Expert Java and Spring Boot backend code generation with modern JDK idioms, best practices,
  and architectural decisions. Make sure to use this skill whenever the user asks to write,
  review, refactor, or design any Java code — including Spring Boot services, REST APIs,
  repositories, entities, DTOs, config classes, domain models, schedulers, event handlers,
  exception handlers, filters, interceptors, or mappers. Also use this skill for any question
  about Java collections, streams, concurrency, threads, file I/O, records, sealed classes,
  Optional, exception handling, JPA, Hibernate, or JVM performance. Even small Java snippets
  benefit — always apply this skill for any JVM backend task.
---

# Backend Developer — Java + Spring Boot

## AGENT INSTRUCTIONS — READ BEFORE RESPONDING

This skill is designed for use by any LLM agent (Claude, GPT-4, Gemini, Mistral, or others).
The steps below are a **required workflow**, not suggestions.
They exist because training data alone is insufficient for producing correct, modern,
production-grade Java — the reference files here are the authoritative source for decisions,
gotchas, and modern API choices that training data does not reliably encode.

---

## MANDATORY WORKFLOW — EXECUTE BEFORE WRITING ANY CODE

**Step 1 — Identify the concept(s) in the task.**
Every concept in the task maps to a reference file in the table below.

**Step 2 — Read every matching reference file BEFORE generating any code.**
Open and read the file at the listed path. Do not substitute training knowledge.
If the task involves choosing between two patterns or APIs: read `references/decision-guide.md`.
If the task involves production concerns (performance, leaks, concurrency traps, Spring pitfalls): read `references/advance_guide.md`.
If you need to verify a Sonar rule or confirm the right API quickly: read `references/quick-reference.md`.

**Step 3 — Read the matching example file.**
The `examples/` folder contains complete, compilable Java code.
Each file has a SCENARIO GUIDE comment at the top explaining when to use each pattern shown.
Read the matching example to verify the code shape before generating.

**Step 4 — Write the code.**
Apply everything from the reference and example files.
Default to the newest LTS JDK feature available for the pattern being implemented.
Every generated file must be clean against the Sonar rules in `references/quick-reference.md`.

---

## North Star — apply to every line of code written

- Readable > Clever
- Immutable by default — `record`, `List.of`, `final` fields
- Fail fast at entry points — `Objects.requireNonNull`, guard clauses at top of method
- Zero waste — no unnecessary allocations, no held locks, no leaked resources
- Right construct for the context — not the most familiar one
- Newest LTS JDK feature wins when multiple approaches are equivalent

---

## Reference File Index — read the file before writing

| Task involves… | Read before coding |
|---|---|
| List, Set, Map, EnumMap, Deque — type choice, factories, atomic ops, Comparator, sizing | `references/collections.md` |
| String building, text blocks, isBlank/strip/lines, regex, java.time, Base64, numbers, logging | `references/strings-and-formatting.md` |
| Records, sealed classes, pattern matching, switch expressions, var, interfaces, immutability | `references/types-and-oop.md` |
| Optional API, null discipline, exception types, try-with-resources, exception hierarchy | `references/optional-and-errors.md` |
| Lambdas, functional interfaces, Streams, Collectors, Gatherers, stream vs loop | `references/streams-and-functional.md` |
| Threads, virtual threads, locks, atomics, CompletableFuture, StructuredTaskScope, ScopedValue | `references/concurrency.md` |
| NIO.2, Files, Path, InputStream, HTTP Client, resource leak rules | `references/file-and-io.md` |
| Spring controllers, DTOs, request/response, validation, ProblemDetail, REST design | `references/spring-web.md` |
| JPA entities, repositories, projections, @Query, N+1, @EntityGraph, @Transactional | `references/spring-data.md` |
| Spring service layer, DI, @ConfigurationProperties, domain events, @Async, @Scheduled | `references/spring-core.md` |
| JVM flags, GC, static constants, autoboxing cost, memory leaks, hot path optimisation | `references/jvm-and-performance.md` |
| Choosing between competing patterns or APIs — stream vs loop, record vs class, Optional vs throw, which collection, which lock | `references/decision-guide.md` |
| Production-grade concerns — leaks, ThreadLocal, N+1, logging overhead, concurrency traps, Spring pitfalls, GC pressure | `references/advance_guide.md` |
| Sonar rules and fast API/pattern lookup table | `references/quick-reference.md` |

---

## Example File Index — read before generating code of that shape

| Code shape | Read before coding |
|---|---|
| NIO.2, try-with-resources, Fork/Join, ThreadLocalRandom, numeric literals | `examples/jdk7/Jdk7Features.java` |
| Streams, Collectors, Optional, java.time, CompletableFuture, Map ops, LongAdder, StampedLock | `examples/jdk8/Jdk8Features.java` |
| List.of/Map.of/Set.of, takeWhile/dropWhile, Stream.ofNullable, VarHandle, StackWalker | `examples/jdk9/Jdk9Features.java` |
| var, isBlank/strip/lines, Files.readString/writeString, Predicate.not, HTTP Client | `examples/jdk10_11/Jdk10And11Features.java` |
| Switch expressions, text blocks (\ and \s escapes), records, sealed classes, pattern instanceof, Stream.toList | `examples/jdk12_17/Jdk12To17Features.java` |
| Virtual threads, Sequenced Collections, pattern switch with guards, record patterns, ScopedValue, StructuredTaskScope | `examples/jdk21/Jdk21Features.java` |
| Stream Gatherers (windowFixed/Sliding/scan/fold/mapConcurrent), unnamed _, primitive patterns, flexible constructors | `examples/jdk22_25/Jdk22To25Features.java` |
| Spring controller, service, repository, entity, record DTO, @ConfigurationProperties, domain events, exception handler | `examples/springboot/OrderServiceStack.java` |
