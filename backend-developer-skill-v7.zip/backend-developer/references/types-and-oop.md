# Types and OOP

## `var` — local type inference (JDK 10)
```java
// USE — type obvious from RHS
var list    = new ArrayList<String>();
var entries = map.entrySet().iterator().next();   // avoids repeating long generic type
var result  = service.findById(id);

// USE in for-each — always fine
for (var entry : map.entrySet()) { ... }

// DON'T USE — type not obvious
var x = getValue();    // BAD — reader can't tell the type
var flag = true;       // BAD — boolean is short enough to write

// var in lambda params (JDK 11) — enables annotations
list.stream().map((@NonNull var s) -> s.trim()).toList();
```
`var` is compile-time only; erased to the inferred type. No runtime cost.

---

## Records — immutable data carriers (JDK 16)
Auto-generated: canonical constructor, component accessors (`name()`), `equals`, `hashCode`, `toString`.
```java
record Point(double x, double y) {
    // Compact canonical constructor — validation + normalization
    // No need to write this.x = x; compiler adds it after the block
    Point {
        if (Double.isNaN(x) || Double.isNaN(y)) throw new IllegalArgumentException();
        x = Math.round(x * 1000) / 1000.0;   // normalize in compact constructor
    }

    // Additional constructors must delegate to canonical
    Point(double scalar) { this(scalar, scalar); }

    // Static factories are idiomatic
    static Point origin() { return new Point(0, 0); }

    // Instance methods allowed
    double distanceTo(Point other) { return Math.hypot(x - other.x, y - other.y); }

    // Static fields OK; instance fields NOT allowed (record components only)
    private static final Point ZERO = new Point(0, 0);
}

// Records implement interfaces
record Range(int start, int end) implements Comparable<Range> {
    Range { if (end < start) throw new IllegalArgumentException(); }
    public int compareTo(Range o) { return Integer.compare(start, o.start); }
}

// Generic records
record Pair<A, B>(A first, B second) {}
record Result<T>(T value, String error) {
    static <T> Result<T> ok(T v)      { return new Result<>(v, null); }
    static <T> Result<T> err(String e){ return new Result<>(null, e); }
    boolean isOk() { return error == null; }
}
```

**Use record for:** DTO, API request/response, projection, value object, event, config snapshot.
**Do NOT use record for:** JPA `@Entity` (needs no-arg constructor + mutable fields), objects
requiring inheritance, anything needing mutable state.

---

## Sealed classes / interfaces (JDK 17)
Closed hierarchy — compiler verifies exhaustiveness in pattern switch; no `default` needed.
```java
sealed interface PaymentResult
    permits PaymentResult.Success, PaymentResult.Failure, PaymentResult.Pending {

    record Success(String txId, long amount, Instant at) implements PaymentResult {}
    record Failure(String reason, int code)              implements PaymentResult {
        boolean isRetryable() { return code >= 500; }
    }
    record Pending(String ref, Instant expires)          implements PaymentResult {}
}

// Exhaustive — compiler rejects missing case
String describe(PaymentResult r) {
    return switch (r) {
        case PaymentResult.Success s  -> "OK: " + s.txId();
        case PaymentResult.Failure f  -> "ERR " + f.code() + ": " + f.reason();
        case PaymentResult.Pending p  -> "PENDING until " + p.expires();
    };
}
```

**Use sealed when:** variants carry different data (each subtype has different fields).
**Use enum when:** variants are stateless labels — no per-variant data.

---

## Pattern matching — instanceof (JDK 16)
```java
// BEFORE — cast duplicates type check
if (obj instanceof String) { String s = (String) obj; use(s); }

// AFTER — binding variable in scope in true-branch
if (obj instanceof String s && !s.isBlank()) { use(s); }
if (obj instanceof Integer i) return i * 2;

// Negation — s in scope after the if (early return / throw)
if (!(obj instanceof String s)) throw new IllegalArgumentException();
// s is usable here
```

---

## Pattern switch with guards (JDK 21)
```java
String classify(Object obj) {
    return switch (obj) {
        case null                       -> "null";
        case Integer i when i < 0       -> "negative int";
        case Integer i                  -> "non-negative int: " + i;
        case String s when s.isBlank()  -> "blank string";
        case String s                   -> "string: " + s;
        default                         -> obj.getClass().getSimpleName();
    };
}

// Sealed type — exhaustive, no default needed
double area(Shape shape) {
    return switch (shape) {
        case Circle c    -> Math.PI * c.radius() * c.radius();
        case Rectangle r -> r.w() * r.h();
        case Triangle t  -> t.area();
    };
}
```

---

## Record patterns — destructure in pattern position (JDK 21)
```java
// instanceof
if (obj instanceof Point(int x, int y)) { /* x and y bound */ }

// Nested
if (resp instanceof ApiResponse(User(String name, _), int code)) { ... }

// In switch
String render(Shape s) {
    return switch (s) {
        case Circle(double r)              -> "circle r=%.2f".formatted(r);
        case Rectangle(double w, double h) -> "rect %.1fx%.1f".formatted(w, h);
    };
}
```

---

## Unnamed patterns and variables `_` (JDK 22)
```java
case Rectangle(double w, _)       -> ...    // ignore unused component
try { ... } catch (Exception _)   { }       // intentional swallow (document why)
for (var _ : list) count++;                 // iterate for side effect only
try (var _ = meter.time()) { ... }          // resource acquired for side effect
```

---

## Switch expressions (JDK 14)
```java
// Arrow form — no fall-through, no break, exhaustive
int days = switch (month) {
    case JANUARY, MARCH, MAY -> 31;
    case FEBRUARY            -> Year.isLeap(year) ? 29 : 28;
    default                  -> 30;
};

// Block form — statements needed before yielding value
String label = switch (code) {
    case 200 -> "OK";
    default -> {
        log.warn("unknown: {}", code);
        yield "UNKNOWN_" + code;
    }
};
```
**Use switch expression when:** branching on a single value (enum, type, status code).
**Use if-else when:** conditions span multiple variables or involve range checks.

---

## Interfaces — default, static, private methods
```java
interface Validator<T> {
    boolean validate(T t);
    // default — add behaviour without breaking implementors
    default Validator<T> and(Validator<T> other) { return t -> validate(t) && other.validate(t); }
    default Validator<T> or(Validator<T> other)  { return t -> validate(t) || other.validate(t); }
    // static — factory / utility on interface
    static <T> Validator<T> alwaysTrue() { return _ -> true; }
    // private — shared logic between default methods; not exposed (JDK 9)
    private boolean safeValidate(T t) { try { return validate(t); } catch (Exception e) { return false; } }
}
```

---

## Immutability patterns
```java
// Immutable literal            → List.of / Set.of / Map.of
// Immutable defensive copy     → List.copyOf / Map.copyOf  (throws on null elements)
// Immutable data object        → record  (compiler-enforced)
// Immutable complex object     → record + compact constructor for validation
// Immutable with builder       → record + nested Builder class

record Config(String host, int port, boolean tls) {
    static Builder builder() { return new Builder(); }
    static final class Builder {
        private String host = "localhost"; private int port = 8080; private boolean tls = false;
        public Builder host(String h) { this.host = h; return this; }
        public Builder port(int p)   { this.port = p; return this; }
        public Builder tls(boolean t){ this.tls = t; return this; }
        public Config build()        { return new Config(host, port, tls); }
    }
}
```

`final` on a mutable object reference prevents reassignment only — not mutation of the object.
It is NOT a substitute for immutability.

---

## `@Deprecated` lifecycle (JDK 9)
```java
@Deprecated(since = "2.5", forRemoval = true)
public void oldMethod() { ... }
```
Always specify `since` and `forRemoval` to document intent and enable compiler warnings.

---

## Non-static inner class — memory gotcha
Non-static inner class carries implicit `OuterClass.this` reference.
If inner class escapes (stored in callback, listener, cache), outer class is never GC'd.
Fix: make inner class `static` unless it genuinely needs outer instance state.

---

See also: `examples/jdk7/Jdk7Features.java`, `examples/jdk12_17/Jdk12To17Features.java`, `examples/jdk21/Jdk21Features.java`, `examples/jdk22_25/Jdk22To25Features.java`
