# Optional, Null Safety, and Exception Handling

## Optional — complete API

### Construction
```java
Optional.of(nonNullValue)       // NPE if null — use when null is a programming error
Optional.ofNullable(maybeNull)  // safe — use when null is possible
Optional.empty()
```

### Transform (lazy — only run if value present)
```java
opt.map(User::getName)
opt.flatMap(u -> Optional.ofNullable(u.getAddress()))
opt.filter(s -> !s.isBlank())
```

### Consume
```java
opt.ifPresent(this::send)
opt.ifPresentOrElse(this::send, this::logMissing)    // JDK 9
```

### Extract — NEVER use `.get()` naked
```java
opt.orElse("default")                                // always evaluates argument
opt.orElseGet(this::computeDefault)                  // lazy — use when fallback is expensive
opt.orElseThrow()                                    // JDK 10 — NoSuchElementException
opt.orElseThrow(() -> new NotFoundException(id))     // always prefer for domain exceptions
opt.or(() -> fallbackOptional)                       // JDK 9 — chain to another Optional
```

### Stream bridge (JDK 9)
```java
opt.stream()    // 0 or 1 elements — use in flatMap pipelines to skip empties
List<String> present = ids.stream()
    .flatMap(id -> findUser(id).stream())   // skips absent users without filter + get
    .map(User::name)
    .toList();
```

---

## Optional — rules
- Return type **ONLY** — never field, constructor param, collection element
- `isPresent()` + `get()` → replace with `ifPresent` / `map` / `orElseThrow`
- `orElse(expr)` vs `orElseGet(() -> expr)` — `orElse` always evaluates `expr` even when
  value is present; use `orElseGet` when fallback is a method call or object creation
- `opt == null` is always wrong — Optional itself is never null

---

## When Optional vs when throw

| Scenario | Use |
|---|---|
| "Not found" is **normal** — caller decides what to do | `Optional<T>` return type |
| Absence is a **contract violation** — must exist here | throw `NotFoundException` |
| Input validation — caller passed bad data | throw `IllegalArgumentException` |
| Object in wrong state for this operation | throw `IllegalStateException` |
| Entity MUST exist (already validated upstream) | `.orElseThrow(NotFoundException::new)` |

```java
// Optional — expected absence, caller decides
Optional<User> findByEmail(String email) { return repo.findByEmail(email); }

// Throw — contract violation
User requireUser(UUID id) {
    return repo.findById(id)
        .orElseThrow(() -> new NotFoundException("User not found: " + id));
}
```

---

## Null discipline — entry-point validation

Push null checks to **entry points** (public service methods, constructors) not deep in logic.
NPE deep in call stack = long expensive stack trace + hard to diagnose source.

```java
// Objects utility (JDK 7, enriched JDK 9)
Objects.requireNonNull(param, "param must not be null");
Objects.requireNonNull(param, () -> "param null in " + getClass().getSimpleName()); // lazy msg
Objects.requireNonNullElse(value, fallback);    // null-safe with default
Objects.toString(nullable, "");                  // null-safe toString
boolean eq = Objects.equals(a, b);              // null-safe equals — never NPE
int h      = Objects.hash(a, b, c);             // varargs, null-safe multi-field hashCode
Objects.checkIndex(i, list.size());              // bounds check — JDK 9

// Chain optional navigation instead of nested null checks
return Optional.ofNullable(user)
    .map(User::getAddress)
    .map(Address::getCity)
    .orElse("Unknown");
```

`null` in `List.of` / `Set.of` / `Map.of` — these factories are null-hostile; throw immediately.
Document this at API boundaries. Use `List.copyOf` with pre-filtered source if nulls are possible.

---

## Exception handling

### try-with-resources (JDK 7) — always for AutoCloseable
```java
// Multiple resources — closed in REVERSE declaration order
try (var in  = new FileInputStream(src);
     var out = new FileOutputStream(dst)) {
    in.transferTo(out);
}

// JDK 9 — use effectively-final existing variable; no re-declaration
try (existingStream; existingConn) { ... }
```

### Multi-catch — DRY for unrelated exceptions (JDK 7)
```java
// BEFORE: duplicate handler
} catch (IOException e) { throw new AppException(e); }
} catch (SQLException e) { throw new AppException(e); }

// AFTER: one handler
} catch (IOException | SQLException e) { throw new AppException(e); }
```
Don't use multi-catch to collapse exceptions that need different recovery paths.

### Custom exception hierarchy
```java
// Sealed hierarchy — forces exhaustive handling at call site
sealed interface AppError permits NotFoundError, ValidationError, ConflictError {}
record NotFoundError(String entity, Object id) implements AppError {}
record ValidationError(String field, String message) implements AppError {}

// RuntimeException subclass for Spring / unchecked propagation
public class NotFoundException extends RuntimeException {
    public NotFoundException(String message) { super(message); }
}
```

### Which exception type to throw

| Scenario | Use |
|---|---|
| Invalid input from caller | `IllegalArgumentException` |
| Object in wrong state | `IllegalStateException` |
| Entity not found (expected) | custom `NotFoundException extends RuntimeException` |
| Domain rule violated | custom sealed hierarchy or domain exception |
| Arithmetic overflow | `ArithmeticException` (or `Math.addExact` throws it) |
| Index out of bounds | `IndexOutOfBoundsException` or use `Objects.checkIndex` |

### Checked exceptions in streams — wrap them
```java
@FunctionalInterface
interface ThrowingFunction<T, R> {
    R apply(T t) throws Exception;
    static <T, R> Function<T, R> wrap(ThrowingFunction<T, R> f) {
        return t -> {
            try { return f.apply(t); }
            catch (RuntimeException e) { throw e; }
            catch (Exception e) { throw new RuntimeException(e); }
        };
    }
}

list.stream().map(ThrowingFunction.wrap(this::process)).toList();
```

### Fail fast with context
```java
void process(List<Order> orders) {
    Objects.requireNonNull(orders, "orders");
    if (orders.isEmpty()) throw new IllegalArgumentException(
        "orders must not be empty for " + getClass().getSimpleName());
    // business logic — null/empty never reached here
}
```

---

## Exception gotchas

**Silent swallow** — `catch (Exception e) {}` hides bugs; tasks appear to succeed.
At minimum `log.error("...", e)`. Better: translate to domain exception and rethrow.

**Exception in Runnable/Callable submitted to ExecutorService** — exceptions vanish unless
`future.get()` is called. Wrap tasks with a logging try-catch:
```java
executor.submit(() -> {
    try { doWork(); }
    catch (Exception e) { log.error("Task failed", e); }
});
```

**`Optional.get()` naked** — always `orElseThrow()` instead. Sonar S2471.

**Helpful NPE flag (JDK 14)** — JVM tells you which variable was null in the NPE message.
Always enable in production: `-XX:+ShowCodeDetailsInExceptionMessages`

---

See also: `examples/jdk7/Jdk7Features.java`, `examples/jdk8/Jdk8Features.java`, `examples/jdk9/Jdk9Features.java`
