package examples.springboot;

import org.springframework.data.domain.*;
import org.springframework.data.jpa.repository.*;
import org.springframework.stereotype.*;
import org.springframework.transaction.annotation.*;
import org.springframework.web.bind.annotation.*;
import org.springframework.context.ApplicationEventPublisher;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.validation.annotation.Validated;

import jakarta.persistence.*;
import jakarta.validation.constraints.*;
import java.time.*;
import java.util.*;
import java.util.concurrent.*;
import java.util.stream.*;

/**
 * Spring Boot — idiomatic patterns with modern Java (JDK 17-21)
 * Controller → Service → Repository → Entity + Events + Config
 *
 * SCENARIO GUIDE — when to use each Spring pattern:
 *
 * Constructor injection vs field injection vs setter injection
 *   Field injection (@Autowired on field) — DO NOT use: Sonar S3016, untestable without
 *     Spring context, hides dependencies, breaks immutability.
 *   Setter injection — only when dependency is optional or can change post-construction.
 *   Constructor injection — ALWAYS for required dependencies. Enables: final fields,
 *     immutability, testing without Spring, explicit dependency declaration.
 *
 * @ConfigurationProperties + record vs @Value
 *   @Value — single isolated property, SpEL expression, one-off value.
 *   @ConfigurationProperties — group of related properties (API config, limits, feature flags).
 *     With record: immutable, compact, validated at startup via @Validated.
 *     Fails fast at startup if properties are missing or invalid — not at first use.
 *   USE @ConfigurationProperties WHEN: ≥ 2 properties belong together conceptually.
 *
 * record for DTO vs class
 *   USE record WHEN: DTO is immutable (request body, response body, event payload).
 *   Static factory from(Entity e): keeps mapping logic inside the DTO, not the service.
 *   Compact constructor: validate input at construction, not at usage sites.
 *
 * Repository: derived query vs @Query vs Specification
 *   Derived query (findByEmailIgnoreCase) — simple conditions; readable; no SQL risk.
 *     Use for: lookup by 1–3 fields with simple operators.
 *   @Query with text block — complex JPQL or native SQL; multi-join, aggregation.
 *     Use text block: indentation, no escaping, readable multi-line SQL.
 *   Specification — dynamic query (optional filters, user-defined sort).
 *     Use when: search screens, report filters where WHERE clauses vary at runtime.
 *
 * JOIN FETCH vs @EntityGraph vs lazy loading
 *   Lazy default — fine when loading single entity for mutation (no associations needed).
 *   JOIN FETCH in @Query — explicit, query-level; use for specific read queries that need
 *     associations. Fails with pagination (use @EntityGraph instead for paged queries).
 *   @EntityGraph — annotation-level; works with Spring Data paging; cleaner for standard
 *     findById/findAll queries that always need certain associations.
 *   N+1 rule: if you're in a loop calling entity.getAssociation() — you have N+1. Fix with
 *     JOIN FETCH or @EntityGraph.
 *
 * Projection (interface/record) vs full entity for reads
 *   Full entity — use when you'll call methods on it (confirm(), cancel()) or save it.
 *   Projection  — use for read-only views (list endpoints, search results, reports).
 *     Lighter: no first-level cache overhead, only selected columns loaded.
 *   Record projection with @Query SELECT new — works with native JPQL; type-safe.
 *
 * Domain events vs direct service calls
 *   Direct call — simple, synchronous, easy to trace.
 *   ApplicationEventPublisher — USE WHEN: action should trigger side effects in other
 *     subsystems (email, audit, cache invalidation) without tight coupling.
 *     Events make the primary transaction independent of side effects.
 *     @TransactionalEventListener — runs after the transaction commits; safe for
 *     post-commit side effects (send email only if order saved successfully).
 *
 * @Transactional(readOnly = true) vs @Transactional
 *   readOnly = true — default on service class for all query methods. Tells Hibernate
 *     to skip dirty checking; tells DB driver to use read replica if configured.
 *   @Transactional (readOnly = false) — override on write methods only.
 *   RULE: annotate class with readOnly = true; annotate mutating methods with @Transactional.
 *
 * ProblemDetail (RFC 7807) vs custom error response
 *   Custom error body — requires client to know your schema; inconsistent across services.
 *   ProblemDetail — standard format; Spring 6 / Boot 3 native; includes type, title,
 *     detail, instance URI. Use for all @ExceptionHandler responses.
 *
 * StructuredTaskScope for bulk fetch in service layer
 *   USE WHEN: service needs to fetch N entities in parallel (bulk endpoint, dashboard API).
 *   With spring.threads.virtual.enabled=true, each fork runs on a virtual thread.
 *   Scope lifetime guarantees all subtasks finish before result is assembled.
 */

// ─────────────────────────────────────────────────────────────────────────────
// Configuration — @ConfigurationProperties + record (JDK 17+)
// BEFORE: @Value("${app.orders.max-page-size}") private int maxPageSize;
// AFTER:
// ─────────────────────────────────────────────────────────────────────────────
@ConfigurationProperties(prefix = "app.orders")
record OrderConfig(
    @Min(1) @Max(200) int maxPageSize,
    @Positive int defaultPageSize,
    @NotNull Duration processingTimeout,
    @NotBlank String currencyCode
) {}

// ─────────────────────────────────────────────────────────────────────────────
// Entity — JPA with modern Java (immutable-ish, minimal mutability)
// ─────────────────────────────────────────────────────────────────────────────
@Entity
@Table(name = "orders",
    indexes = { @Index(name = "idx_orders_customer", columnList = "customer_id, status") })
class Order {

    @Id @GeneratedValue(strategy = GenerationType.UUID)
    private UUID id;

    @Column(nullable = false)
    private String customerId;

    @Column(nullable = false)
    @Enumerated(EnumType.STRING)
    private OrderStatus status;

    @Column(nullable = false)
    private long amountCents;

    @Column(nullable = false, updatable = false)
    private Instant createdAt = Instant.now();

    @Column(nullable = false)
    private Instant updatedAt = Instant.now();

    // JPA requires no-arg constructor; keep package-private
    Order() {}

    Order(String customerId, long amountCents) {
        this.customerId  = Objects.requireNonNull(customerId, "customerId");
        this.amountCents = amountCents;
        this.status      = OrderStatus.PENDING;
    }

    // Behaviour on the entity — not anemic
    void confirm() {
        if (status != OrderStatus.PENDING)
            throw new IllegalStateException("Only PENDING orders can be confirmed, was: " + status);
        this.status    = OrderStatus.CONFIRMED;
        this.updatedAt = Instant.now();
    }

    void cancel(String reason) {
        if (status == OrderStatus.SHIPPED || status == OrderStatus.DELIVERED)
            throw new IllegalStateException("Cannot cancel after shipment");
        this.status    = OrderStatus.CANCELLED;
        this.updatedAt = Instant.now();
    }

    // Accessors (no setters — state change via methods above)
    UUID      getId()          { return id; }
    String    getCustomerId()  { return customerId; }
    OrderStatus getStatus()    { return status; }
    long      getAmountCents() { return amountCents; }
    Instant   getCreatedAt()   { return createdAt; }
}

enum OrderStatus { PENDING, CONFIRMED, PROCESSING, SHIPPED, DELIVERED, CANCELLED }

// ─────────────────────────────────────────────────────────────────────────────
// DTOs — records (immutable, compact, no Lombok needed)
// ─────────────────────────────────────────────────────────────────────────────

// Request — validation annotations on record components
record CreateOrderRequest(
    @NotBlank String customerId,
    @Positive long amountCents,
    @NotBlank String currencyCode
) {}

// Response — static factory from entity
record OrderResponse(
    UUID id,
    String customerId,
    String status,
    long amountCents,
    Instant createdAt
) {
    static OrderResponse from(Order o) {
        return new OrderResponse(
            o.getId(), o.getCustomerId(), o.getStatus().name(),
            o.getAmountCents(), o.getCreatedAt());
    }
}

// Paged response
record PagedResponse<T>(
    List<T> content,
    int page,
    int size,
    long totalElements,
    int totalPages,
    boolean last
) {
    static <T> PagedResponse<T> from(Page<T> page) {
        return new PagedResponse<>(
            page.getContent(), page.getNumber(), page.getSize(),
            page.getTotalElements(), page.getTotalPages(), page.isLast());
    }
}

// ─────────────────────────────────────────────────────────────────────────────
// Domain events — records (immutable, descriptive)
// ─────────────────────────────────────────────────────────────────────────────
record OrderCreatedEvent(UUID orderId, String customerId, Instant occurredAt) {
    OrderCreatedEvent(UUID orderId, String customerId) {
        this(orderId, customerId, Instant.now());
    }
}

record OrderConfirmedEvent(UUID orderId, Instant confirmedAt) {
    OrderConfirmedEvent(UUID orderId) { this(orderId, Instant.now()); }
}

// ─────────────────────────────────────────────────────────────────────────────
// Repository — Spring Data JPA with projection + text block queries
// ─────────────────────────────────────────────────────────────────────────────
interface OrderRepository extends JpaRepository<Order, UUID> {

    // Derived query — simple, readable
    Optional<Order> findByIdAndCustomerId(UUID id, String customerId);
    List<Order>     findByCustomerIdAndStatus(String customerId, OrderStatus status);
    boolean         existsByCustomerIdAndStatus(String customerId, OrderStatus status);
    long            countByCustomerId(String customerId);

    // Projection — avoid loading full entity for read-only views
    interface OrderSummary {
        UUID      getId();
        String    getStatus();
        long      getAmountCents();
        Instant   getCreatedAt();
    }
    List<OrderSummary> findSummariesByCustomerId(String customerId, Sort sort);

    // Text block JPQL — complex query; JOIN FETCH avoids N+1
    @Query("""
            SELECT o FROM Order o
            WHERE o.customerId = :customerId
              AND o.status IN :statuses
              AND o.createdAt >= :since
            ORDER BY o.createdAt DESC
            """)
    List<Order> findRecentByStatuses(
        @Param("customerId") String customerId,
        @Param("statuses")   Collection<OrderStatus> statuses,
        @Param("since")      Instant since);

    // Native query with text block — when JPQL is insufficient
    @Query(value = """
            SELECT DATE_TRUNC('day', created_at) AS day,
                   COUNT(*)                      AS cnt,
                   SUM(amount_cents)             AS revenue
            FROM   orders
            WHERE  customer_id = :customerId
            GROUP  BY 1
            ORDER  BY 1
            """, nativeQuery = true)
    List<Object[]> dailyStats(@Param("customerId") String customerId);

    // EntityGraph — pre-load associations, avoid N+1
    @EntityGraph(attributePaths = {"items", "shippingAddress"})
    Optional<Order> findWithDetailsById(UUID id);
}

// ─────────────────────────────────────────────────────────────────────────────
// Service — constructor injection, virtual-thread safe, events
// ─────────────────────────────────────────────────────────────────────────────
@Service
@Transactional(readOnly = true)
class OrderService {

    // Constructor injection — always; no @Autowired on fields (Sonar S3016)
    private final OrderRepository        repo;
    private final ApplicationEventPublisher events;
    private final OrderConfig            config;

    OrderService(OrderRepository repo, ApplicationEventPublisher events, OrderConfig config) {
        this.repo   = repo;
        this.events = events;
        this.config = config;
    }

    @Transactional
    public OrderResponse create(CreateOrderRequest req) {
        // Validation guard — fail fast
        Objects.requireNonNull(req, "request");

        var order = new Order(req.customerId(), req.amountCents());
        var saved = repo.save(order);

        events.publishEvent(new OrderCreatedEvent(saved.getId(), saved.getCustomerId()));

        return OrderResponse.from(saved);
    }

    public Optional<OrderResponse> findById(UUID id) {
        return repo.findById(id).map(OrderResponse::from);
    }

    public PagedResponse<OrderResponse> listByCustomer(String customerId, int page, int size) {
        int safeSize = Math.min(size, config.maxPageSize());  // enforce config limit
        var pageable = PageRequest.of(page, safeSize, Sort.by("createdAt").descending());
        return PagedResponse.from(repo.findAll(pageable).map(OrderResponse::from));
    }

    @Transactional
    public OrderResponse confirm(UUID id) {
        // orElseThrow with context — not naked Optional.get()
        var order = repo.findById(id)
            .orElseThrow(() -> new NoSuchElementException("Order not found: " + id));

        order.confirm();
        events.publishEvent(new OrderConfirmedEvent(order.getId()));

        return OrderResponse.from(order);
    }

    // Virtual thread-safe async fan-out (Spring Boot 3.2+ with virtual threads enabled)
    public Map<String, OrderResponse> bulkFetch(List<UUID> ids) {
        try (var scope = new java.util.concurrent.StructuredTaskScope.ShutdownOnFailure()) {
            // Fork one lookup per id — virtual threads handle blocking I/O cheaply
            var subtasks = ids.stream()
                .collect(Collectors.toMap(
                    id -> id,
                    id -> scope.fork(() -> repo.findById(id).map(OrderResponse::from).orElse(null))
                ));

            scope.join().throwIfFailed();

            return subtasks.entrySet().stream()
                .filter(e -> e.getValue().get() != null)
                .collect(Collectors.toMap(
                    e -> e.getKey().toString(),
                    e -> e.getValue().get()));

        } catch (Exception e) {
            throw new RuntimeException("Bulk fetch failed", e);
        }
    }
}

// ─────────────────────────────────────────────────────────────────────────────
// Controller — REST, @Validated, ProblemDetail (RFC 7807)
// ─────────────────────────────────────────────────────────────────────────────
@RestController
@RequestMapping("/api/v1/orders")
@Validated
class OrderController {

    private final OrderService service;

    OrderController(OrderService service) { this.service = service; }

    @PostMapping
    @ResponseStatus(org.springframework.http.HttpStatus.CREATED)
    OrderResponse create(@RequestBody @jakarta.validation.Valid CreateOrderRequest req) {
        return service.create(req);
    }

    @GetMapping("/{id}")
    OrderResponse getById(@PathVariable UUID id) {
        return service.findById(id)
            .orElseThrow(() -> new NoSuchElementException("Order not found: " + id));
    }

    @GetMapping
    PagedResponse<OrderResponse> list(
        @RequestParam String customerId,
        @RequestParam(defaultValue = "0") @Min(0) int page,
        @RequestParam(defaultValue = "20") @Min(1) @Max(100) int size) {
        return service.listByCustomer(customerId, page, size);
    }

    @PatchMapping("/{id}/confirm")
    OrderResponse confirm(@PathVariable UUID id) {
        return service.confirm(id);
    }
}

// ─────────────────────────────────────────────────────────────────────────────
// Exception handler — ProblemDetail (Spring 6 / Boot 3)
// ─────────────────────────────────────────────────────────────────────────────
@RestControllerAdvice
class GlobalExceptionHandler
    extends org.springframework.web.servlet.mvc.method.annotation.ResponseEntityExceptionHandler {

    @ExceptionHandler(NoSuchElementException.class)
    @ResponseStatus(org.springframework.http.HttpStatus.NOT_FOUND)
    org.springframework.http.ProblemDetail handleNotFound(
        NoSuchElementException ex,
        jakarta.servlet.http.HttpServletRequest req) {

        var pd = org.springframework.http.ProblemDetail.forStatusAndDetail(
            org.springframework.http.HttpStatus.NOT_FOUND, ex.getMessage());
        pd.setInstance(java.net.URI.create(req.getRequestURI()));
        pd.setTitle("Resource Not Found");
        return pd;
    }

    @ExceptionHandler(IllegalStateException.class)
    @ResponseStatus(org.springframework.http.HttpStatus.CONFLICT)
    org.springframework.http.ProblemDetail handleConflict(IllegalStateException ex) {
        var pd = org.springframework.http.ProblemDetail.forStatusAndDetail(
            org.springframework.http.HttpStatus.CONFLICT, ex.getMessage());
        pd.setTitle("Invalid State Transition");
        return pd;
    }
}
