# JDK 21 (LTS) — Virtual Threads, Pattern Switch, Sequenced Collections

## Virtual threads (JEP 444) — M:N onto OS threads; blocking I/O unmounts, not parks
```java
// Explicit
Thread.ofVirtual().name("task-", 0).start(() -> process());

// Executor (preferred for structured work)
try (var exec = Executors.newVirtualThreadPerTaskExecutor()) {
    exec.submit(this::fetchFromDb);
    exec.submit(this::callRemoteService);
}

// Spring Boot 3.2+: spring.threads.virtual.enabled=true
// Auto-configures: Tomcat, @Async, scheduled tasks, etc.

// Rules:
// 1. Never pool virtual threads — create one per task
// 2. Replace synchronized with ReentrantLock (synchronized pins carrier thread)
// 3. Replace ThreadLocal with ScopedValue for propagated request context
// 4. No benefit for CPU-bound loops; only helps on I/O-bound blocking code
// 5. Thread.sleep(Duration) on virtual thread = cheap yield, not park
```

## Sequenced Collections (JEP 431) — `SequencedCollection`, `SequencedSet`, `SequencedMap`
```java
list.getFirst() / list.getLast()            // replaces get(0) / get(size()-1)
list.addFirst(e) / list.addLast(e)
list.removeFirst() / list.removeLast()
list.reversed()                             // reversed view, no copy

deque.getFirst() / deque.getLast()          // Deque now implements SequencedCollection

map.firstEntry() / map.lastEntry()
map.sequencedKeySet() / map.sequencedValues() / map.sequencedEntrySet()
// LinkedHashMap, LinkedHashSet, TreeMap, TreeSet all benefit
```

## Pattern matching for switch (JEP 441) — type patterns + guards + null
```java
String describe(Object obj) {
    return switch (obj) {
        case null                       -> "null";
        case Integer i when i < 0       -> "negative int";
        case Integer i                  -> "non-negative int: " + i;
        case Long l                     -> "long: " + l;
        case String s when s.isBlank()  -> "blank string";
        case String s                   -> "string: " + s;
        case int[] arr                  -> "int array len=" + arr.length;
        case Point(int x, int y)        -> "point at " + x + "," + y;  // record pattern
        default                         -> obj.getClass().getSimpleName();
    };
}

// Sealed type: exhaustive, no default required
double area(Shape s) {
    return switch (s) {
        case Circle c    -> Math.PI * c.radius() * c.radius();
        case Rectangle r -> r.w() * r.h();
        case Triangle t  -> t.area();
    };
}
```

## Record patterns (JEP 440) — destructure records in pattern position
```java
// instanceof
if (obj instanceof Point(int x, int y)) { /* x and y bound */ }

// Nested
if (response instanceof ApiResponse(User(String name, _), int code)) { ... }

// In switch
String render(Shape shape) {
    return switch (shape) {
        case Circle(double r)               -> "circle r=%.2f".formatted(r);
        case Rectangle(double w, double h)  -> "rect %sx%s".formatted(w, h);
        case Triangle t                     -> "triangle area=%.2f".formatted(t.area());
    };
}
```

## Unnamed patterns `_` and unnamed variables `_` (finalized JDK 22, JEP 456)
```java
// Unnamed pattern — ignore record component
case Rectangle(double w, _)    -> ...   // height not needed

// Unnamed variable — suppress unused-variable warning
try { ... } catch (Exception _) { }     // intentional swallow (still log in prod)
for (var _ : list) total++;             // iterate for side effect only
try (var _ = meter.time()) { ... }      // resource for side effect only
int _ = computeAndDiscard();            // result intentionally unused
```

## Scoped values (JEP 446 → finalized ~JDK 25)
```java
static final ScopedValue<RequestContext> CTX = ScopedValue.newInstance();

// Bind for duration of call tree — immutable, inherited by virtual thread children
ScopedValue.where(CTX, ctx).run(() -> service.handle(request));

// With return value
Result r = ScopedValue.where(CTX, ctx).call(() -> service.handle(request));

// Read anywhere in call tree
RequestContext ctx = CTX.get();

// Prefer over InheritableThreadLocal — safe with virtual threads, immutable
```

## Structured concurrency (JEP 453 → stabilizing)
```java
// ShutdownOnFailure: cancel all when any fails
try (var scope = new StructuredTaskScope.ShutdownOnFailure()) {
    Subtask<User>   user   = scope.fork(() -> fetchUser(id));
    Subtask<Orders> orders = scope.fork(() -> fetchOrders(id));
    scope.join().throwIfFailed();                   // waits + propagates first failure
    return new Profile(user.get(), orders.get());
}

// ShutdownOnSuccess: return first successful result
try (var scope = new StructuredTaskScope.ShutdownOnSuccess<String>()) {
    scope.fork(() -> serviceA.call());
    scope.fork(() -> serviceB.call());
    return scope.join().result();                   // first to succeed
}
// Automatically cancels remaining tasks when scope exits
```

---
See also: `examples/jdk21/Jdk21Features.java`
