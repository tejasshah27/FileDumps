---
name: backend-developer
description: >
  Expert Java + Spring Boot backend code generation. Use whenever the user asks to write,
  review, refactor, or design any Java code, Spring Boot service, REST API, repository,
  config class, DTO, domain model, scheduler, event, exception handler, filter, interceptor,
  mapper, or any backend component. Triggers on: Java, Spring, Spring Boot, JPA, Hibernate,
  REST, microservice, controller, entity, repository, DTO, mapper, config, backend, endpoint,
  service layer. Apply for any Java code request — even tiny snippets benefit from modern idioms.
  Always default to newest LTS feature available. Always write Sonar-clean, zero-boilerplate code.
---

# Backend Developer — Java + Spring Boot

## North Star
Readable > Clever. Immutable by default. Fail fast. Zero waste (allocations, threads, locks, casts).
Prefer language features over boilerplate. Sonar-clean on first write. Newest LTS feature wins.

---

## JDK 7 — Project Coin: Small Language Fixes

**Diamond `<>`** — never repeat generic type on RHS
```java
Map<String, List<Integer>> map = new HashMap<>();
```

**try-with-resources** — any `AutoCloseable`; no finally needed
```java
try (var in = new FileInputStream(f); var out = new FileOutputStream(g)) { ... }
```

**Multi-catch** — one handler for unrelated exceptions
```java
catch (IOException | SQLException e) { throw new AppException(e); }
```

**String switch** — replaces if-else chains on strings

**Binary literals + numeric underscores** — readability for constants
```java
int mask   = 0b1111_0000;
long limit = 1_000_000_000L;
```

**`Objects` utility** — null-safe helpers
```java
Objects.requireNonNull(param, "param must not be null");
Objects.requireNonNullElse(value, fallback);    // JDK 9
Objects.toString(obj, "default");
boolean eq = Objects.equals(a, b);              // null-safe equals
int h      = Objects.hash(a, b, c);             // multi-field hashCode
Objects.checkIndex(i, list.size());             // JDK 9
```

**NIO.2** (`java.nio.file`) — replace `java.io.File` completely
```java
Path p = Path.of("dir", "file.txt");            // Path.of = JDK 11; Paths.get = JDK 7+
Files.copy(src, dst, StandardCopyOption.REPLACE_EXISTING);
Files.move(src, dst, StandardCopyOption.ATOMIC_MOVE);
Files.createDirectories(path);
Files.walk(dir).filter(Files::isRegularFile).forEach(...);
Files.lines(path, UTF_8).filter(...).collect(toList());
Files.readAllBytes(path);                        // whole file as byte[]
try (var watcher = FileSystems.getDefault().newWatchService()) { ... }
```

**Fork/Join** — divide-and-conquer parallelism
```java
class SumTask extends RecursiveTask<Long> {
    protected Long compute() {
        if (size < THRESHOLD) return computeDirectly();
        var left = new SumTask(...); left.fork();
        return new SumTask(...).compute() + left.join();
    }
}
ForkJoinPool.commonPool().invoke(task);
```

**`ThreadLocalRandom`** — lock-free per-thread random; prefer over `Math.random()` and `new Random()`
```java
int n = ThreadLocalRandom.current().nextInt(0, 100);
```

**`Phaser`** — flexible barrier; prefer over `CyclicBarrier` when party count is dynamic

---

## JDK 8 — Lambdas, Streams, java.time, CompletableFuture

**Lambdas + method refs** — 4 forms; prefer method ref when it reads naturally
```java
list.forEach(System.out::println);          // instance method on arbitrary object
list.stream().map(String::toUpperCase);     // instance method on stream element
list.stream().filter(Objects::nonNull);     // static method
list.stream().map(User::new);              // constructor ref
```

**Functional interface family** (`java.util.function`) — prefer primitive specializations to avoid boxing
```
Function<T,R>     BiFunction<T,U,R>    UnaryOperator<T>   BinaryOperator<T>
Consumer<T>       BiConsumer<T,U>
Supplier<T>
Predicate<T>      BiPredicate<T,U>
// Primitive: avoids boxing overhead in hot paths
IntFunction<R>    ToIntFunction<T>    IntUnaryOperator    IntBinaryOperator
IntConsumer       IntSupplier         IntPredicate
// same prefixes for Long, Double
```

**Streams — complete reference**
```java
// Factories
Stream.of(a, b, c)
Stream.empty()
Stream.generate(UUID::randomUUID).limit(10)         // infinite
Stream.iterate(0, n -> n + 2).limit(5)              // infinite; JDK9 adds 3-arg with predicate
Stream.concat(s1, s2)
IntStream.range(0, 10)                              // [0,10)
IntStream.rangeClosed(1, 10)                        // [1,10]
Arrays.stream(arr)
collection.stream() / .parallelStream()

// Intermediate (lazy, not evaluated until terminal)
.filter(pred)         .map(fn)           .flatMap(fn)
.mapToInt(fn)         .mapToLong(fn)     .mapToDouble(fn)
.distinct()           .sorted()          .sorted(comparator)
.peek(consumer)       .limit(n)          .skip(n)
.mapMulti(biConsumer)                               // JDK16 push-based flatMap
.takeWhile(pred)      .dropWhile(pred)              // JDK9

// Terminal (triggers evaluation)
.collect(collector)   .toList()                     // toList() = JDK16 unmodifiable
.forEach(consumer)    .forEachOrdered(consumer)
.reduce(identity, fn) .reduce(fn)                   // Optional result
.count()
.min(comparator)      .max(comparator)              // Optional<T>
.sum() / .average() / .summaryStatistics()          // IntStream/LongStream/DoubleStream
.anyMatch(pred)       .allMatch(pred)  .noneMatch(pred)
.findFirst()          .findAny()                    // Optional<T>
.toArray()            .toArray(T[]::new)
```

**Collectors — complete reference**
```java
Collectors.toList()                                 // mutable list
Collectors.toUnmodifiableList()                     // JDK10 immutable
Collectors.toSet() / toUnmodifiableSet()
Collectors.toMap(keyFn, valFn)
Collectors.toMap(keyFn, valFn, mergeOnDup)         // merge fn for duplicate keys
Collectors.toUnmodifiableMap(keyFn, valFn)
Collectors.groupingBy(classifier)                   // Map<K, List<V>>
Collectors.groupingBy(classifier, downstream)       // e.g., counting(), summing...
Collectors.partitioningBy(pred)                     // Map<Boolean, List<V>>
Collectors.partitioningBy(pred, downstream)
Collectors.counting()
Collectors.summingInt(fn) / summingLong / summingDouble
Collectors.averagingInt(fn)
Collectors.joining(delimiter, prefix, suffix)
Collectors.mapping(fn, downstream)
Collectors.flatMapping(fn, downstream)              // JDK9
Collectors.filtering(pred, downstream)              // JDK9
Collectors.collectingAndThen(downstream, finisher)
Collectors.teeing(c1, c2, merger)                   // JDK12 — two collectors at once
Collectors.summarizingInt(fn)                       // IntSummaryStatistics
Collectors.toCollection(ArrayList::new)             // specific mutable collection
```

**Optional — complete reference**
```java
// Construction
Optional.of(nonNullValue)                           // NPE if null
Optional.ofNullable(maybeNull)                      // safe
Optional.empty()

// Transform
opt.map(User::getName)
opt.flatMap(u -> Optional.ofNullable(u.getAddress()))
opt.filter(s -> !s.isBlank())

// Consume
opt.ifPresent(this::send)
opt.ifPresentOrElse(this::send, this::logMissing)   // JDK9

// Extract (never use .get() naked)
opt.orElse("default")
opt.orElseGet(this::computeDefault)                 // lazy — prefer over orElse for non-literals
opt.orElseThrow()                                   // JDK10 — NoSuchElementException
opt.orElseThrow(() -> new NotFoundException(id))    // custom
opt.or(() -> fallbackOptional)                      // JDK9 — returns other Optional

// Stream bridge
opt.stream()                                        // JDK9 — 0 or 1 elements; flatMap-friendly

// Rules
// - Return type ONLY; never field / constructor param / collection element
// - Never Optional.get() without isPresent(); use orElseThrow()
// - opt.isPresent() + opt.get() → replace with opt.ifPresent / orElseThrow / map
```

**Default + static interface methods**
```java
interface Validator<T> {
    boolean validate(T t);
    default Validator<T> and(Validator<T> other) { return t -> validate(t) && other.validate(t); }
    default Validator<T> or(Validator<T> other)  { return t -> validate(t) || other.validate(t); }
    static <T> Validator<T> alwaysTrue() { return t -> true; }
}
```

**`java.time`** — ban `Date`, `Calendar`, `SimpleDateFormat` entirely
```java
LocalDate.now() / .of(2024, 1, 15) / .parse("2024-01-15")
LocalTime.now() / .of(14, 30, 0)
LocalDateTime.now(ZoneId.of("UTC"))
ZonedDateTime.now(ZoneId.of("America/New_York"))
OffsetDateTime.now(ZoneOffset.UTC)
Instant.now()                                       // machine timestamp; use for DB/logs
Duration.ofSeconds(30) / Duration.between(t1, t2)
Period.ofDays(7) / Period.between(d1, d2)
date.plus(1, ChronoUnit.MONTHS)
ChronoUnit.DAYS.between(start, end)
DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss")
DateTimeFormatter.ISO_OFFSET_DATE_TIME              // thread-safe — safe as static final
TemporalAdjusters.firstDayOfMonth()
TemporalAdjusters.next(DayOfWeek.MONDAY)
```

**`CompletableFuture`** — async pipelines
```java
CompletableFuture
    .supplyAsync(() -> fetchUser(id), executor)
    .thenApply(User::getName)                       // transform, same thread
    .thenApplyAsync(this::enrich, executor)         // transform, different executor
    .thenCompose(name -> lookupProfile(name))       // chain async step (flatMap equiv)
    .thenCombine(fetchOrders(id), (p, o) -> new View(p, o))  // merge two futures
    .exceptionally(ex -> fallback)                  // recover from exception
    .handle((result, ex) -> ex != null ? fallback : result)  // always runs
    .whenComplete((r, ex) -> audit(r, ex))          // side-effect, preserves result/exception
    .orTimeout(5, SECONDS)                          // JDK9 — completes exceptionally
    .completeOnTimeout(fallback, 5, SECONDS);       // JDK9 — completes with fallback

CompletableFuture.allOf(f1, f2, f3).join();        // wait all; results via f1.get() etc
CompletableFuture.anyOf(f1, f2, f3).join();        // first to complete (any type)
CompletableFuture.failedFuture(ex);                 // JDK9
CompletableFuture.completedStage(value);            // JDK9
```

**Map new methods** — avoid manual get-then-put
```java
map.getOrDefault(key, fallback)
map.putIfAbsent(key, value)                         // atomic check-then-put
map.computeIfAbsent(key, k -> new ArrayList<>())    // canonical cache-miss pattern
map.computeIfPresent(key, (k, v) -> transform(v))
map.compute(key, (k, v) -> v == null ? 1 : v + 1) // null-safe atomic update
map.merge(key, 1, Integer::sum)                     // frequency count idiom
map.forEach((k, v) -> ...)
map.replaceAll((k, v) -> transform(v))
map.remove(key, specificValue)                      // conditional remove (returns boolean)
map.replace(key, oldValue, newValue)               // CAS-style conditional replace
```

**Comparator fluent API**
```java
Comparator.comparing(User::lastName)
    .thenComparing(User::firstName)
    .thenComparingInt(User::age)
    .reversed()
Comparator.naturalOrder() / Comparator.reverseOrder()
Comparator.nullsFirst(Comparator.naturalOrder())
Comparator.comparingInt(String::length)
```

**Collection new methods**
```java
list.removeIf(s -> s.isBlank())         // in-place filter
list.replaceAll(String::trim)           // in-place transform
list.sort(comparator)                   // in-place sort (mergesort, stable)
```

**`LongAdder` / `LongAccumulator`** — high-contention counters; faster than `AtomicLong` under write contention
```java
LongAdder hits = new LongAdder(); hits.increment(); long total = hits.sum();
LongAccumulator max = new LongAccumulator(Long::max, 0);
```

**`StampedLock`** — optimistic read + write; replaces `ReadWriteLock` for read-heavy shared state
```java
long stamp = lock.tryOptimisticRead();
int x = this.x, y = this.y;
if (!lock.validate(stamp)) {
    stamp = lock.readLock();
    try { x = this.x; y = this.y; } finally { lock.unlockRead(stamp); }
}
```

**Math overflow-checked** — use in financial / safety-critical arithmetic
```java
Math.addExact(a, b); Math.subtractExact(a, b);
Math.multiplyExact(a, b); Math.toIntExact(longVal);
// All throw ArithmeticException on overflow
```

**Base64** — replaces Apache Commons
```java
Base64.getEncoder().encodeToString(bytes);
Base64.getDecoder().decode(encoded);
Base64.getUrlEncoder().withoutPadding();     // URL-safe, no padding
Base64.getMimeEncoder(76, CRLF);             // MIME wrapping
```

**Effectively final in lambdas** — captured locals need not be declared `final` but must not be reassigned

**`@FunctionalInterface`** — document intent; compiler enforces exactly one abstract method

---

## JDK 9 — Modules, Factories, Stream/Optional Polish

**Immutable collection factories** — zero-copy, null-hostile; prefer everywhere for literals
```java
List.of(a, b, c)                           // ordered, fixed-size
Set.of(a, b, c)                            // no guaranteed order, no duplicates
Map.of("k1", v1, "k2", v2)               // up to 10 pairs
Map.ofEntries(
    Map.entry("k1", v1),
    Map.entry("k2", v2)                    // unbounded; Map.entry = JDK 9 immutable Entry
)
```

**try-with-resources on effectively final vars** — no re-declaration needed (JDK 9+)
```java
// JDK 7-8: must declare new var in try(...)
// JDK 9+:
try (existingAutoCloseable) { ... }
```

**Stream additions**
```java
Stream.iterate(seed, predicate, step)      // bounded: Stream.iterate(0, n->n<10, n->n+1)
Stream.ofNullable(maybeNull)               // 0 or 1 element; replaces null-check + Stream.of
stream.takeWhile(pred)                     // ordered: elements until pred fails
stream.dropWhile(pred)                     // ordered: skip while pred holds
```

**Optional additions**
```java
opt.ifPresentOrElse(consumer, emptyAction)
opt.or(() -> Optional.of(fallback))        // chain Optional alternatives
opt.stream()                               // Stream<T> of 0 or 1; use in flatMap
```

**Collectors additions**
```java
Collectors.flatMapping(fn, downstream)     // flatMap then collect in one pass
Collectors.filtering(pred, downstream)     // filter inside groupingBy downstream collector
```

**Private interface methods** — extract shared logic from default methods
```java
interface Parser {
    default int parsePositive(String s) { return validated(parse(s)); }
    default int parseNegative(String s) { return validated(-parse(s)); }
    private int parse(String s) { return Integer.parseInt(s.strip()); }
    private int validated(int n) { if (n == 0) throw new IllegalArgumentException(); return n; }
}
```

**`@Deprecated` enriched**
```java
@Deprecated(since = "9", forRemoval = true)    // document lifecycle intent
```

**`VarHandle`** — atomic field ops without `Unsafe`
```java
static final VarHandle VALUE =
    MethodHandles.lookup().findVarHandle(Node.class, "value", int.class);
VALUE.compareAndSet(instance, expected, update);  // CAS
VALUE.getAndAdd(instance, 1);                     // atomic increment
```

**`StackWalker`** — cheap lazy stack inspection; replaces `Thread.currentThread().getStackTrace()`
```java
Optional<String> caller = StackWalker.getInstance()
    .walk(s -> s.skip(1).findFirst().map(StackWalker.StackFrame::getClassName));
```

**Reactive `Flow` API** — `Publisher`, `Subscriber`, `Subscription`, `Processor`; use Reactor/RxJava on top

**Multi-release JARs** — version-specific classes under `META-INF/versions/N/`

---

## JDK 10 — `var`

**`var`** — local type inference; reduces noise without losing type info
```java
var list    = new ArrayList<String>();          // obvious from RHS
var entries = map.entrySet().iterator().next(); // avoids repeating generic type
var result  = service.findById(id);             // method name implies type

// DON'T use when type is non-obvious
var x = getValue();     // BAD — reader can't tell type
var flag = true;        // BAD — boolean is short enough

// OK in for-each
for (var entry : map.entrySet()) { ... }
for (var item  : items)          { ... }
```

**`List.copyOf`, `Set.copyOf`, `Map.copyOf`** — defensive immutable snapshot (throws on null elements)

**`Collectors.toUnmodifiableList/Set/Map`**

**`Optional.orElseThrow()`** — no-arg; always prefer over `get()` (Sonar S2689)

---

## JDK 11 (LTS) — String Polish, Files, HTTP Client

**`var` in lambda params** — enables annotations on lambda parameters
```java
list.stream().map((@NonNull var s) -> s.trim()).toList();
```

**String methods**
```java
"  hi  ".isBlank()                  // true if empty or Unicode whitespace only
"  hi  ".strip()                    // Unicode-aware trim (not just ASCII 0x20)
"  hi  ".stripLeading()
"  hi  ".stripTrailing()
"ha".repeat(3)                      // "hahaha"
"a\nb\nc".lines()                   // Stream<String> without regex split overhead
```

**`Files` one-liners**
```java
String  content = Files.readString(path, UTF_8);
Files.writeString(path, content, UTF_8, CREATE, TRUNCATE_EXISTING);
```

**`Path.of()`** — same as `Paths.get()`, cleaner factory name

**`Predicate.not()`** — negate method references
```java
list.stream().filter(Predicate.not(String::isBlank))
stream.filter(Predicate.not(seen::contains))
```

**`Collection.toArray(IntFunction)`** — no unchecked cast
```java
String[] arr = list.toArray(String[]::new);
```

**HTTP Client** — async/sync; replaces `HttpURLConnection`
```java
var client = HttpClient.newBuilder()
    .connectTimeout(Duration.ofSeconds(5))
    .followRedirects(NORMAL)
    .executor(executor)
    .build();

HttpRequest req = HttpRequest.newBuilder(URI.create(url))
    .header("Accept", "application/json")
    .timeout(Duration.ofSeconds(10))
    .GET().build();

// Sync
HttpResponse<String> res = client.send(req, BodyHandlers.ofString());

// Async
client.sendAsync(req, BodyHandlers.ofString())
      .thenApply(HttpResponse::body)
      .thenAccept(this::process);
```

**`InputStream` additions**
```java
byte[] all  = in.readAllBytes();
byte[] n    = in.readNBytes(1024);
long  count = in.transferTo(outputStream);
InputStream.nullInputStream()      // /dev/null source
OutputStream.nullOutputStream()    // /dev/null sink
```

**`Pattern.asMatchPredicate()`** — full-match semantics (like `matches()`); `asPredicate()` = `find()`

**`CharSequence.compare(a, b)`** — static lexicographic compare

---

## JDK 12–16 — Expressions, Text Blocks, Records, Pattern instanceof

**Switch expressions (finalized JDK 14, JEP 361)**
```java
// Arrow form: no fall-through, no break, exhaustive
int days = switch (month) {
    case JANUARY, MARCH, MAY, JULY, AUGUST, OCTOBER, DECEMBER -> 31;
    case APRIL, JUNE, SEPTEMBER, NOVEMBER -> 30;
    case FEBRUARY -> Year.isLeap(year) ? 29 : 28;
};

// Block form with yield
String label = switch (status) {
    case 200 -> "OK";
    default -> {
        log.warn("unknown status: {}", status);
        yield "UNKNOWN_" + status;
    }
};
```

**Text blocks (finalized JDK 15, JEP 378)** — multiline strings; no concatenation or escaping
```java
// Indentation baseline = closing """
// Opening """ must be followed by newline
String json = """
        {
          "name": "%s",
          "active": true
        }
        """.formatted(user.name());   // .formatted() = JDK 15

String sql = """
        SELECT u.id, u.email, r.name AS role
        FROM users u
        JOIN roles r ON r.id = u.role_id
        WHERE u.active = true
          AND u.created_at > :since
        ORDER BY u.created_at DESC
        """;

// Escape sequences in text blocks
// \  = suppress newline (line continuation)
String msg = """
        Hello, \
        World!""";          // "Hello, World!" — no embedded newline

// \s = preserve trailing whitespace (otherwise stripped)
String col = """
        Alice  \s
        Bob    \s
        """;

// \ and " do not need escaping inside text blocks (except """ needs one escaped)
```

**Records (finalized JDK 16, JEP 395)** — immutable data carrier
```java
// Auto-generated: canonical constructor, accessors (name()), equals, hashCode, toString
record Point(double x, double y) {
    // Compact canonical constructor — validation / normalization (no explicit this.x = x needed)
    Point {
        if (Double.isNaN(x) || Double.isNaN(y)) throw new IllegalArgumentException();
        x = Math.round(x * 1000) / 1000.0;  // normalize in compact constructor
    }

    // Additional constructors must delegate
    Point(double scalar) { this(scalar, scalar); }

    // Static factories
    static Point origin() { return new Point(0, 0); }

    // Instance methods
    double distanceTo(Point other) { return Math.hypot(x - other.x, y - other.y); }

    // Static fields OK; instance fields NOT OK (must be record components only)
    private static final Point ORIGIN = new Point(0, 0);
}

// Records can implement interfaces
record Range(int start, int end) implements Comparable<Range> {
    Range { if (end < start) throw new IllegalArgumentException(); }
    public int compareTo(Range o) { return Integer.compare(start, o.start); }
}

// Generic records
record Pair<A, B>(A first, B second) {}
record Result<T>(T value, String error) {
    static <T> Result<T> ok(T v)   { return new Result<>(v, null); }
    static <T> Result<T> err(String e) { return new Result<>(null, e); }
    boolean isOk() { return error == null; }
}
```

**Pattern matching `instanceof` (finalized JDK 16, JEP 394)**
```java
// Before: boilerplate cast
if (obj instanceof String) { String s = (String) obj; ... }

// After: binding variable in scope within true-branch
if (obj instanceof String s && !s.isBlank()) { use(s); }
if (obj instanceof Integer i) return i * 2;

// Negation: s NOT in scope in else-branch
if (!(obj instanceof String s)) throw new IllegalArgumentException();
// s IS in scope here (after the throw)
```

**`Stream.toList()`** — shorthand `collect(toUnmodifiableList())`; null-hostile; no cast
```java
List<String> names = users.stream().map(User::name).toList();
```

**`Stream.mapMulti(BiConsumer<T, Consumer<R>>)`** — push-based flatMap; better for conditional/variable expansion
```java
stream.mapMulti((user, push) -> {
    if (user.isActive()) push.accept(user.email());
    user.aliases().forEach(push);
});
```

**Sealed classes (finalized JDK 17, JEP 409)** — closed hierarchy; enables exhaustive switch
```java
sealed interface Shape permits Circle, Rectangle, Triangle {}

record Circle(double radius) implements Shape {}
record Rectangle(double w, double h) implements Shape {}
final class Triangle implements Shape {          // final, sealed, or non-sealed
    private final double base, height;
    Triangle(double base, double height) { this.base = base; this.height = height; }
    double area() { return 0.5 * base * height; }
}

// Compiler verifies exhaustiveness — no default needed for sealed types
double area = switch (shape) {
    case Circle c    -> Math.PI * c.radius() * c.radius();
    case Rectangle r -> r.w() * r.h();
    case Triangle t  -> t.area();
};
```

**Helpful NullPointerExceptions (JDK 14, JEP 358)** — JVM reports which reference was null; no code change; always enable in prod: `-XX:+ShowCodeDetailsInExceptionMessages`

**`String.indent(n)` (JDK 12)** — add (n>0) or remove (n<0) leading spaces per line; ensures trailing newline

**`String.transform(Function<String,R>)` (JDK 12)** — pipe string through function; fluent chaining
```java
String result = " hello ".transform(String::strip).transform(String::toUpperCase);
```

**`Files.mismatch(Path, Path)` (JDK 12)** — first differing byte position; -1 if identical

**Compact number format (JDK 12)**
```java
NumberFormat.getCompactNumberInstance(Locale.US, Style.SHORT).format(1_500_000);  // "1.5M"
```

**`Collectors.teeing(c1, c2, merger)` (JDK 12)** — two collectors in one pass
```java
var stats = stream.collect(Collectors.teeing(
    Collectors.summingLong(Order::amount),
    Collectors.counting(),
    (sum, count) -> new Summary(sum, count)));
```

**Enhanced pseudo-random (JDK 17, JEP 356)** — algorithm-pluggable; `RandomGenerator` interface
```java
RandomGenerator rng = RandomGeneratorFactory.of("L64X128MixRandom").create();
rng.ints(100, 0, 100).boxed().toList();
```

---

## JDK 21 (LTS) — Virtual Threads, Pattern Switch, Sequenced Collections

**Virtual threads (JEP 444)** — M:N onto OS threads; blocking I/O unmounts, not parks
```java
// Explicit
Thread.ofVirtual().name("task-", 0).start(() -> process());

// Executor (preferred for structured work)
try (var exec = Executors.newVirtualThreadPerTaskExecutor()) {
    exec.submit(this::fetchFromDb);
    exec.submit(this::callRemoteService);
}

// Spring Boot 3.2+: spring.threads.virtual.enabled=true
// Auto-configures: Tomcat, @Async, scheduled tasks, etc.

// Rules:
// 1. Never pool virtual threads — create one per task
// 2. Replace synchronized with ReentrantLock (synchronized pins carrier thread)
// 3. Replace ThreadLocal with ScopedValue for propagated request context
// 4. No benefit for CPU-bound loops; only helps on I/O-bound blocking code
// 5. Thread.sleep(Duration) on virtual thread = cheap yield, not park
```

**Sequenced Collections (JEP 431)** — `SequencedCollection`, `SequencedSet`, `SequencedMap`
```java
list.getFirst() / list.getLast()            // replaces get(0) / get(size()-1)
list.addFirst(e) / list.addLast(e)
list.removeFirst() / list.removeLast()
list.reversed()                             // reversed view, no copy

deque.getFirst() / deque.getLast()          // Deque now implements SequencedCollection

map.firstEntry() / map.lastEntry()
map.sequencedKeySet() / map.sequencedValues() / map.sequencedEntrySet()
// LinkedHashMap, LinkedHashSet, TreeMap, TreeSet all benefit
```

**Pattern matching for switch (JEP 441)** — type patterns + guards + null
```java
String describe(Object obj) {
    return switch (obj) {
        case null                       -> "null";
        case Integer i when i < 0       -> "negative int";
        case Integer i                  -> "non-negative int: " + i;
        case Long l                     -> "long: " + l;
        case String s when s.isBlank()  -> "blank string";
        case String s                   -> "string: " + s;
        case int[] arr                  -> "int array len=" + arr.length;
        case Point(int x, int y)        -> "point at " + x + "," + y;  // record pattern
        default                         -> obj.getClass().getSimpleName();
    };
}

// Sealed type: exhaustive, no default required
double area(Shape s) {
    return switch (s) {
        case Circle c    -> Math.PI * c.radius() * c.radius();
        case Rectangle r -> r.w() * r.h();
        case Triangle t  -> t.area();
    };
}
```

**Record patterns (JEP 440)** — destructure records in pattern position
```java
// instanceof
if (obj instanceof Point(int x, int y)) { /* x and y bound */ }

// Nested
if (response instanceof ApiResponse(User(String name, _), int code)) { ... }

// In switch
String render(Shape shape) {
    return switch (shape) {
        case Circle(double r)               -> "circle r=%.2f".formatted(r);
        case Rectangle(double w, double h)  -> "rect %sx%s".formatted(w, h);
        case Triangle t                     -> "triangle area=%.2f".formatted(t.area());
    };
}
```

**Unnamed patterns `_` and unnamed variables `_` (finalized JDK 22, JEP 456)**
```java
// Unnamed pattern — ignore record component
case Rectangle(double w, _)    -> ...   // height not needed

// Unnamed variable — suppress unused-variable warning
try { ... } catch (Exception _) { }     // intentional swallow (still log in prod)
for (var _ : list) total++;             // iterate for side effect only
try (var _ = meter.time()) { ... }      // resource for side effect only
int _ = computeAndDiscard();            // result intentionally unused
```

**Scoped values (JEP 446 → finalized ~JDK 25)**
```java
static final ScopedValue<RequestContext> CTX = ScopedValue.newInstance();

// Bind for duration of call tree — immutable, inherited by virtual thread children
ScopedValue.where(CTX, ctx).run(() -> service.handle(request));

// With return value
Result r = ScopedValue.where(CTX, ctx).call(() -> service.handle(request));

// Read anywhere in call tree
RequestContext ctx = CTX.get();

// Prefer over InheritableThreadLocal — safe with virtual threads, immutable
```

**Structured concurrency (JEP 453 → stabilizing)**
```java
// ShutdownOnFailure: cancel all when any fails
try (var scope = new StructuredTaskScope.ShutdownOnFailure()) {
    Subtask<User>   user   = scope.fork(() -> fetchUser(id));
    Subtask<Orders> orders = scope.fork(() -> fetchOrders(id));
    scope.join().throwIfFailed();                   // waits + propagates first failure
    return new Profile(user.get(), orders.get());
}

// ShutdownOnSuccess: return first successful result
try (var scope = new StructuredTaskScope.ShutdownOnSuccess<String>()) {
    scope.fork(() -> serviceA.call());
    scope.fork(() -> serviceB.call());
    return scope.join().result();                   // first to succeed
}
// Automatically cancels remaining tasks when scope exits
```

---

## JDK 22–25 — Stream Gatherers, Flexible Constructors, Primitive Patterns

**Stream Gatherers (finalized JDK 24, JEP 485)** — custom intermediate stream operators
```java
// Built-in Gatherers (java.util.stream.Gatherers)
stream.gather(Gatherers.windowFixed(3))        // non-overlapping List<T> windows
stream.gather(Gatherers.windowSliding(3))      // overlapping List<T> windows
stream.gather(Gatherers.scan(identity, fn))    // running accumulation (keeps intermediates)
stream.gather(Gatherers.fold(identity, fn))    // like reduce but as gatherer (single result)
stream.gather(Gatherers.mapConcurrent(4, fn))  // parallel map with max concurrency

// Custom gatherer
Gatherer<String, ?, String> deduplicate = Gatherer.ofSequential(
    HashSet::new,
    (seen, element, downstream) -> {
        if (seen.add(element)) downstream.push(element);
        return true;
    }
);
stream.gather(deduplicate).toList();
```

**Flexible constructor bodies (JEP 482 preview)** — statements before `super()`/`this()`
```java
class Validated extends Base {
    Validated(String s) {
        Objects.requireNonNull(s, "s");     // validation before super() — now legal
        super(s.trim());
    }
}
```

**Module import declarations (JEP 476 preview)**
```java
import module java.sql;                     // imports all packages exported by java.sql
import module java.net.http;
```

**Primitive types in patterns (JEP 455 preview)** — patterns over primitives
```java
switch (intValue) {
    case int i when i < 0   -> "negative";
    case int i              -> "non-negative";
}
// instanceof with unboxing
Object obj = 42;
if (obj instanceof int i) { /* i is unboxed int */ }
```

**`String.formatted()` (JDK 15)** — instance method; pair with text blocks
```java
String body = """
        Dear %s,
        Order #%d has shipped to %s.
        """.formatted(name, orderId, address);
```

**Compact object headers (JDK 24 experimental, JEP 450)** — object header shrinks from 12-16 bytes → 8 bytes; no code change; enable: `-XX:+UseCompactObjectHeaders`

**Class-file API (finalized JDK 24, JEP 484)** — programmatic bytecode generation; replaces ASM in framework internals

---

## Cross-Cutting Idioms

### String Building
```java
// Multiline:        text block (JDK 15+)
// Single concat:    + operator (JIT inlines via invokedynamic since JDK 9)
// Loops:            StringBuilder with size hint
var sb = new StringBuilder(items.size() * 20);
for (var item : items) sb.append(item).append(',');
String result = sb.deleteCharAt(sb.length() - 1).toString();

// Streams:          Collectors.joining (most concise)
items.stream().collect(Collectors.joining(", ", "[", "]"));

// Formatting:       .formatted() or String.format for structured output
// NEVER:            += in a loop (creates new String each iteration)
```

### Null Safety
```java
// Chain optional navigation
return Optional.ofNullable(user)
    .map(User::getAddress)
    .map(Address::getCity)
    .orElse("unknown");

// Null-safe utility
Objects.requireNonNull(param, () -> "param null in " + caller());
Objects.requireNonNullElse(value, fallback);
Objects.toString(nullable, "");
```

### Exception Handling
```java
// Fail fast with context
if (items.isEmpty()) throw new IllegalArgumentException("items must not be empty for " + operationName);

// Custom hierarchy — sealed for exhaustive handling
sealed interface AppError permits NotFoundError, ValidationError, ConflictError {}
record NotFoundError(String entity, Object id) implements AppError {}

// Wrap checked exceptions for stream compatibility
@FunctionalInterface
interface ThrowingFunction<T, R> {
    R apply(T t) throws Exception;
    static <T, R> Function<T, R> wrap(ThrowingFunction<T, R> f) {
        return t -> { try { return f.apply(t); }
                      catch (RuntimeException e) { throw e; }
                      catch (Exception e) { throw new RuntimeException(e); } };
    }
}
list.stream().map(ThrowingFunction.wrap(this::process))

// Multi-catch for unrelated exceptions sharing same handling
catch (TimeoutException | ConnectException e) { throw new ServiceUnavailableException(e); }
```

### Immutability Patterns
```java
// Literals:       List.of / Set.of / Map.of
// Defensive copy: List.copyOf / Set.copyOf / Map.copyOf
// Data objects:   record (compiler-enforced)
// Complex builds: builder pattern returning record or final class

record Config(String host, int port, boolean tls) {
    static Builder builder() { return new Builder(); }
    static final class Builder {
        private String host = "localhost"; private int port = 8080; private boolean tls = false;
        public Builder host(String h) { this.host = h; return this; }
        public Builder port(int p)   { this.port = p; return this; }
        public Builder tls(boolean t){ this.tls = t; return this; }
        public Config build()        { return new Config(host, port, tls); }
    }
}
```

### Concurrency Guide
```java
// I/O-bound parallelism:   Virtual threads (JDK 21+)
// Async fan-out:           StructuredTaskScope (JDK 21+) or CompletableFuture.allOf
// Async chain:             CompletableFuture
// Scheduled tasks:         ScheduledExecutorService (not Timer — not thread-safe)
// Read-heavy shared state: StampedLock optimistic read
// Write-heavy counter:     LongAdder / LongAccumulator
// Once-per-request context: ScopedValue (JDK 21+) over InheritableThreadLocal

// Virtual thread: use ReentrantLock, not synchronized
private final ReentrantLock lock = new ReentrantLock();
lock.lock();
try { /* critical section */ } finally { lock.unlock(); }
```

### Collections Choice
```java
// ArrayList      — default; index access O(1); iteration fast (cache-friendly)
// LinkedList     — only when frequent head/tail insertion/removal; slower iteration
// ArrayDeque     — stack/queue; prefer over Stack and LinkedList
// HashMap        — default map
// LinkedHashMap  — insertion-order iteration
// TreeMap        — sorted key iteration (NavigableMap)
// EnumMap        — enum keys: bit-vector backed, fastest possible map
// ConcurrentHashMap — thread-safe reads; segment-locked writes (no global lock)
// CopyOnWriteArrayList — read-heavy, write-rare thread-safe list

// Pre-size maps to avoid rehash: new HashMap<>(expectedSize * 2)
// EnumSet for enum-value flag sets (bit operations internally)
```

### I/O
```java
// Small files:  Files.readString / Files.readAllBytes
// Large files:  Files.lines (streaming, buffered)
// Binary:       InputStream.readAllBytes / readNBytes / transferTo
// Write:        Files.writeString / Files.write
// Always specify charset explicitly: UTF_8 (StandardCharsets.UTF_8)
```

### Performance Checklist
```
☐ Avoid autoboxing in hot paths — use primitive streams (IntStream/LongStream)
☐ Pre-size collections when size is known
☐ EnumMap/EnumSet for enum keys/values
☐ Static final Pattern.compile() — not per-call
☐ static final DateTimeFormatter — thread-safe
☐ StringBuilder with capacity hint in loops
☐ Prefer Stream.toList() over collect(toList()) — no extra allocation
☐ Prefer List.copyOf() over new ArrayList<>(list) for read-only defensive copy
☐ LongAdder over AtomicLong for high-contention increments
☐ VarHandle over Unsafe for lock-free field access
```

---

## Spring Boot Patterns

### Injection — always constructor injection (Sonar: field injection = S3016)
```java
@Service
@RequiredArgsConstructor                 // Lombok generates constructor
public class OrderService {
    private final OrderRepository repo;
    private final PaymentGateway gateway;
    private final ApplicationEventPublisher events;
}
```

### Configuration
```java
// Prefer @ConfigurationProperties over @Value for related groups
@ConfigurationProperties(prefix = "app.payment")
record PaymentConfig(
    @NotBlank String apiKey,
    @NotNull URI endpoint,
    @DurationUnit(ChronoUnit.SECONDS) Duration timeout
) {}

// Register
@EnableConfigurationProperties(PaymentConfig.class)
```

### DTOs — use records
```java
record UserDto(UUID id, String name, String email) {
    static UserDto from(User u) {
        return new UserDto(u.getId(), u.getName(), u.getEmail());
    }
}

// Spring Data projection (avoids loading full entity)
interface UserSummary { UUID getId(); String getName(); }
List<UserSummary> findAllProjectedBy();
```

### Repositories
```java
// Derived for simple queries
Optional<User> findByEmailIgnoreCase(String email);
boolean existsByEmail(String email);
List<User> findByActiveTrueOrderByCreatedAtDesc();

// Text block SQL for complex queries
@Query(value = """
        SELECT u FROM User u
        JOIN FETCH u.roles r
        WHERE u.active = true
          AND r.name = :role
        """)
List<User> findActiveByRole(@Param("role") String role);

// Avoid N+1 — use JOIN FETCH or @EntityGraph
@EntityGraph(attributePaths = {"roles", "address"})
Optional<User> findWithDetailsById(UUID id);
```

### Exception Handling
```java
@RestControllerAdvice
public class GlobalExceptionHandler extends ResponseEntityExceptionHandler {
    @ExceptionHandler(EntityNotFoundException.class)
    ProblemDetail handleNotFound(EntityNotFoundException ex, HttpServletRequest req) {
        var pd = ProblemDetail.forStatusAndDetail(NOT_FOUND, ex.getMessage());
        pd.setInstance(URI.create(req.getRequestURI()));
        return pd;
    }
}
```

### Virtual Threads + Spring Boot 3.2+
```java
// application.properties
spring.threads.virtual.enabled=true
// Automatically configures: Tomcat executor, @Async, @Scheduled, task executors
```

---

## Sonar Rules — Always Apply

```
S1481  Remove unused local variables
S1854  Remove useless variable assignments
S2095  Close resources in try-with-resources
S2789  Don't check Optional for null (always non-null)
S3776  Cognitive complexity > 15 → refactor
S4973  Compare Strings with equals(), not ==
S6201  Use pattern matching instanceof (not cast after check)
S6204  Use Stream.toList() over collect(toUnmodifiableList())
S6206  Use record for pure data classes
S1905  Remove redundant casts
S4266  Use isEmpty() over size() == 0
S1192  Extract duplicate string literals to constants
S2153  No boxing immediately followed by unboxing
S3518  Divisor must not be zero (validate)
S1135  No committed TODO/FIXME (use issue tracker)
S2055  Write-only fields should be removed
S3016  Avoid field injection (@Autowired on field)
```

---

## Quick Decision Reference

| Need | Best choice |
|------|-------------|
| Immutable data object | `record` |
| Closed type hierarchy | `sealed interface` + `record` subtypes |
| Absent return value | `Optional<T>` |
| Multiline string | Text block `"""..."""` |
| Complex conditional value | Switch expression `->` |
| High-contention counter | `LongAdder` |
| Async fan-out, cancel on failure | `StructuredTaskScope.ShutdownOnFailure` |
| Thread-inherited context (virtual) | `ScopedValue` |
| Async pipeline / chain | `CompletableFuture` |
| I/O-bound parallelism | Virtual thread executor |
| Immutable literal collection | `List.of` / `Set.of` / `Map.of` |
| Defensive immutable copy | `List.copyOf` / `Map.copyOf` |
| Custom stream intermediate op | `Stream.gather(Gatherer)` JDK24 |
| File read/write | `Files.readString` / `Files.writeString` |
| HTTP call (no Spring) | `HttpClient` JDK11 |
| Lock-free field CAS | `VarHandle` |
| Read-heavy shared struct | `StampedLock` optimistic |
| Enum-keyed map | `EnumMap` |
| Spring config group | `@ConfigurationProperties` + `record` |
| Spring DTO | `record` + static factory |
| Null-safe navigation | `Optional.map().flatMap()` |
| Ignore exception variable | `catch (Exception _)` JDK22 |
| Ignore record component | `case Foo(int x, _)` JDK22 |
