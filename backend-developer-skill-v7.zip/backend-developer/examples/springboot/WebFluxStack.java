package examples.springboot.webflux;

import org.springframework.context.annotation.*;
import org.springframework.data.annotation.Id;
import org.springframework.data.r2dbc.repository.Query;
import org.springframework.data.r2dbc.repository.R2dbcRepository;
import org.springframework.data.relational.core.mapping.Table;
import org.springframework.http.*;
import org.springframework.security.config.annotation.method.configuration.EnableReactiveMethodSecurity;
import org.springframework.security.config.annotation.web.reactive.EnableWebFluxSecurity;
import org.springframework.security.config.web.server.ServerHttpSecurity;
import org.springframework.security.web.server.SecurityWebFilterChain;
import org.springframework.security.config.Customizer;
import org.springframework.stereotype.*;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.reactive.function.client.*;
import org.springframework.web.reactive.function.server.*;
import org.springframework.web.server.*;
import reactor.core.publisher.*;
import reactor.core.scheduler.Schedulers;
import reactor.util.retry.Retry;

import jakarta.validation.Valid;
import jakarta.validation.constraints.*;
import java.net.URI;
import java.time.*;
import java.util.*;

/**
 * Spring WebFlux — complete reactive stack (R2DBC + WebClient + Router + Security)
 *
 * SCENARIO GUIDE — when to use each reactive pattern shown here:
 *
 * ── Programming model choice ────────────────────────────────────────────────
 * Choose WebFlux (this file) when:
 *   - Serving Server-Sent Events, WebSocket streams, or large file streams
 *   - Fully reactive downstream (R2DBC, reactive Redis/Mongo, reactive 3rd-party clients)
 *   - Very high concurrency with tight thread budget (embedded device, cloud function)
 *   - Kotlin coroutines team — coroutines integrate natively with WebFlux
 * Choose Spring MVC (OrderServiceStack.java) when:
 *   - Team is primarily imperative Java — easier to debug and test
 *   - Using JPA/Hibernate — it is inherently blocking; mixing with WebFlux requires workarounds
 *   - On JDK 21+ with spring.threads.virtual.enabled=true — virtual threads close the gap
 *   - Domain logic is complex — imperative code is far easier to reason about
 *
 * ── @RestController vs Router functions ────────────────────────────────────
 * @RestController — familiar, annotation-driven; use for standard REST APIs (shown in OrderReactiveController)
 * Router functions — programmatic, composable; use for:
 *   - Dynamic route registration at runtime
 *   - Nested route groups with shared filters
 *   - Testing handlers in isolation without Netty (shown in OrderRouter + OrderHandler)
 *
 * ── flatMap vs flatMapSequential ──────────────────────────────────────────
 * flatMap(fn)            — concurrent; results arrive in completion order (not input order)
 * flatMapSequential(fn)  — concurrent internally; output preserves input order
 * USE flatMap WHEN: order does not matter (fan-out HTTP calls, parallel lookups)
 * USE flatMapSequential WHEN: order matters (pagination, ordered event stream)
 *
 * ── Mono.zip vs sequential flatMap ────────────────────────────────────────
 * Mono.zip(a, b)         — subscribes to a and b simultaneously; ideal for independent calls
 * a.flatMap(r -> b(r))   — sequential; each step waits for the previous result
 * USE zip WHEN: calls are independent (fetch user + fetch orders for same ID simultaneously)
 * USE sequential flatMap WHEN: call B depends on the result of call A
 *
 * ── Error handling ─────────────────────────────────────────────────────────
 * onErrorReturn     — simple fallback value; does not retry
 * onErrorResume     — fallback reactive pipeline (e.g. cache → DB fallback)
 * onErrorMap        — translate infrastructure exception → domain exception at boundary
 * retryWhen         — retry on transient errors with backoff; never retry on business errors
 * @ExceptionHandler — global HTTP error mapping in @RestControllerAdvice
 *
 * ── R2DBC vs JPA ───────────────────────────────────────────────────────────
 * R2DBC — non-blocking; no lazy loading; no first-level cache; simpler entity model
 *         Use with WebFlux for fully reactive I/O
 * JPA   — rich ORM; lazy loading; caching; complex domain model support
 *         Use with Spring MVC or virtual threads (blocking is fine on VTs)
 * NEVER mix JPA + WebFlux — JPA blocks the event loop and starves Netty
 *
 * ── Reactive Context vs MDC ────────────────────────────────────────────────
 * MDC alone is unreliable in WebFlux — reactive pipelines can switch threads.
 * Use Reactor Context (contextWrite / deferContextual) for per-request data.
 * Bridge to MDC for Logback with Hooks.enableAutomaticContextPropagation().
 *
 * ── block() is forbidden inside a reactive pipeline ───────────────────────
 * Calling .block() on Netty's event loop thread causes BlockingOperationError.
 * If you must call blocking code (legacy library, JDBC), offload to:
 *   Mono.fromCallable(() -> blockingCall()).subscribeOn(Schedulers.boundedElastic())
 * Never use Schedulers.parallel() for blocking — it has a fixed thread count.
 *
 * ── Testing ────────────────────────────────────────────────────────────────
 * StepVerifier    — unit-test any Mono/Flux pipeline without HTTP; use withVirtualTime for timeouts
 * WebTestClient   — HTTP-level integration tests; works with @WebFluxTest and @SpringBootTest
 * @WebFluxTest    — slice test: loads only web layer; mock services with @MockBean
 */

// ─── Domain Entity (R2DBC) ──────────────────────────────────────────────────

@Table("orders")
class Order {
    @Id
    private UUID    id;
    private String  customerId;
    private String  status;
    private long    amountCents;
    private String  currencyCode;
    private Instant createdAt;
    private Instant updatedAt;

    Order() {}

    Order(String customerId, long amountCents, String currencyCode) {
        this.customerId  = Objects.requireNonNull(customerId, "customerId");
        this.amountCents = amountCents;
        this.currencyCode = Objects.requireNonNull(currencyCode, "currencyCode");
        this.status      = "PENDING";
        this.createdAt   = Instant.now();
    }

    // Accessors
    public UUID    getId()          { return id; }
    public String  getCustomerId()  { return customerId; }
    public String  getStatus()      { return status; }
    public long    getAmountCents() { return amountCents; }
    public String  getCurrencyCode(){ return currencyCode; }
    public Instant getCreatedAt()   { return createdAt; }

    // Setters required by R2DBC mapping
    public void setId(UUID id)             { this.id = id; }
    public void setCustomerId(String c)    { this.customerId = c; }
    public void setStatus(String s)        { this.status = s; }
    public void setAmountCents(long a)     { this.amountCents = a; }
    public void setCurrencyCode(String c)  { this.currencyCode = c; }
    public void setCreatedAt(Instant t)    { this.createdAt = t; }
    public void setUpdatedAt(Instant t)    { this.updatedAt = t; }
}

// ─── DTOs — records (immutable, zero boilerplate) ───────────────────────────

record CreateOrderRequest(
    @NotBlank String customerId,
    @Positive long amountCents,
    @NotBlank String currencyCode
) {}

record OrderResponse(UUID id, String customerId, String status, long amountCents, Instant createdAt) {
    static OrderResponse from(Order o) {
        return new OrderResponse(o.getId(), o.getCustomerId(),
            o.getStatus(), o.getAmountCents(), o.getCreatedAt());
    }
}

// ─── R2DBC Repository ───────────────────────────────────────────────────────

interface OrderRepository extends R2dbcRepository<Order, UUID> {

    // Derived method — Spring Data generates the query
    Flux<Order> findByCustomerId(String customerId);

    // Custom query — use text block for readability on multi-line SQL
    @Query("""
           SELECT * FROM orders
           WHERE customer_id = :customerId
             AND status      = :status
           ORDER BY created_at DESC
           """)
    Flux<Order> findByCustomerIdAndStatus(String customerId, String status);

    Mono<Boolean> existsByCustomerIdAndStatus(String customerId, String status);
    Mono<Long>    countByCustomerId(String customerId);
}

// ─── Domain Events (records, immutable) ─────────────────────────────────────

record OrderCreatedEvent(UUID orderId, String customerId, long amountCents, Instant occurredAt) {
    OrderCreatedEvent(UUID orderId, String customerId, long amountCents) {
        this(orderId, customerId, amountCents, Instant.now());
    }
}

// ─── Service — fully reactive ────────────────────────────────────────────────

@Service
@Transactional   // R2dbcTransactionManager handles reactive transactions
class OrderService {

    private static final org.slf4j.Logger log =
        org.slf4j.LoggerFactory.getLogger(OrderService.class);

    private final OrderRepository         repo;
    private final PaymentGatewayClient    paymentClient;
    private final reactor.core.publisher.Sinks.Many<OrderCreatedEvent> eventSink;

    OrderService(OrderRepository repo, PaymentGatewayClient paymentClient) {
        this.repo          = repo;
        this.paymentClient = paymentClient;
        // Hot sink — multicasts events to all active SSE subscribers
        this.eventSink     = Sinks.many().multicast().onBackpressureBuffer();
    }

    public Mono<OrderResponse> create(CreateOrderRequest req) {
        var order = new Order(req.customerId(), req.amountCents(), req.currencyCode());

        return repo.save(order)
            .flatMap(saved -> {
                // Fan-out: charge payment concurrently with publishing event
                // Mono.zip — both subscriptions start simultaneously
                var charge = paymentClient.charge(saved.getId(), saved.getAmountCents());
                var event  = Mono.fromRunnable(() -> {
                    var evt = new OrderCreatedEvent(saved.getId(), saved.getCustomerId(), saved.getAmountCents());
                    eventSink.tryEmitNext(evt);
                });
                return Mono.zip(charge, event).thenReturn(saved);
            })
            .map(OrderResponse::from)
            .doOnSuccess(r  -> log.info("Order created id={} customer={}", r.id(), r.customerId()))
            .doOnError(ex -> log.error("Order creation failed for customer={}", req.customerId(), ex));
    }

    @Transactional(readOnly = true)
    public Mono<OrderResponse> findById(UUID id) {
        return repo.findById(id)
            .map(OrderResponse::from)
            .switchIfEmpty(Mono.error(new NotFoundException("Order not found: " + id)));
    }

    @Transactional(readOnly = true)
    public Flux<OrderResponse> streamByCustomer(String customerId) {
        return repo.findByCustomerId(customerId)
            .map(OrderResponse::from);
    }

    // Live event stream — returns a Flux backed by the hot sink; client disconnects cancel
    public Flux<OrderCreatedEvent> orderEventStream() {
        return eventSink.asFlux();
    }
}

// ─── WebClient — reactive outbound HTTP ─────────────────────────────────────

@Component
class PaymentGatewayClient {

    private static final org.slf4j.Logger log =
        org.slf4j.LoggerFactory.getLogger(PaymentGatewayClient.class);

    // ALWAYS a singleton — never new WebClient() per request
    private final WebClient client;

    PaymentGatewayClient(@org.springframework.beans.factory.annotation.Value("${app.payment.base-url:http://localhost:9090}") String baseUrl) {
        this.client = WebClient.builder()
            .baseUrl(baseUrl)
            .defaultHeader(HttpHeaders.CONTENT_TYPE, MediaType.APPLICATION_JSON_VALUE)
            .codecs(c -> c.defaultCodecs().maxInMemorySize(512 * 1024))  // 512 KB
            .filter(ExchangeFilterFunction.ofRequestProcessor(req -> {
                log.debug("→ Payment {} {}", req.method(), req.url());
                return Mono.just(req);
            }))
            .build();
    }

    public Mono<Void> charge(UUID orderId, long amountCents) {
        return client.post()
            .uri("/charges")
            .bodyValue(Map.of("orderId", orderId, "amountCents", amountCents))
            .retrieve()
            // Map 4xx → domain exception (do NOT retry business failures)
            .onStatus(HttpStatusCode::is4xxClientError,
                      res -> res.bodyToMono(String.class)
                                .map(body -> new PaymentDeclinedException("Declined: " + body)))
            // Map 5xx → transient exception (eligible for retry)
            .onStatus(HttpStatusCode::is5xxServerError,
                      res -> Mono.error(new GatewayUnavailableException("Gateway 5xx")))
            .bodyToMono(Void.class)
            .timeout(Duration.ofSeconds(5))
            .retryWhen(Retry.backoff(2, Duration.ofMillis(200))
                            .filter(ex -> ex instanceof GatewayUnavailableException))
            .doOnSuccess(_ -> log.info("Payment charged orderId={}", orderId))
            .doOnError(PaymentDeclinedException.class,
                       ex -> log.warn("Payment declined orderId={}: {}", orderId, ex.getMessage()));
    }
}

// ─── Controller — annotation-driven reactive ────────────────────────────────

@RestController
@RequestMapping("/api/v1/orders")
@Validated
class OrderReactiveController {

    private final OrderService service;

    OrderReactiveController(OrderService service) { this.service = service; }

    @PostMapping
    @ResponseStatus(HttpStatus.CREATED)
    Mono<OrderResponse> create(@RequestBody @Valid Mono<CreateOrderRequest> req) {
        // Mono<CreateOrderRequest> — body not yet deserialized; flatMap continues the pipeline
        return req.flatMap(service::create);
    }

    @GetMapping("/{id}")
    Mono<OrderResponse> getById(@PathVariable UUID id) {
        return service.findById(id);   // NotFoundException bubbles to @RestControllerAdvice
    }

    @GetMapping
    Flux<OrderResponse> listByCustomer(@RequestParam @NotBlank String customerId) {
        return service.streamByCustomer(customerId);
    }

    // Server-Sent Events — real-time order stream; client receives updates as they happen
    @GetMapping(value = "/events", produces = MediaType.TEXT_EVENT_STREAM_VALUE)
    Flux<OrderCreatedEvent> streamEvents() {
        return service.orderEventStream()
            .doOnCancel(() -> {});  // client disconnect is handled automatically
    }
}

// ─── Handler + Router — functional endpoint alternative ─────────────────────

@Component
class OrderHandler {

    private final OrderService service;

    OrderHandler(OrderService service) { this.service = service; }

    Mono<ServerResponse> create(ServerRequest req) {
        return req.bodyToMono(CreateOrderRequest.class)
            .flatMap(service::create)
            .flatMap(order -> ServerResponse
                .created(URI.create("/api/v1/orders/" + order.id()))
                .bodyValue(order))
            .onErrorResume(NotFoundException.class,
                           ex -> ServerResponse.notFound().build());
    }

    Mono<ServerResponse> getById(ServerRequest req) {
        var id = UUID.fromString(req.pathVariable("id"));
        return service.findById(id)
            .flatMap(o -> ServerResponse.ok().bodyValue(o))
            .onErrorResume(NotFoundException.class,
                           ex -> ServerResponse.notFound().build());
    }

    Mono<ServerResponse> list(ServerRequest req) {
        var customerId = req.queryParam("customerId")
            .orElseThrow(() -> new IllegalArgumentException("customerId is required"));
        return ServerResponse.ok()
            .contentType(MediaType.APPLICATION_JSON)
            .body(service.streamByCustomer(customerId), OrderResponse.class);
    }

    Mono<ServerResponse> streamEvents(ServerRequest req) {
        return ServerResponse.ok()
            .contentType(MediaType.TEXT_EVENT_STREAM)
            .body(service.orderEventStream(), OrderCreatedEvent.class);
    }
}

@Configuration
class OrderRouter {

    @Bean
    RouterFunction<ServerResponse> orderRoutes(OrderHandler handler) {
        return RouterFunctions.route()
            .POST("/api/v2/orders",              handler::create)
            .GET("/api/v2/orders/{id}",           handler::getById)
            .GET("/api/v2/orders",                handler::list)
            .GET("/api/v2/orders/events",         handler::streamEvents)
            // Route-scoped filter — applies only to this route group
            .filter((req, next) -> {
                var start = System.nanoTime();
                return next.handle(req).doFinally(signal -> {
                    var ms = (System.nanoTime() - start) / 1_000_000;
                    // log.debug("Router {} {} → {} ms", req.method(), req.uri(), ms);
                });
            })
            .build();
    }
}

// ─── WebFilter — correlation ID propagated via Reactor Context ───────────────

@Component
@org.springframework.core.annotation.Order(-1)
class CorrelationIdWebFilter implements WebFilter {

    private static final String CORRELATION_KEY = "correlationId";

    @Override
    public Mono<Void> filter(ServerWebExchange exchange, WebFilterChain chain) {
        var id = Optional.ofNullable(
                exchange.getRequest().getHeaders().getFirst("X-Correlation-Id"))
            .orElseGet(() -> UUID.randomUUID().toString());

        exchange.getResponse().getHeaders().set("X-Correlation-Id", id);

        // contextWrite attaches the value to the Reactor Context for the entire pipeline
        return chain.filter(exchange)
            .contextWrite(ctx -> ctx.put(CORRELATION_KEY, id));
    }
}

// ─── Global Exception Handler ────────────────────────────────────────────────

@RestControllerAdvice
class GlobalExceptionHandler {

    @ExceptionHandler(NotFoundException.class)
    Mono<ResponseEntity<ProblemDetail>> handleNotFound(NotFoundException ex) {
        var pd = ProblemDetail.forStatusAndDetail(HttpStatus.NOT_FOUND, ex.getMessage());
        return Mono.just(ResponseEntity.status(HttpStatus.NOT_FOUND).body(pd));
    }

    @ExceptionHandler(PaymentDeclinedException.class)
    Mono<ResponseEntity<ProblemDetail>> handlePaymentDeclined(PaymentDeclinedException ex) {
        var pd = ProblemDetail.forStatusAndDetail(HttpStatus.PAYMENT_REQUIRED, ex.getMessage());
        pd.setTitle("Payment Declined");
        return Mono.just(ResponseEntity.status(HttpStatus.PAYMENT_REQUIRED).body(pd));
    }

    @ExceptionHandler(IllegalArgumentException.class)
    Mono<ResponseEntity<ProblemDetail>> handleBadRequest(IllegalArgumentException ex) {
        var pd = ProblemDetail.forStatusAndDetail(HttpStatus.BAD_REQUEST, ex.getMessage());
        return Mono.just(ResponseEntity.badRequest().body(pd));
    }
}

// ─── Security (WebFlux variant) ──────────────────────────────────────────────

@Configuration
@EnableWebFluxSecurity
@EnableReactiveMethodSecurity
class SecurityConfig {

    @Bean
    SecurityWebFilterChain securityFilterChain(ServerHttpSecurity http) {
        return http
            .csrf(ServerHttpSecurity.CsrfSpec::disable)   // stateless API — no CSRF
            .authorizeExchange(ex -> ex
                .pathMatchers("/actuator/health/**", "/actuator/info").permitAll()
                .pathMatchers(HttpMethod.POST, "/api/v1/orders").hasRole("USER")
                .pathMatchers("/api/v1/admin/**").hasRole("ADMIN")
                .anyExchange().authenticated()
            )
            .oauth2ResourceServer(o -> o.jwt(Customizer.withDefaults()))
            .build();
    }
}

// ─── Test examples (shown as inner classes for compactness) ──────────────────

// StepVerifier — unit test reactive pipeline without HTTP
class OrderServiceTest {

    // @ExtendWith(MockitoExtension.class)
    // @Mock OrderRepository repo;
    // @Mock PaymentGatewayClient paymentClient;
    // @InjectMocks OrderService service;

    void findById_notFound_emitsNotFoundException() {
        // when(repo.findById(any())).thenReturn(Mono.empty());
        // StepVerifier.create(service.findById(UUID.randomUUID()))
        //     .verifyError(NotFoundException.class);
    }

    void create_emitsResponse_andPublishesEvent() {
        // var order = new Order("cust-1", 5000L, "USD");
        // when(repo.save(any())).thenReturn(Mono.just(order));
        // when(paymentClient.charge(any(), anyLong())).thenReturn(Mono.empty());
        //
        // StepVerifier.create(service.create(new CreateOrderRequest("cust-1", 5000L, "USD")))
        //     .assertNext(res -> assertThat(res.status()).isEqualTo("PENDING"))
        //     .verifyComplete();
    }

    void stream_emitsAllOrders() {
        // var orders = Flux.just(new Order("cust-1", 1000L, "USD"), new Order("cust-1", 2000L, "USD"));
        // when(repo.findByCustomerId("cust-1")).thenReturn(orders);
        //
        // StepVerifier.create(service.streamByCustomer("cust-1"))
        //     .expectNextCount(2)
        //     .verifyComplete();
    }

    void create_timesOut_propagatesError() {
        // when(repo.save(any())).thenReturn(Mono.never());
        //
        // StepVerifier.withVirtualTime(
        //         () -> service.create(new CreateOrderRequest("cust-1", 1000L, "USD")))
        //     .thenAwait(Duration.ofSeconds(6))
        //     .verifyError(java.util.concurrent.TimeoutException.class);
    }
}

// WebTestClient — HTTP-level test
class OrderControllerTest {

    // @WebFluxTest(OrderReactiveController.class)
    // @Autowired WebTestClient client;
    // @MockBean OrderService service;

    void create_validRequest_returns201() {
        // when(service.create(any())).thenReturn(Mono.just(
        //     new OrderResponse(UUID.randomUUID(), "cust-1", "PENDING", 5000L, Instant.now())));
        //
        // client.post().uri("/api/v1/orders")
        //     .contentType(MediaType.APPLICATION_JSON)
        //     .bodyValue(new CreateOrderRequest("cust-1", 5000L, "USD"))
        //     .exchange()
        //     .expectStatus().isCreated()
        //     .expectBody(OrderResponse.class)
        //     .value(res -> assertThat(res.status()).isEqualTo("PENDING"));
    }
}

// ─── Domain exceptions ───────────────────────────────────────────────────────

class NotFoundException extends RuntimeException {
    NotFoundException(String message) { super(message); }
}

class PaymentDeclinedException extends RuntimeException {
    PaymentDeclinedException(String message) { super(message); }
}

class GatewayUnavailableException extends RuntimeException {
    GatewayUnavailableException(String message) { super(message); }
}
