# File Handling and I/O

## NIO.2 — always prefer over `java.io.File` (JDK 7)

`java.io.File` problems: no charset support, boolean return codes instead of exceptions,
no atomic operations, poor symlink handling, no `WatchService`.

```java
Path p = Path.of("dir", "sub", "file.txt")   // JDK 11; use Paths.get() on JDK 7-10
Path p = Paths.get("dir", "sub", "file.txt") // JDK 7+

Files.exists(p) / Files.notExists(p)
Files.isRegularFile(p) / Files.isDirectory(p)
Files.size(p)
Files.createDirectories(p)                   // mkdir -p; no error if exists
Files.copy(src, dst, StandardCopyOption.REPLACE_EXISTING)
Files.move(src, dst, StandardCopyOption.ATOMIC_MOVE)   // safe rename; all-or-nothing
Files.delete(p)          // throws if not found
Files.deleteIfExists(p)  // silent if not found
```

---

## Reading files

```java
// Small files — read entire content as String (JDK 11)
String content = Files.readString(path, StandardCharsets.UTF_8);

// Small files — read entire content as bytes (JDK 7)
byte[] bytes = Files.readAllBytes(path);

// Large files — stream lines lazily; MUST close
try (var lines = Files.lines(path, StandardCharsets.UTF_8)) {
    lines.filter(Predicate.not(String::isBlank))
         .map(String::strip)
         .forEach(this::process);
}

// Large files — buffered reader
try (var reader = Files.newBufferedReader(path, StandardCharsets.UTF_8)) {
    String line;
    while ((line = reader.readLine()) != null) { process(line); }
}
```

**Always specify charset explicitly** — never rely on `Charset.defaultCharset()` which depends on
the platform and JVM flags. Use `StandardCharsets.UTF_8`.

---

## Writing files

```java
// One-liner write (JDK 11)
Files.writeString(path, content, StandardCharsets.UTF_8,
    StandardOpenOption.CREATE, StandardOpenOption.TRUNCATE_EXISTING);

// Append
Files.writeString(path, line + "\n", StandardCharsets.UTF_8,
    StandardOpenOption.CREATE, StandardOpenOption.APPEND);

// Buffered writer for many lines
try (var writer = Files.newBufferedWriter(path, StandardCharsets.UTF_8)) {
    for (var line : lines) { writer.write(line); writer.newLine(); }
}
```

---

## Directory traversal — always close the stream

```java
// WRONG — Files.walk returns an AutoCloseable Stream; no try = file descriptor leak
Files.walk(dir).filter(Files::isRegularFile).forEach(this::process);  // ← leaks!

// CORRECT
try (var walk = Files.walk(dir)) {
    walk.filter(Files::isRegularFile)
        .filter(p -> p.toString().endsWith(".csv"))
        .forEach(this::process);
}

// Files.list — same leak risk; always try-with-resources
try (var entries = Files.list(dir)) {
    entries.filter(Files::isDirectory).forEach(this::scan);
}

// Files.mismatch — first differing byte position; -1 if identical (JDK 12)
long diffAt = Files.mismatch(fileA, fileB);
```

**Resource leak rule:** `Files.walk()`, `Files.lines()`, `Files.list()`, `Files.find()` all
return streams backed by OS file descriptors. Forgetting `try-with-resources` leaks descriptors
silently until `Too many open files` crash under load.

---

## InputStream additions (JDK 11)
```java
byte[] all   = in.readAllBytes();           // reads until EOF; auto-sizes; use for small payloads
byte[] chunk = in.readNBytes(1024);         // reads exactly N bytes or EOF
long   count = in.transferTo(outputStream); // copies all bytes; returns byte count

InputStream.nullInputStream()    // /dev/null equivalent source
OutputStream.nullOutputStream()  // /dev/null equivalent sink
```

---

## WatchService — filesystem events (JDK 7)
```java
try (var watcher = FileSystems.getDefault().newWatchService()) {
    dir.register(watcher,
        StandardWatchEventKinds.ENTRY_CREATE,
        StandardWatchEventKinds.ENTRY_MODIFY,
        StandardWatchEventKinds.ENTRY_DELETE);

    WatchKey key = watcher.take();   // blocks until event
    for (var event : key.pollEvents()) {
        var kind = event.kind();
        var changed = (Path) event.context();
        System.out.println(kind + ": " + changed);
    }
    key.reset();
}
```

---

## HTTP Client (JDK 11)

Use when: no Spring on classpath, writing library/tool, or calling external APIs from utility code.
Spring users: prefer `RestTemplate` (blocking MVC) or `WebClient` (reactive / non-blocking).

```java
// Client — reuse as static final or Spring bean; thread-safe
static final HttpClient CLIENT = HttpClient.newBuilder()
    .connectTimeout(Duration.ofSeconds(5))
    .followRedirects(HttpClient.Redirect.NORMAL)
    .version(HttpClient.Version.HTTP_2)
    .build();

// Sync request
HttpRequest req = HttpRequest.newBuilder(URI.create(url))
    .header("Accept", "application/json")
    .header("Authorization", "Bearer " + token)
    .timeout(Duration.ofSeconds(10))
    .GET().build();

HttpResponse<String> res = CLIENT.send(req, HttpResponse.BodyHandlers.ofString());
int status = res.statusCode();
String body = res.body();

// POST with JSON body
HttpRequest post = HttpRequest.newBuilder(URI.create(url))
    .header("Content-Type", "application/json")
    .POST(HttpRequest.BodyPublishers.ofString(json))
    .build();

// Async
CLIENT.sendAsync(req, HttpResponse.BodyHandlers.ofString())
    .thenApply(HttpResponse::body)
    .thenAccept(this::process)
    .exceptionally(ex -> { log.error("Request failed", ex); return null; });
```

---

See also: `examples/jdk7/Jdk7Features.java`, `examples/jdk10_11/Jdk10And11Features.java`
