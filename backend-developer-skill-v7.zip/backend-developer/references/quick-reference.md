# Quick Reference — Sonar Rules and Decision Lookup

This file contains two always-available lookups pulled out of SKILL.md to keep it lean.
Read this file whenever you need to verify a Sonar rule or quickly confirm the right API/pattern choice.
For full scenario reasoning behind each decision, read `references/decision-guide.md`.

---

## Sonar Rules — Enforce on Every Generated File

```
S1481  Remove unused local variables
S1854  Remove useless variable assignments
S2095  Close resources in try-with-resources
S2789  Don't check Optional for null (always non-null)
S3776  Cognitive complexity > 15 → refactor into smaller methods
S4973  Compare Strings with equals(), not ==
S6201  Use pattern matching instanceof — not manual cast after type check
S6204  Use Stream.toList() — not collect(toUnmodifiableList())
S6206  Use record for pure data classes — not class with only fields + constructor
S1905  Remove redundant casts
S4266  Use isEmpty() — not size() == 0
S1192  Extract duplicate string literals to constants
S2153  No boxing immediately followed by unboxing
S3518  Divisor must not be zero — validate before divide
S1135  No committed TODO/FIXME — use issue tracker
S2055  Write-only fields should be removed
S3016  Avoid field injection — never @Autowired on field
```

---

## Quick Decision Table

When you know what you need but want to confirm the right choice fast.
For the full "when" reasoning: read `references/decision-guide.md`.
For full API: read the concept reference file listed in the routing table in SKILL.md.

| Need | Correct choice |
|---|---|
| Immutable data object / DTO / event / value | `record` |
| Closed type hierarchy, variants carry different data | `sealed interface` + `record` subtypes |
| Stateless labels, DB column, EnumMap key | `enum` |
| Absent return (expected, normal outcome) | `Optional<T>` return type |
| Absent = contract violation / must exist | throw `NotFoundException` with context |
| Multiline string — SQL, JSON, HTML, email | Text block `"""..."""` |
| Conditional value on single variable | Switch expression `->` |
| Null-safe navigation chain | `Optional.ofNullable().map().flatMap().orElse()` |
| High-write-contention counter | `LongAdder` — not `AtomicLong` |
| Async fan-out, all results needed, cancel on failure | `StructuredTaskScope.ShutdownOnFailure` |
| Async fan-out, first result wins | `StructuredTaskScope.ShutdownOnSuccess` |
| Sequential async pipeline | `CompletableFuture` chain |
| I/O-bound parallelism | Virtual thread per-task executor |
| CPU-bound parallelism | `ForkJoinPool` / `RecursiveTask` |
| Cross-cutting request context (traceId, user, tenant) | `ScopedValue` — not `ThreadLocal` |
| Mutual exclusion with virtual threads | `ReentrantLock` — never `synchronized` |
| Read-heavy shared mutable state | `StampedLock` optimistic read |
| Lock-free field CAS | `VarHandle` |
| Immutable literal collection (code constant) | `List.of` / `Set.of` / `Map.of` |
| Immutable defensive copy (from mutable input) | `List.copyOf` / `Map.copyOf` |
| Sliding window over stream elements | `Gatherers.windowSliding(n)` |
| Running accumulation keeping intermediates | `Gatherers.scan(identity, fn)` |
| Bounded parallel map preserving order | `Gatherers.mapConcurrent(n, fn)` |
| File read — small, fits in memory | `Files.readString(path, UTF_8)` |
| File read — large, line-by-line | `try (var s = Files.lines(path, UTF_8)) { ... }` |
| Directory traversal | `try (var s = Files.walk(dir)) { ... }` — MUST close |
| HTTP call without Spring | `static final HttpClient` — JDK 11 |
| Enum-keyed map | `EnumMap` — never `HashMap<MyEnum, ...>` |
| Enum value set | `EnumSet` — never `HashSet<MyEnum>` |
| Spring config group | `@ConfigurationProperties` + `record` — not `@Value` |
| Spring DTO | `record` + `static from(Entity e)` factory |
| Spring write transaction | `@Transactional` on method, `readOnly=false` |
| Spring read transaction | `@Transactional(readOnly=true)` on class default |
| Regex reused across calls | `private static final Pattern` — never inline `.matches()` |
| Date/time formatter | `private static final DateTimeFormatter` — thread-safe, expensive to build |
| Jackson ObjectMapper | Singleton Spring bean or `static final` — never `new` per request |
| Logger | `private static final Logger log = LoggerFactory.getLogger(MyClass.class)` |
| Default ordered list | `ArrayList` |
| Frequent head/tail insert+remove | `ArrayDeque` — not `LinkedList` |
| Thread-safe read-heavy list | `CopyOnWriteArrayList` |
| Thread-safe map | `ConcurrentHashMap` |
| Insertion-order map | `LinkedHashMap` |
| Sorted map | `TreeMap` |
| String concat in loop | `StringBuilder` with capacity hint — never `+=` |
| Multi-line template with params | `"""...""".formatted(args)` |
| Two aggregations in one stream pass | `Collectors.teeing(c1, c2, merger)` |
| Variable-count output per stream element | `Stream.mapMulti(biConsumer)` — not `flatMap` |
| Pattern matching type check | `instanceof MyType t` — not cast after check |
| Ignore unused record component in pattern | `case Foo(int x, _)` — unnamed `_` |
| Ignore unused exception variable | `catch (Exception _)` — unnamed `_` |
| Overflow-safe arithmetic | `Math.addExact` / `Math.multiplyExact` — throws on overflow |
| Optional.get() — never | Use `orElseThrow()` always |
| Date/time API — never | `java.util.Date` / `Calendar` / `SimpleDateFormat` — use `java.time` |
| Synchronisation with virtual threads — never | `synchronized` — use `ReentrantLock` |
| String trim — prefer | `strip()` over `trim()` — Unicode-aware |
| String blank check — prefer | `isBlank()` over `isEmpty()` — catches whitespace-only |
