# Spring Boot Patterns

## Injection — always constructor injection (Sonar: field injection = S3016)
```java
@Service
@RequiredArgsConstructor                 // Lombok generates constructor
public class OrderService {
    private final OrderRepository repo;
    private final PaymentGateway gateway;
    private final ApplicationEventPublisher events;
}
```

## Configuration — `@ConfigurationProperties` + record
```java
// Prefer @ConfigurationProperties over @Value for related groups
@ConfigurationProperties(prefix = "app.payment")
record PaymentConfig(
    @NotBlank String apiKey,
    @NotNull URI endpoint,
    @DurationUnit(ChronoUnit.SECONDS) Duration timeout
) {}

// Register
@EnableConfigurationProperties(PaymentConfig.class)
```

## DTOs — use records
```java
record UserDto(UUID id, String name, String email) {
    static UserDto from(User u) {
        return new UserDto(u.getId(), u.getName(), u.getEmail());
    }
}

// Spring Data projection (avoids loading full entity)
interface UserSummary { UUID getId(); String getName(); }
List<UserSummary> findAllProjectedBy();
```

## Repositories
```java
// Derived for simple queries
Optional<User> findByEmailIgnoreCase(String email);
boolean existsByEmail(String email);
List<User> findByActiveTrueOrderByCreatedAtDesc();

// Text block JPQL for complex queries
@Query(value = """
        SELECT u FROM User u
        JOIN FETCH u.roles r
        WHERE u.active = true
          AND r.name = :role
        """)
List<User> findActiveByRole(@Param("role") String role);

// Avoid N+1 — use JOIN FETCH or @EntityGraph
@EntityGraph(attributePaths = {"roles", "address"})
Optional<User> findWithDetailsById(UUID id);
```

## Exception Handling — ProblemDetail (RFC 7807, Spring 6+)
```java
@RestControllerAdvice
public class GlobalExceptionHandler extends ResponseEntityExceptionHandler {
    @ExceptionHandler(EntityNotFoundException.class)
    ProblemDetail handleNotFound(EntityNotFoundException ex, HttpServletRequest req) {
        var pd = ProblemDetail.forStatusAndDetail(NOT_FOUND, ex.getMessage());
        pd.setInstance(URI.create(req.getRequestURI()));
        return pd;
    }
}
```

## Virtual Threads + Spring Boot 3.2+
```java
// application.properties
spring.threads.virtual.enabled=true
// Automatically configures: Tomcat executor, @Async, @Scheduled, task executors
```

---
See also: `examples/springboot/OrderServiceStack.java`
