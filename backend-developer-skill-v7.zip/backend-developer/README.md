# backend-developer skill

Expert Java + Spring Boot backend code generation skill for Claude.

## Structure

```
backend-developer/
├── SKILL.md                          ← Install this skill in Claude
└── examples/
    ├── jdk7/
    │   └── Jdk7Features.java         ← Diamond, try-with-resources, multi-catch,
    │                                    NIO.2, Fork/Join, ThreadLocalRandom
    ├── jdk8/
    │   └── Jdk8Features.java         ← Lambdas, Streams, Collectors, Optional,
    │                                    java.time, CompletableFuture, LongAdder,
    │                                    StampedLock, Map methods, Comparator
    ├── jdk9/
    │   └── Jdk9Features.java         ← List.of/Set.of/Map.of, Stream.ofNullable,
    │                                    takeWhile/dropWhile, Optional.or/stream,
    │                                    private interface methods, VarHandle,
    │                                    StackWalker, HTTP Client incubator
    ├── jdk10_11/
    │   └── Jdk10And11Features.java   ← var, copyOf, readString/writeString,
    │                                    String.isBlank/strip/lines/repeat,
    │                                    Predicate.not, HTTP Client final,
    │                                    InputStream.readAllBytes/transferTo
    ├── jdk12_17/
    │   └── Jdk12To17Features.java    ← Switch expressions, text blocks (\ \s),
    │                                    records (compact constructor, generics),
    │                                    sealed classes, pattern instanceof,
    │                                    Stream.toList, mapMulti, teeing,
    │                                    String.indent/transform
    ├── jdk21/
    │   └── Jdk21Features.java        ← Virtual threads + ReentrantLock rule,
    │                                    Sequenced Collections, pattern switch
    │                                    with guards, record patterns (nested),
    │                                    unnamed variables _, ScopedValue,
    │                                    StructuredTaskScope (both strategies)
    ├── jdk22_25/
    │   └── Jdk22To25Features.java    ← Stream Gatherers (all built-ins + custom),
    │                                    unnamed variables (final), flexible
    │                                    constructors, primitive patterns
    └── springboot/
        └── OrderServiceStack.java    ← Full stack: Entity, Repository (projections,
                                         text block queries, EntityGraph),
                                         Service (constructor injection, events,
                                         virtual thread fan-out), Controller,
                                         @ConfigurationProperties + record,
                                         ProblemDetail exception handler
```

## Coverage by JDK version

| Version | Key additions |
|---------|---------------|
| JDK 7   | Diamond `<>`, try-with-resources, multi-catch, NIO.2, Fork/Join |
| JDK 8   | Lambdas, Streams, Optional, java.time, CompletableFuture |
| JDK 9   | `List.of`, `takeWhile`/`dropWhile`, `Stream.ofNullable`, private interface methods, VarHandle |
| JDK 10  | `var`, `List.copyOf` |
| JDK 11  | `isBlank`/`strip`/`lines`/`repeat`, `Files.readString`, `Predicate.not`, HTTP Client |
| JDK 12  | `String.indent`, `String.transform`, `Collectors.teeing` |
| JDK 14  | Switch expressions (final) |
| JDK 15  | Text blocks (final) with `\` and `\s` escapes |
| JDK 16  | Records (final), `Stream.toList()`, `mapMulti`, pattern `instanceof` |
| JDK 17  | Sealed classes, enhanced pseudo-random |
| JDK 21  | Virtual threads, Sequenced Collections, pattern switch, record patterns, `_`, ScopedValue, StructuredTaskScope |
| JDK 22+ | Unnamed variables (final), Stream Gatherers, flexible constructors, primitive patterns |

## Install

Upload `backend-developer.skill` to Claude via Settings → Skills.
