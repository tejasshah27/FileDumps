# Strings and Formatting

## String building — choose by context

| Context | Use | Why |
|---|---|---|
| Multi-line literal | Text block `"""` | No escaping, baseline indent, readable |
| Single-line concat | `+` operator | JIT optimises via `invokedynamic` since JDK 9 |
| Concat in loop | `StringBuilder` | `+=` in loop = new `String` per iteration → O(n²) heap |
| Stream elements | `Collectors.joining(", ", "[", "]")` | Most concise |
| Parameterised template | `.formatted()` or `String.format()` | Cold path only; format parsing is slow |

**NEVER** `+=` in a loop. JIT does NOT optimise `+=` inside loops.
**NEVER** `String.format()` / `.formatted()` on a hot path — format string is parsed on every call.
`StringBuilder` in loops: hint capacity to avoid internal array resizing:
```java
var sb = new StringBuilder(items.size() * 20);
for (var item : items) sb.append(item).append(',');
sb.deleteCharAt(sb.length() - 1);
```

---

## String methods (JDK 11)
```java
"  hi  ".isBlank()          // true if empty OR Unicode whitespace — use for input validation
"  hi  ".isEmpty()          // true only if length == 0 — "   " is NOT empty
"  hi  ".strip()            // Unicode-aware trim — always prefer over trim()
"  hi  ".stripLeading()     // leading only
"  hi  ".stripTrailing()    // trailing only
"ha".repeat(3)              // "hahaha"
"a\nb\nc".lines()           // Stream<String>; lazy; handles \n, \r\n, \r — no regex overhead
```

`strip()` vs `trim()` — `trim()` removes only chars ≤ ASCII 0x20; misses Unicode whitespace
like `\u2000` (non-breaking space). Always use `strip()` in new code.

`isBlank()` vs `isEmpty()`:
```java
// WRONG — won't catch "   " (whitespace-only input)
if (name == null || name.isEmpty()) throw new IllegalArgumentException();

// CORRECT
if (name == null || name.isBlank()) throw new IllegalArgumentException();
```

---

## String utilities (JDK 12+)
```java
" hello ".transform(String::strip).transform(String::toUpperCase)  // fluent pipe
block.indent(4)      // add 4 spaces per line; n<0 removes; always ensures trailing newline
```

---

## Text blocks (JDK 15)
Multi-line strings: SQL, JSON, XML, HTML, email bodies. No concatenation. No escaping.
```java
// Indentation baseline = closing """
String sql = """
        SELECT u.id, u.email
        FROM   users u
        WHERE  u.active = true
          AND  u.created_at > :since
        ORDER  BY u.created_at DESC
        """;

// .formatted() for runtime values
String body = """
        Dear %s,
        Order #%d is confirmed.
        """.formatted(name, orderId);

// \  = suppress newline (two lines become one)
String oneLine = """
        Hello \
        World""";    // → "Hello World"

// \s = preserve trailing whitespace (otherwise stripped by compiler)
String padded = """
        Alice  \s
        Bob    \s
        """;
```

---

## Regex — always static final Pattern
```java
// BAD — recompiles NFA/DFA automaton on EVERY call; constant allocation on hot path
boolean valid = value.matches("[a-z]+");
String[] parts = line.split("\\.");

// GOOD — compile once, reuse; thread-safe
private static final Pattern ALPHA  = Pattern.compile("[a-z]+");
private static final Pattern DOT    = Pattern.compile("\\.");

boolean valid = ALPHA.asMatchPredicate().test(value);   // full match
boolean found = ALPHA.asPredicate().test(value);        // partial match (find)
String[] parts = DOT.split(line);
```

`asMatchPredicate()` → full string must match (like `String.matches()`).
`asPredicate()` → any substring matches (like `Matcher.find()`).

---

## java.time — ban Date, Calendar, SimpleDateFormat entirely

```java
LocalDate.now() / .of(2024, 1, 15) / .parse("2024-01-15")
LocalTime.now() / .of(14, 30, 0)
LocalDateTime.now(ZoneId.of("UTC"))
ZonedDateTime.now(ZoneId.of("America/New_York"))
OffsetDateTime.now(ZoneOffset.UTC)
Instant.now()                                  // machine timestamp — use for DB cols, logs, events
Duration.ofSeconds(30) / Duration.between(t1, t2)
Period.ofDays(7)   / Period.between(d1, d2)
date.plus(1, ChronoUnit.MONTHS)
ChronoUnit.DAYS.between(start, end)

// Formatter is thread-safe — always static final, never new per call
private static final DateTimeFormatter ISO  = DateTimeFormatter.ISO_OFFSET_DATE_TIME;
private static final DateTimeFormatter DISP = DateTimeFormatter.ofPattern("dd MMM yyyy HH:mm");

TemporalAdjusters.firstDayOfMonth()
TemporalAdjusters.next(DayOfWeek.MONDAY)
```

**Use** `Instant` for: timestamps stored in DB, log timestamps, event times, duration measurement.
**Use** `ZonedDateTime` for: user-facing display, scheduling, calendar operations.
**Use** `LocalDate` for: date-only concepts (birthday, deadline) where timezone is irrelevant.
**Never** `new Date()`, `Calendar.getInstance()`, `SimpleDateFormat` in new code.

---

## Numeric literals (JDK 7)
```java
int mask   = 0b1111_0000;    // binary literal — intent clear
long limit = 1_000_000_000L; // underscore separator — prevents off-by-one-zero errors
```
Use underscores in any numeric literal ≥ 5 digits.

---

## Compact number format (JDK 12)
```java
NumberFormat.getCompactNumberInstance(Locale.US, Style.SHORT).format(1_500_000); // "1.5M"
```

---

## Base64 (JDK 8)
```java
Base64.getEncoder().encodeToString(bytes);
Base64.getDecoder().decode(encoded);
Base64.getUrlEncoder().withoutPadding();    // URL-safe, no padding
Base64.getMimeEncoder(76, CRLF);            // MIME line-wrapping
```

---

## Math overflow-checked — use in financial / safety-critical arithmetic
```java
Math.addExact(a, b); Math.subtractExact(a, b);
Math.multiplyExact(a, b); Math.toIntExact(longVal);
// All throw ArithmeticException on overflow instead of silently wrapping
```

---

## Logging strings — parameterised always
```java
// BAD — string built even when DEBUG disabled; wasteful allocation
log.debug("Processing order: " + order.getId() + " for user: " + user.getName());

// GOOD — string built only if level enabled; no allocation otherwise
log.debug("Processing order: {} for user: {}", order.getId(), user.getName());

// For expensive toString() on hot path, guard explicitly
if (log.isDebugEnabled()) {
    log.debug("Full state: {}", expensiveObject.toDetailedString());
}
```

---

## `String.intern()` — use sparingly
Only intern a controlled, finite, compile-time-known set of strings (e.g. enum-like codes).
Never intern DB values, user input, or network data — unbounded unique strings fill the pool → OOM.

---

See also: `examples/jdk7/Jdk7Features.java`, `examples/jdk10_11/Jdk10And11Features.java`, `examples/jdk12_17/Jdk12To17Features.java`
