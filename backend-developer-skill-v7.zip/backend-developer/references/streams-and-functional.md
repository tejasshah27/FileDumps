# Streams and Functional Programming

## Lambdas and method references

Four forms of method reference — prefer over verbose lambda when it reads naturally:
```java
list.forEach(System.out::println);          // 1. instance method on arbitrary object
list.stream().map(String::toUpperCase);     // 2. instance method on stream element
list.stream().filter(Objects::nonNull);     // 3. static method
list.stream().map(User::new);              // 4. constructor ref
```

Lambdas vs anonymous classes:
- Lambda: any `@FunctionalInterface` (single abstract method)
- Anonymous class: non-functional interface, or lambda needs `this`, or needs to maintain state
- Effectively final: captured locals don't need `final` keyword but must not be reassigned

`@FunctionalInterface` — annotate custom functional interfaces; compiler enforces single abstract method.

---

## Functional interface family (`java.util.function`)
```
Function<T,R>       BiFunction<T,U,R>    UnaryOperator<T>    BinaryOperator<T>
Consumer<T>         BiConsumer<T,U>
Supplier<T>
Predicate<T>        BiPredicate<T,U>

// Primitive specialisations — avoids boxing/unboxing in hot paths
IntFunction<R>      ToIntFunction<T>     IntUnaryOperator    IntBinaryOperator
IntConsumer         IntSupplier          IntPredicate
// same pattern for Long, Double
```

Compose predicates and functions:
```java
Predicate<String> notBlankAndShort =
    Predicate.not(String::isBlank).and(s -> s.length() < 50);

Function<String, String> pipeline =
    ((Function<String,String>) String::strip).andThen(String::toLowerCase);
```

`Predicate.not()` (JDK 11) — negate method references cleanly:
```java
stream.filter(Predicate.not(String::isBlank))      // vs: filter(s -> !s.isBlank())
stream.filter(Predicate.not(blocklist::contains))
```

---

## Stream — complete factory reference
```java
Stream.of(a, b, c)
Stream.empty()
Stream.generate(UUID::randomUUID).limit(10)           // infinite; always limit
Stream.iterate(0, n -> n + 2).limit(5)                // infinite; JDK 9: 3-arg with predicate
Stream.iterate(0, n -> n < 100, n -> n + 2)           // JDK 9 — bounded, like for-loop
Stream.ofNullable(maybeNull)                           // JDK 9 — 0 or 1 element
Stream.concat(s1, s2)
IntStream.range(0, 10)         // [0,10)
IntStream.rangeClosed(1, 10)   // [1,10]
Arrays.stream(arr)
collection.stream() / .parallelStream()
```

---

## Stream — intermediate operations (lazy)
```java
.filter(pred)       .map(fn)           .flatMap(fn)
.mapToInt(fn)       .mapToLong(fn)     .mapToDouble(fn)
.distinct()         .sorted()          .sorted(comparator)
.peek(consumer)     .limit(n)          .skip(n)
.takeWhile(pred)    .dropWhile(pred)   // JDK 9 — ordered; stop/skip at predicate boundary
.mapMulti(biConsumer)                  // JDK 16 — push-based flatMap; no Stream alloc per element
```

`takeWhile` vs `filter`:
- `filter` — scans ALL elements; order irrelevant
- `takeWhile` — stops at FIRST failure; use on sorted/ordered data (events before date, log header)
- `dropWhile` — skips prefix while predicate holds; use for ordered header lines

`mapMulti` vs `flatMap`:
- `flatMap` — allocates a `Stream` per element
- `mapMulti` — push model; caller controls how many outputs per input; faster for sparse expansion

---

## Stream — terminal operations
```java
.collect(collector)     .toList()               // toList() = JDK 16 unmodifiable, null-hostile
.forEach(consumer)      .forEachOrdered(consumer)
.reduce(identity, fn)   .reduce(fn)             // Optional result
.count()
.min(comparator)        .max(comparator)        // Optional<T>
.sum() / .average() / .summaryStatistics()      // IntStream / LongStream / DoubleStream
.anyMatch(pred)         .allMatch(pred)         .noneMatch(pred)
.findFirst()            .findAny()              // Optional<T>
.toArray()              .toArray(T[]::new)
```

`toList()` vs `collect(toList())` vs `collect(toUnmodifiableList())`:
- `toList()` (JDK 16) — unmodifiable, null-hostile; prefer in all new code
- `collect(toList())` — mutable `ArrayList`; use only when post-collection mutation needed
- `collect(toUnmodifiableList())` — JDK 10; allows nulls during collection

---

## Collectors — complete reference
```java
Collectors.toList()                              // mutable
Collectors.toUnmodifiableList()                  // JDK 10 immutable
Collectors.toMap(keyFn, valFn)
Collectors.toMap(keyFn, valFn, mergeOnDuplicate) // merge fn for duplicate keys
Collectors.toUnmodifiableMap(keyFn, valFn)
Collectors.groupingBy(classifier)               // Map<K, List<V>>
Collectors.groupingBy(classifier, downstream)   // downstream: counting(), summing(), toSet()...
Collectors.partitioningBy(pred)                 // Map<Boolean, List<V>>
Collectors.partitioningBy(pred, downstream)
Collectors.counting()
Collectors.summingInt(fn) / summingLong / summingDouble
Collectors.averagingInt(fn)
Collectors.joining(delimiter, prefix, suffix)
Collectors.mapping(fn, downstream)
Collectors.flatMapping(fn, downstream)          // JDK 9 — flatMap inside groupingBy
Collectors.filtering(pred, downstream)          // JDK 9 — filter inside groupingBy downstream
Collectors.collectingAndThen(downstream, finisher)
Collectors.teeing(c1, c2, merger)               // JDK 12 — two collectors in one pass
Collectors.summarizingInt(fn)                   // IntSummaryStatistics
Collectors.toCollection(ArrayList::new)
```

`teeing` — use when you need TWO different aggregations of the same data in one pass:
```java
var stats = stream.collect(Collectors.teeing(
    Collectors.summingLong(Order::amount),
    Collectors.counting(),
    (sum, count) -> new Summary(sum, count)));
```

---

## Stream Gatherers — custom intermediate ops (JDK 24)
Gatherers are to intermediate ops what Collectors are to terminal ops.
Collectors = terminal; Gatherers = intermediate (produces another Stream).

```java
// Built-in Gatherers
stream.gather(Gatherers.windowFixed(3))       // non-overlapping batches: [0,1,2], [3,4,5]...
stream.gather(Gatherers.windowSliding(3))     // overlapping windows:     [0,1,2], [1,2,3]...
stream.gather(Gatherers.scan(identity, fn))   // running accumulation — keeps ALL intermediates
stream.gather(Gatherers.fold(identity, fn))   // like reduce but as gatherer (single result)
stream.gather(Gatherers.mapConcurrent(4, fn)) // parallel map, bounded concurrency, preserves order
```

When Gatherers beat pre-JDK24 patterns:

| Operation | Before Gatherers | After |
|---|---|---|
| Sliding window | External `ArrayDeque` + loop hack | `windowSliding(n)` |
| Batch/chunk | `AtomicInteger` + `groupingBy` trick | `windowFixed(n)` |
| Running sum / cumulative | `int[] acc = {0}` array trick | `scan(() -> 0, Integer::sum)` |
| Bounded parallel map | Manual `CompletableFuture` list + order tracking | `mapConcurrent(n, fn)` |

Custom Gatherer:
```java
static <T> Gatherer<T, Set<T>, T> deduplicate() {
    return Gatherer.ofSequential(
        HashSet::new,
        (seen, element, downstream) -> {
            if (seen.add(element)) downstream.push(element);
            return true;   // true = continue, false = short-circuit
        }
    );
}
stream.gather(deduplicate()).toList();
```

---

## Stream vs for-loop — choose deliberately

**Use Stream when:**
- Transform / filter / aggregate / collect pipeline — declarative intent is clear
- Grouping, partitioning, joining — Collectors do it in one pass
- Parallelism desired (but see `parallelStream` warning below)

**Use for-loop when:**
- Checked exceptions must propagate from the body
- Multiple mutable variables updated per iteration
- Early exit depends on accumulated state
- Tight primitive loop where boxing would hurt — use `IntStream` instead
- Collection is small (< ~10 elements) — Stream infra overhead exceeds iteration cost

**`parallelStream()` — use rarely:**
- Uses `ForkJoinPool.commonPool()` shared across the entire JVM
- Blocking I/O inside parallel stream starves all other pool users
- Only beneficial for CPU-bound operations on large datasets (> ~10,000 elements)
- For I/O-bound parallelism: use virtual threads instead

---

## Primitive streams — avoid autoboxing on hot paths
```java
// AVOID: Integer stream auto-boxes each element
List<Integer> salaries = employees.stream().map(Employee::salary).toList();

// PREFER: no boxing
IntSummaryStatistics stats = employees.stream()
    .mapToInt(Employee::salary)
    .summaryStatistics();

int total = IntStream.rangeClosed(1, 100).sum();
```

---

See also: `examples/jdk8/Jdk8Features.java`, `examples/jdk9/Jdk9Features.java`, `examples/jdk12_17/Jdk12To17Features.java`, `examples/jdk22_25/Jdk22To25Features.java`
