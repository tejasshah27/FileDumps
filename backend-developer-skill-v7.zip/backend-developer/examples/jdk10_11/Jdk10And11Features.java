package examples.jdk10_11;

import java.io.*;
import java.net.URI;
import java.net.http.*;
import java.nio.charset.StandardCharsets;
import java.nio.file.*;
import java.time.Duration;
import java.util.*;
import java.util.function.Predicate;
import java.util.regex.Pattern;
import java.util.stream.Stream;

/**
 * JDK 10 — var (local type inference)
 * JDK 11 — String methods, Files one-liners, HTTP Client, Predicate.not, InputStream additions
 *
 * SCENARIO GUIDE — when to use each pattern:
 *
 * var — local type inference
 *   USE WHEN: the type is obvious from the RHS (constructor call, factory method, cast).
 *   USE WHEN: the generic type is long and repetitive (Map<String, List<OrderItem>> etc).
 *   DO NOT use WHEN: type is not obvious from RHS: var x = getValue(); — reader can't tell.
 *   DO NOT use WHEN: primitive literals: var flag = true; — boolean is short enough.
 *   DO NOT use for: fields, method params, return types — only local variables.
 *   var in for-each is idiomatic and always fine.
 *
 * isBlank() vs isEmpty()
 *   isEmpty() — length == 0 only. "   " (spaces) is NOT empty.
 *   isBlank() — empty OR only Unicode whitespace. "   " IS blank.
 *   USE isBlank() for input validation — trims intent. USE isEmpty() only if you
 *   specifically want to allow whitespace-only strings.
 *
 * strip() vs trim()
 *   trim() — removes only chars ≤ ASCII 0x20. Misses Unicode whitespace like \u2000.
 *   strip() — Unicode-aware. ALWAYS prefer strip()/stripLeading()/stripTrailing()
 *   over trim() in new code.
 *
 * lines() vs split("\\n") vs split("\\R")
 *   split("\\n")  — regex, allocates array, doesn't handle \r\n or \r.
 *   split("\\R")  — handles all line endings but still allocates full array eagerly.
 *   lines()       — Stream<String>, lazy, handles all line endings, no regex overhead.
 *   USE lines() WHEN: processing text line-by-line in a stream pipeline.
 *
 * repeat(n)
 *   USE WHEN: building padding, separators, indentation. Avoid manual StringBuilder loop.
 *
 * Files.readString / writeString vs BufferedReader/Writer
 *   BufferedReader — needed for large files (line-by-line streaming).
 *   Files.readString — one-liner for small-to-medium files that fit in memory.
 *   USE Files.readString WHEN: config files, templates, test fixtures — anything that
 *   fits comfortably in a String.
 *   ALWAYS pass explicit charset (UTF_8) — never rely on platform default.
 *
 * Predicate.not() vs lambda negation
 *   BEFORE: .filter(s -> !s.isBlank())  — lambda required, can't negate method ref directly.
 *   AFTER:  .filter(Predicate.not(String::isBlank))  — method ref preserved.
 *   USE Predicate.not() WHEN: negating a method reference in a stream filter.
 *   Also works for set membership: Predicate.not(blocklist::contains).
 *
 * HTTP Client vs RestTemplate vs WebClient
 *   RestTemplate  — Spring blocking HTTP; still fine in Spring MVC / non-reactive code.
 *   WebClient     — Spring reactive HTTP; use in WebFlux or when reactive pipeline needed.
 *   HttpClient    — JDK built-in; use when: no Spring on classpath, writing library/tool,
 *                   or want zero-dependency HTTP. Supports HTTP/2 and async natively.
 *   USE JDK HttpClient WHEN: utility code, CLI tools, tests, or microservice that calls
 *   external APIs without Spring dependency.
 *
 * InputStream.readAllBytes() vs read() loop
 *   read() loop — required for streaming; avoids loading full content into memory.
 *   readAllBytes() — loads full content; only use for small resources (< few MB).
 *   USE readAllBytes() WHEN: test data loading, config bytes, known-small payloads.
 *   USE transferTo() WHEN: piping one stream to another without buffering in memory.
 *
 * Pattern.asMatchPredicate() vs asPredicate()
 *   asPredicate()      — uses Matcher.find() — partial match; any substring matches.
 *   asMatchPredicate() — uses Matcher.matches() — full string must match pattern.
 *   USE asMatchPredicate() WHEN: validating format (UUID, email, phone) — you want
 *   the whole string to conform, not just contain a substring.
 */
public class Jdk10And11Features {

    // ═══════════════════════════════════════════════════════════════════════
    // JDK 10 — var
    // ═══════════════════════════════════════════════════════════════════════

    // ── var: use when RHS makes type obvious ─────────────────────────────────
    void varGoodUses() {
        var names    = new ArrayList<String>();               // obvious: ArrayList<String>
        var map      = new HashMap<String, List<Integer>>();  // avoids repeating generics
        var entries  = map.entrySet();                        // Set<Map.Entry<String,List<Integer>>>
        var iterator = entries.iterator();                    // Iterator<...>

        // var in for-each — idiomatic
        for (var entry : map.entrySet()) {
            System.out.println(entry.getKey() + " -> " + entry.getValue());
        }

        // var with complex generics: saves repetition without losing type info
        var stats = new TreeMap<String, Map<String, Long>>();

        // Effectively captures type from factory
        var ids = List.of("a", "b", "c");   // var = List<String>
    }

    // ── var: DON'T use when type is ambiguous ─────────────────────────────────
    void varBadUses() {
        // BAD — reader cannot tell type
        // var result = process();          ← what does process() return?
        // var flag   = check();            ← boolean? int? object?

        // PREFER explicit type when var obscures intent:
        boolean isValid = validate("input");   // intent clear
        int count       = getCount();          // primitive, short, clear

        // var IS OK here (type obvious from literal / constructor):
        var timeout = Duration.ofSeconds(30);  // var = Duration
        var sb      = new StringBuilder(256);  // var = StringBuilder
    }

    boolean validate(String s) { return !s.isBlank(); }
    int getCount() { return 0; }

    // ── JDK 10: defensive copy ────────────────────────────────────────────────
    record UserGroup(List<String> members) {
        UserGroup(List<String> members) {
            // copyOf = unmodifiable snapshot; throws NullPointerException if any element null
            this.members = List.copyOf(members);
        }
    }

    // ═══════════════════════════════════════════════════════════════════════
    // JDK 11 — String methods
    // ═══════════════════════════════════════════════════════════════════════

    // ── isBlank() — Unicode-aware (not just ASCII 0x20) ──────────────────────
    // BEFORE: s == null || s.trim().isEmpty()
    // AFTER:
    boolean hasContent(String s) {
        return s != null && !s.isBlank();
    }

    // ── strip() — Unicode whitespace (e.g. \u2000 stripped; trim() leaves it) ─
    String normalize(String input) {
        return input.strip();           // Unicode-aware; prefer over trim()
    }

    // ── lines() — Stream<String> without split overhead ──────────────────────
    // BEFORE: Arrays.stream(text.split("\\R"))  — regex, allocates array
    // AFTER:
    List<String> nonBlankLines(String text) {
        return text.lines()
            .filter(Predicate.not(String::isBlank))
            .map(String::strip)
            .toList();
    }

    long countLines(String text) {
        return text.lines().count();
    }

    // ── repeat() ─────────────────────────────────────────────────────────────
    String divider(int width) {
        return "-".repeat(width);
    }

    String indent(String text, int spaces) {
        return " ".repeat(spaces) + text;
    }

    // ── stripLeading / stripTrailing ─────────────────────────────────────────
    String trimStart(String s) { return s.stripLeading(); }
    String trimEnd(String s)   { return s.stripTrailing(); }

    // ═══════════════════════════════════════════════════════════════════════
    // JDK 11 — Files one-liners
    // ═══════════════════════════════════════════════════════════════════════

    // BEFORE: BufferedReader/FileReader + loop + close in finally
    // AFTER:
    String readConfig(Path path) throws IOException {
        return Files.readString(path, StandardCharsets.UTF_8);
    }

    void writeReport(Path path, String content) throws IOException {
        Files.writeString(path, content,
            StandardCharsets.UTF_8,
            StandardOpenOption.CREATE,
            StandardOpenOption.TRUNCATE_EXISTING);
    }

    void appendLog(Path path, String line) throws IOException {
        Files.writeString(path, line + System.lineSeparator(),
            StandardCharsets.UTF_8,
            StandardOpenOption.CREATE,
            StandardOpenOption.APPEND);
    }

    // ── Path.of() — replaces Paths.get() ────────────────────────────────────
    Path buildPath(String base, String sub, String file) {
        return Path.of(base, sub, file);   // same as Paths.get(base, sub, file), cleaner name
    }

    // ═══════════════════════════════════════════════════════════════════════
    // JDK 11 — Predicate.not()
    // ═══════════════════════════════════════════════════════════════════════

    // BEFORE: s -> !s.isEmpty()   or   s -> !s.isBlank()
    // AFTER:
    List<String> cleanList(List<String> raw) {
        return raw.stream()
            .filter(Predicate.not(String::isBlank))   // method ref negated cleanly
            .map(String::strip)
            .distinct()
            .sorted()
            .toList();
    }

    // Works with any Predicate, not just method refs
    Set<String> BLACKLIST = Set.of("admin", "root");

    List<String> filterBlacklist(List<String> users) {
        return users.stream()
            .filter(Predicate.not(BLACKLIST::contains))
            .toList();
    }

    // ═══════════════════════════════════════════════════════════════════════
    // JDK 11 — Collection.toArray(IntFunction)
    // ═══════════════════════════════════════════════════════════════════════

    // BEFORE: list.toArray(new String[0])   ← works but relies on runtime type
    // AFTER:
    String[] toStringArray(List<String> list) {
        return list.toArray(String[]::new);   // no cast, no new String[0] idiom
    }

    // ═══════════════════════════════════════════════════════════════════════
    // JDK 11 — InputStream additions
    // ═══════════════════════════════════════════════════════════════════════

    byte[] readAllBytes(InputStream in) throws IOException {
        return in.readAllBytes();                        // reads until EOF; auto-sizes buffer
    }

    byte[] readChunk(InputStream in, int size) throws IOException {
        return in.readNBytes(size);                      // reads exactly size bytes (or EOF)
    }

    long pipe(InputStream in, OutputStream out) throws IOException {
        return in.transferTo(out);                       // copies all bytes; returns count
    }

    // /dev/null equivalents — useful for testing / discarding output
    void discardOutput() throws IOException {
        try (var sink = OutputStream.nullOutputStream()) {
            sink.write("ignored".getBytes());
        }
    }

    Stream<String> emptyLineSource() {
        return new BufferedReader(new InputStreamReader(InputStream.nullInputStream())).lines();
    }

    // ═══════════════════════════════════════════════════════════════════════
    // JDK 11 — HTTP Client (completed from JDK 9 incubator)
    // ═══════════════════════════════════════════════════════════════════════

    static final HttpClient CLIENT = HttpClient.newBuilder()
        .connectTimeout(Duration.ofSeconds(5))
        .followRedirects(HttpClient.Redirect.NORMAL)
        .version(HttpClient.Version.HTTP_2)
        .build();

    // Sync request
    String syncGet(String url) throws IOException, InterruptedException {
        var req = HttpRequest.newBuilder(URI.create(url))
            .header("Accept", "application/json")
            .timeout(Duration.ofSeconds(10))
            .GET()
            .build();
        return CLIENT.send(req, HttpResponse.BodyHandlers.ofString()).body();
    }

    // Async request — non-blocking
    java.util.concurrent.CompletableFuture<Integer> asyncPost(String url, String json) {
        var req = HttpRequest.newBuilder(URI.create(url))
            .header("Content-Type", "application/json")
            .POST(HttpRequest.BodyPublishers.ofString(json))
            .build();
        return CLIENT.sendAsync(req, HttpResponse.BodyHandlers.discarding())
            .thenApply(HttpResponse::statusCode);
    }

    // ── Pattern.asMatchPredicate() ────────────────────────────────────────────
    // asPredicate()      → Matcher.find()    (partial match)
    // asMatchPredicate() → Matcher.matches() (full match)
    static final Pattern UUID_PATTERN =
        Pattern.compile("[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}");

    boolean isValidUuid(String s) {
        return UUID_PATTERN.asMatchPredicate().test(s);   // full-string match
    }

    List<String> filterUuids(List<String> tokens) {
        return tokens.stream()
            .filter(UUID_PATTERN.asMatchPredicate())
            .toList();
    }
}
