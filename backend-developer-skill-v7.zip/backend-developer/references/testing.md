# Testing — Spring Boot + Java

Read this file when writing any test class. Covers: slice selection, MockMvc, Mockito,
TestContainers, async/event testing, and AssertJ patterns.

Cross-reference: `spring-web.md` · `spring-data.md` · `spring-core.md`

---

## Table of Contents

1. [Test slice decision table](#test-slice-decision-table)
2. [@WebMvcTest — controller layer](#webmvctest--controller-layer)
3. [@DataJpaTest — repository layer](#datajpatest--repository-layer)
4. [@SpringBootTest — integration](#springboottest--integration)
5. [Mockito — @MockBean vs @Mock](#mockito--mockbean-vs-mock)
6. [ArgumentCaptor](#argumentcaptor)
7. [TestContainers](#testcontainers)
8. [Testing @Async with Awaitility](#testing-async-with-awaitility)
9. [Testing @EventListener / @TransactionalEventListener](#testing-eventlistener--transactionaleventlistener)
10. [Testing @Transactional rollback](#testing-transactional-rollback)
11. [AssertJ patterns](#assertj-patterns)
12. [Testing virtual threads](#testing-virtual-threads)

---

## Test slice decision table

| What you're testing | Use | Spring context | DB |
|---|---|---|---|
| Controller validation, status codes, JSON serialization | `@WebMvcTest` | Partial (web layer only) | None (mock service) |
| Repository queries, JPQL, N+1, projections | `@DataJpaTest` | JPA slice only | In-memory H2 or TestContainers |
| Full request → service → DB round-trip | `@SpringBootTest` + `MockMvc` / `WebTestClient` | Full | TestContainers |
| Pure unit logic (service, domain) | Plain JUnit + Mockito | None | None |
| Async tasks, event listeners, scheduled jobs | `@SpringBootTest` | Full | As needed |

**Rule:** use the smallest slice that covers the concern. `@SpringBootTest` is expensive — reserve it for integration paths.

---

## @WebMvcTest — controller layer

Loads only the web layer (controllers, filters, `@ControllerAdvice`). Services and repositories must be mocked.

```java
@WebMvcTest(OrderController.class)
class OrderControllerTest {

    @Autowired MockMvc mvc;

    // @MockBean creates a Mockito mock AND registers it as a Spring bean
    @MockBean OrderService service;

    @Test
    void create_validRequest_returns201() throws Exception {
        var response = new OrderResponse(UUID.randomUUID(), "cust-1", "PENDING", 5000L, Instant.now());
        when(service.create(any())).thenReturn(response);

        mvc.perform(post("/api/v1/orders")
                .contentType(APPLICATION_JSON)
                .content("""
                        {"customerId":"cust-1","amountCents":5000,"currencyCode":"USD"}
                        """))
            .andExpect(status().isCreated())
            .andExpect(jsonPath("$.status").value("PENDING"))
            .andExpect(jsonPath("$.amountCents").value(5000));
    }

    @Test
    void create_blankCustomerId_returns400() throws Exception {
        mvc.perform(post("/api/v1/orders")
                .contentType(APPLICATION_JSON)
                .content("""{"customerId":"","amountCents":100,"currencyCode":"USD"}"""))
            .andExpect(status().isBadRequest())
            .andExpect(jsonPath("$.status").value(400));
        // service never called — validation fired before controller body
        verify(service, never()).create(any());
    }

    @Test
    void getById_notFound_returns404() throws Exception {
        when(service.findById(any())).thenReturn(Optional.empty());

        mvc.perform(get("/api/v1/orders/{id}", UUID.randomUUID()))
            .andExpect(status().isNotFound());
    }

    @Test
    void getById_found_returnsOrder() throws Exception {
        var id = UUID.randomUUID();
        var response = new OrderResponse(id, "cust-1", "CONFIRMED", 5000L, Instant.now());
        when(service.findById(id)).thenReturn(Optional.of(response));

        mvc.perform(get("/api/v1/orders/{id}", id))
            .andExpect(status().isOk())
            .andExpect(jsonPath("$.id").value(id.toString()));
    }
}
```

**MockMvc quick reference:**
```java
mvc.perform(get("/path").param("key", "val").header("X-TraceId", "abc"))
mvc.perform(put("/path/{id}", id).contentType(APPLICATION_JSON).content(json))
mvc.perform(delete("/path/{id}", id))
    .andExpect(status().isNoContent())
    .andExpect(content().contentType(APPLICATION_JSON))
    .andExpect(jsonPath("$.field").value("expected"))
    .andExpect(jsonPath("$.list", hasSize(3)))
    .andDo(print());   // prints request + response to console — useful while debugging
```

---

## @DataJpaTest — repository layer

Loads only JPA infrastructure. Rolls back each test by default. Use `@AutoConfigureTestDatabase(replace = NONE)` + TestContainers for real DB dialect.

```java
@DataJpaTest
@AutoConfigureTestDatabase(replace = AutoConfigureTestDatabase.Replace.NONE)
@Import(TestContainersConfig.class)   // see TestContainers section below
class OrderRepositoryTest {

    @Autowired OrderRepository repo;
    @Autowired TestEntityManager em;

    @Test
    void findSummariesByCustomerId_returnsProjection() {
        var customerId = "cust-42";
        em.persistAndFlush(new Order(customerId, 5000L));
        em.persistAndFlush(new Order(customerId, 8000L));
        em.clear();  // evict from first-level cache — force DB round-trip

        var results = repo.findSummariesByCustomerId(customerId);

        assertThat(results).hasSize(2);
        assertThat(results).extracting(OrderSummary::getAmountCents)
                           .containsExactlyInAnyOrder(5000L, 8000L);
    }

    @Test
    void findByIdAndCustomerId_wrongCustomer_returnsEmpty() {
        var order = em.persistAndFlush(new Order("cust-1", 1000L));
        em.clear();

        var result = repo.findByIdAndCustomerId(order.getId(), "cust-other");

        assertThat(result).isEmpty();
    }
}
```

**TestEntityManager tips:**
- `persistAndFlush(entity)` — saves and sends SQL immediately (within transaction)
- `em.clear()` — evict first-level cache; forces subsequent calls to hit DB
- Without `clear()`, `findById` may return the cached instance, not a real DB result

---

## @SpringBootTest — integration

Starts the full application context. Expensive — use for end-to-end paths only.

```java
@SpringBootTest(webEnvironment = SpringBootTest.WebEnvironment.RANDOM_PORT)
class OrderIntegrationTest {

    @Autowired TestRestTemplate rest;
    // OR: @Autowired WebTestClient webClient;  (for reactive or non-blocking assertions)

    @Test
    void createOrder_thenConfirm_fullRoundTrip() {
        var createReq = Map.of("customerId", "cust-1", "amountCents", 5000, "currencyCode", "USD");
        var created = rest.postForEntity("/api/v1/orders", createReq, OrderResponse.class);

        assertThat(created.getStatusCode()).isEqualTo(HttpStatus.CREATED);
        var id = created.getBody().id();

        var confirmed = rest.exchange("/api/v1/orders/{id}/confirm", PATCH, null, OrderResponse.class, id);
        assertThat(confirmed.getBody().status()).isEqualTo("CONFIRMED");
    }
}
```

```properties
# src/test/resources/application-test.properties
spring.jpa.hibernate.ddl-auto=create-drop
logging.level.org.hibernate.SQL=DEBUG   # see generated SQL during tests
```

---

## Mockito — @MockBean vs @Mock

| | `@Mock` (plain Mockito) | `@MockBean` (Spring) |
|---|---|---|
| Spring context | Not needed | Registers mock as bean in context |
| When to use | Pure unit tests (no Spring) | `@WebMvcTest`, `@SpringBootTest` |
| Lifecycle | Per test class (with `@ExtendWith(MockitoExtension.class)`) | Per test (reset between tests by default) |

```java
// Pure unit test — no Spring
@ExtendWith(MockitoExtension.class)
class OrderServiceTest {

    @Mock OrderRepository repo;
    @Mock ApplicationEventPublisher events;

    @InjectMocks OrderService service;  // creates OrderService with mocked deps

    @Test
    void create_persistsAndPublishesEvent() {
        var req = new CreateOrderRequest("cust-1", 5000L, "USD");
        var saved = new Order("cust-1", 5000L);
        when(repo.save(any())).thenReturn(saved);

        service.create(req);

        verify(repo).save(any(Order.class));
        verify(events).publishEvent(any(OrderCreatedEvent.class));
    }

    @Test
    void findById_notFound_throwsNotFoundException() {
        when(repo.findById(any())).thenReturn(Optional.empty());

        assertThatThrownBy(() -> service.findById(UUID.randomUUID()))
            .isInstanceOf(NotFoundException.class)
            .hasMessageContaining("not found");
    }
}
```

**Common Mockito patterns:**
```java
// Return values
when(repo.findById(id)).thenReturn(Optional.of(entity));
when(repo.save(any())).thenAnswer(inv -> inv.getArgument(0));  // return first arg

// Void methods
doNothing().when(events).publishEvent(any());
doThrow(new RuntimeException("fail")).when(gateway).charge(any());

// Verify interactions
verify(repo, times(1)).save(any());
verify(events, never()).publishEvent(any());
verify(repo, atLeastOnce()).findById(any());
verifyNoMoreInteractions(repo, events);

// Stubbing in order
InOrder inOrder = inOrder(repo, events);
inOrder.verify(repo).save(any());
inOrder.verify(events).publishEvent(any());
```

---

## ArgumentCaptor

Use when you need to assert on what was passed to a mock — not just that it was called.

```java
@Test
void create_publishesEventWithCorrectCustomerId() {
    var captor = ArgumentCaptor.forClass(OrderCreatedEvent.class);
    when(repo.save(any())).thenReturn(savedOrder);

    service.create(new CreateOrderRequest("cust-99", 1000L, "USD"));

    verify(events).publishEvent(captor.capture());
    assertThat(captor.getValue().customerId()).isEqualTo("cust-99");
    assertThat(captor.getValue().occurredAt()).isNotNull();
}

// Multiple captures (called N times)
verify(events, times(3)).publishEvent(captor.capture());
List<OrderCreatedEvent> captured = captor.getAllValues();
assertThat(captured).extracting(OrderCreatedEvent::customerId)
                    .containsExactly("cust-1", "cust-2", "cust-3");
```

---

## TestContainers

Use for integration tests that need a real database engine (PostgreSQL, MySQL, etc.).

```java
// Shared container config — loaded once per test suite run
@TestConfiguration
class TestContainersConfig {

    @Bean
    @ServiceConnection   // Spring Boot 3.1+: auto-wires datasource without @DynamicPropertySource
    PostgreSQLContainer<?> postgres() {
        return new PostgreSQLContainer<>("postgres:16-alpine");
    }
}

// Use in @DataJpaTest
@DataJpaTest
@AutoConfigureTestDatabase(replace = AutoConfigureTestDatabase.Replace.NONE)
@Import(TestContainersConfig.class)
class OrderRepositoryTest { ... }

// @ServiceConnection alternative — @DynamicPropertySource (pre-Boot 3.1 or explicit control)
@SpringBootTest
@Testcontainers
class OrderIntegrationTest {

    @Container
    static PostgreSQLContainer<?> postgres =
        new PostgreSQLContainer<>("postgres:16-alpine")
            .withDatabaseName("test")
            .withUsername("test")
            .withPassword("test");

    @DynamicPropertySource
    static void datasourceProperties(DynamicPropertyRegistry reg) {
        reg.add("spring.datasource.url",      postgres::getJdbcUrl);
        reg.add("spring.datasource.username", postgres::getUsername);
        reg.add("spring.datasource.password", postgres::getPassword);
    }
}
```

**Performance tip:** Declare containers as `static` — they start once per class, not once per test method.

---

## Testing @Async with Awaitility

`@Async` methods return before execution completes. Use Awaitility to poll for the expected state.

```java
<dependency>
    <groupId>org.awaitility</groupId>
    <artifactId>awaitility</artifactId>
    <scope>test</scope>
</dependency>
```

```java
@SpringBootTest
class NotificationServiceTest {

    @Autowired OrderService service;
    @Autowired NotificationRepository notifications;

    @Test
    void create_asyncEmailSent_withinTimeout() {
        service.create(new CreateOrderRequest("cust-1", 5000L, "USD"));

        // Poll up to 3 seconds, checking every 200ms
        await().atMost(3, SECONDS)
               .pollInterval(200, MILLISECONDS)
               .untilAsserted(() ->
                   assertThat(notifications.findByCustomerId("cust-1")).isNotEmpty()
               );
    }
}
```

**Alternative — CompletableFuture.get() for @Async that returns CompletableFuture:**
```java
CompletableFuture<Void> future = service.sendEmailAsync("user@example.com", "body");
future.get(5, TimeUnit.SECONDS);   // blocks until done or timeout
assertThat(emailSentFlag).isTrue();
```

---

## Testing @EventListener / @TransactionalEventListener

```java
// Spy on event listener to verify it was called
@SpringBootTest
class OrderEventTest {

    @Autowired OrderService service;
    @SpyBean NotificationListener listener;  // real bean + Mockito spy

    @Test
    void create_publishesOrderCreatedEvent() {
        var captor = ArgumentCaptor.forClass(OrderCreatedEvent.class);

        service.create(new CreateOrderRequest("cust-1", 5000L, "USD"));

        // @EventListener fires synchronously in same thread
        verify(listener).onOrderCreated(captor.capture());
        assertThat(captor.getValue().customerId()).isEqualTo("cust-1");
    }

    @Test
    @Transactional   // @TransactionalEventListener fires AFTER_COMMIT; test must commit
    void create_transactionalEventListener_firesAfterCommit() {
        // For @TransactionalEventListener: the test's own @Transactional wraps the call,
        // but AFTER_COMMIT fires ONLY when that outer transaction commits.
        // Solution: run in @Transactional(propagation = NOT_SUPPORTED) so each service
        // call commits its own transaction.
    }
}

// Cleaner approach: capture events via a test listener
@TestComponent
class TestEventCapture {
    final List<Object> events = new CopyOnWriteArrayList<>();

    @EventListener
    void capture(Object event) { events.add(event); }
}
```

---

## Testing @Transactional rollback

By default, `@Transactional` on a test method rolls back after the test. Useful for isolation:

```java
@DataJpaTest  // implies @Transactional
class OrderRepositoryTest {

    @Test
    // No annotation needed — @DataJpaTest wraps every test in a transaction that rolls back
    void save_persistsCorrectly() {
        var order = repo.save(new Order("cust-1", 1000L));
        assertThat(order.getId()).isNotNull();
        // rolled back after test — DB is clean for next test
    }

    @Test
    @Commit   // override rollback — use when you need to verify post-commit state
    void save_andVerifyInSeparateTransaction() { ... }
}

// @SpringBootTest does NOT roll back by default — add @Transactional explicitly
@SpringBootTest
@Transactional
class ServiceIntegrationTest { ... }
```

---

## AssertJ patterns

Prefer AssertJ (`assertThat`) over JUnit `assertEquals` — richer failure messages, fluent chaining.

```java
// Basic
assertThat(result).isNotNull();
assertThat(result.status()).isEqualTo("CONFIRMED");
assertThat(result.amountCents()).isPositive().isGreaterThan(0);

// Optional
assertThat(optResult).isPresent().get().extracting(OrderResponse::status).isEqualTo("PENDING");
assertThat(emptyOpt).isEmpty();

// Collections
assertThat(list).hasSize(3);
assertThat(list).extracting(Order::getStatus).containsExactlyInAnyOrder(PENDING, CONFIRMED, CANCELLED);
assertThat(list).filteredOn(o -> o.getAmountCents() > 1000).hasSize(2);
assertThat(list).allSatisfy(o -> assertThat(o.getCreatedAt()).isNotNull());
assertThat(list).anySatisfy(o -> assertThat(o.getStatus()).isEqualTo(CONFIRMED));

// Exception assertions
assertThatThrownBy(() -> service.findById(UUID.randomUUID()))
    .isInstanceOf(NotFoundException.class)
    .hasMessageContaining("not found");

assertThatCode(() -> service.cancel(id))
    .doesNotThrowAnyException();

// Soft assertions — collect all failures before reporting
SoftAssertions.assertSoftly(soft -> {
    soft.assertThat(result.id()).isNotNull();
    soft.assertThat(result.status()).isEqualTo("PENDING");
    soft.assertThat(result.amountCents()).isEqualTo(5000L);
});
```

---

## Testing virtual threads

When `spring.threads.virtual.enabled=true` is active in tests, verify no carrier pinning occurs:

```java
@SpringBootTest
@TestPropertySource(properties = "spring.threads.virtual.enabled=true")
class VirtualThreadTest {

    @Autowired OrderService service;

    @Test
    void handleRequest_runsOnVirtualThread() throws Exception {
        var threadName = new AtomicReference<String>();

        // Run via HTTP so it executes on Tomcat's virtual thread
        // Check thread name — virtual threads are named "tomcat-handler-N" or similar
        // Alternatively: use JFR to assert no VirtualThreadPinned events
    }

    @Test
    void concurrentRequests_noDeadlock() throws Exception {
        int count = 100;
        var latch = new CountDownLatch(count);
        var errors = new CopyOnWriteArrayList<Throwable>();

        try (var exec = Executors.newVirtualThreadPerTaskExecutor()) {
            for (int i = 0; i < count; i++) {
                exec.submit(() -> {
                    try {
                        service.findById(UUID.randomUUID());
                    } catch (NotFoundException ignored) {
                    } catch (Throwable t) {
                        errors.add(t);
                    } finally {
                        latch.countDown();
                    }
                });
            }
        }

        latch.await(10, SECONDS);
        assertThat(errors).isEmpty();
    }
}
```
