# Spring Boot — Core (Services, DI, Configuration, Events, Beans)

## Dependency Injection — always constructor injection

```java
@Service
public class OrderService {
    private final OrderRepository     repo;
    private final PaymentGateway      gateway;
    private final ApplicationEventPublisher events;

    // Constructor injection — explicit, testable, immutable, no Spring context needed in tests
    OrderService(OrderRepository repo, PaymentGateway gateway, ApplicationEventPublisher events) {
        this.repo    = repo;
        this.gateway = gateway;
        this.events  = events;
    }
}
```

**Never:**
- `@Autowired` on fields — untestable without Spring context, hides dependencies, Sonar S3016
- `@Autowired` on static fields — Spring doesn't inject static fields; stays `null` silently
- Setter injection for required dependencies — use only for optional dependencies

---

## Configuration — `@ConfigurationProperties` + record

```java
// Group related properties; validated at startup; injected where needed
@ConfigurationProperties(prefix = "app.payment")
record PaymentConfig(
    @NotBlank String apiKey,
    @NotNull URI endpoint,
    @Positive int maxRetries,
    @NotNull Duration timeout
) {}

// Register — one of:
@EnableConfigurationProperties(PaymentConfig.class)   // explicit on @Configuration class
// OR in main class / @ConfigurationPropertiesScan on package

// Inject as constructor param
@Service
class PaymentService {
    PaymentService(PaymentConfig config) { ... }
}
```

**`@ConfigurationProperties` vs `@Value`:**
- `@ConfigurationProperties` — group of related props; validated at startup; record is ideal
- `@Value` — single isolated property; SpEL expressions; legacy integration

Missing `@EnableConfigurationProperties` = config class silently ignored; all fields null. No startup error.

---

## Service layer patterns

```java
@Service
@Transactional(readOnly = true)     // class-level default; read-only = skip dirty check
public class OrderService {

    @Transactional                   // override for writes
    public OrderResponse create(CreateOrderRequest req) {
        Objects.requireNonNull(req, "request");

        var order = new Order(req.customerId(), req.amountCents());
        var saved = repo.save(order);

        // Publish domain event — decouples side effects (email, audit, cache invalidation)
        events.publishEvent(new OrderCreatedEvent(saved.getId(), saved.getCustomerId()));

        return OrderResponse.from(saved);
    }

    @Transactional
    public OrderResponse confirm(UUID id) {
        var order = repo.findById(id)
            .orElseThrow(() -> new NotFoundException("Order not found: " + id));
        order.confirm();      // state transition on entity
        // no explicit save — Hibernate dirty-check flushes on transaction commit
        events.publishEvent(new OrderConfirmedEvent(order.getId()));
        return OrderResponse.from(order);
    }
}
```

---

## Domain events

```java
// Event as record — immutable, carries all context
record OrderCreatedEvent(UUID orderId, String customerId, Instant occurredAt) {
    OrderCreatedEvent(UUID orderId, String customerId) {
        this(orderId, customerId, Instant.now());
    }
}

// Listener — runs in same transaction by default
@EventListener
void onOrderCreated(OrderCreatedEvent event) { sendConfirmationEmail(event.customerId()); }

// @TransactionalEventListener — runs AFTER transaction commits (safe for post-commit side effects)
@TransactionalEventListener(phase = TransactionPhase.AFTER_COMMIT)
void onOrderCreated(OrderCreatedEvent event) { sendEmail(event.customerId()); }
// If email fails, order is already saved — consider outbox pattern for at-least-once delivery
```

Use events when: action triggers side effects in other subsystems (email, audit, cache) without
tight coupling. Primary transaction stays independent of side effects.

---

## Prototype bean in singleton — common gotcha

```java
// BAD — Spring injects prototype once at singleton creation; same instance reused forever
@Service
class ReportService {
    @Autowired private ReportBuilder builder;   // prototype injected once = pointless
}

// GOOD — get a new instance per use
@Service
class ReportService {
    private final ObjectFactory<ReportBuilder> builderFactory;

    ReportService(ObjectFactory<ReportBuilder> factory) { this.builderFactory = factory; }

    void generate() {
        ReportBuilder builder = builderFactory.getObject();   // fresh instance each call
        builder.build();
    }
}
```

---

## Virtual threads — Spring Boot 3.2+

```properties
# application.properties — one property applies globally
spring.threads.virtual.enabled=true
```
Automatically applies to: Tomcat request threads, `@Async` executor, `@Scheduled` tasks,
`TaskExecutor`, `SimpleAsyncTaskExecutor`.

---

## Async and scheduling

```java
// @Async — fire-and-forget; returns CompletableFuture for callers that need result
@Async
CompletableFuture<Void> sendEmailAsync(String to, String body) {
    emailService.send(to, body);
    return CompletableFuture.completedFuture(null);
}

// @Scheduled — cron or fixed delay/rate
@Scheduled(cron = "0 0 2 * * *")              // 2 AM every day
@Scheduled(fixedDelay = 60_000)               // 60s after last completion
@Scheduled(fixedRate = 30_000)                // every 30s regardless of duration
void archiveOldOrders() { ... }
```

Enable: `@EnableAsync` and `@EnableScheduling` on a `@Configuration` class or main class.

---

## @Bean scope decisions

| Scope | When |
|---|---|
| `singleton` (default) | Stateless service / repository / client — always prefer |
| `prototype` | Stateful builder / parser that must not be shared across threads |
| `request` | Request-scoped data (Spring MVC only) |
| `session` | User session state (Spring MVC only) |

Prototype in singleton = subtle bug (see gotcha above).
Spring `@Bean` configured with wrong scope = new bean per request when singleton intended = memory pressure.

---

See also: `examples/springboot/OrderServiceStack.java`
