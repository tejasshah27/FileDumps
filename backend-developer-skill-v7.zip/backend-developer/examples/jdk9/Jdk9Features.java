package examples.jdk9;

import java.net.http.*;
import java.net.URI;
import java.time.Duration;
import java.util.*;
import java.util.concurrent.CompletableFuture;
import java.util.stream.*;

/**
 * JDK 9 — Immutable factories, Stream/Optional additions, private interface methods,
 *          try-with-resources polish, VarHandle, StackWalker
 *
 * SCENARIO GUIDE — when to use each pattern:
 *
 * List.of / Set.of / Map.of vs new ArrayList / new HashMap
 *   USE List.of WHEN: collection is known at compile time and will never change.
 *   These are null-hostile (throw NPE on null element/key/value) — use intentionally
 *   to catch null bugs early.
 *   DO NOT use when: collection needs to grow, allow nulls, or be serialized with
 *   frameworks that require ArrayList/HashMap specifically.
 *   Map.ofEntries() — use when > 10 pairs; Map.of() only supports up to 10.
 *
 * List.copyOf / Map.copyOf — defensive immutable copy
 *   USE WHEN: accepting a mutable collection as input and storing it in a field.
 *   Prevents caller from mutating state after construction.
 *   record compact constructor is the canonical place: this.items = List.copyOf(items);
 *
 * Stream.ofNullable vs null-check + Stream.of
 *   BEFORE: value != null ? Stream.of(value) : Stream.empty()  — verbose
 *   USE Stream.ofNullable WHEN: integrating a nullable value into a stream pipeline.
 *
 * takeWhile / dropWhile vs filter
 *   filter     — scans ALL elements, regardless of order.
 *   takeWhile  — stops at FIRST element that fails the predicate (ordered streams only).
 *   USE takeWhile WHEN: data is sorted/ordered and you want a prefix (e.g. events before date).
 *   USE dropWhile WHEN: skipping a known-ordered header/prefix (e.g. comment lines at top).
 *   CAUTION: on unordered/parallel streams, behaviour is non-deterministic.
 *
 * 3-arg Stream.iterate(seed, predicate, step) vs limit()
 *   BEFORE: Stream.iterate(0, n -> n+1).limit(10) — limit is a separate step.
 *   USE 3-arg WHEN: termination condition is intrinsic to the iteration (n < max),
 *   not an external count. Reads like a for-loop, avoids accidental infinite stream.
 *
 * Private interface methods
 *   USE WHEN: two or more default methods share logic that must not be exposed to
 *   implementors. Without private methods, you'd have to make helper logic a default
 *   (exposing it) or duplicate it.
 *
 * VarHandle vs AtomicFieldUpdater vs Unsafe
 *   AtomicFieldUpdater — legacy; reflection-based; slower; no array element support.
 *   Unsafe             — internal JDK API; breaks between versions; forbidden in modules.
 *   USE VarHandle WHEN: lock-free field updates (CAS, getAndAdd) on instance fields
 *   in a class you own. Faster than AtomicFieldUpdater, safe unlike Unsafe.
 *
 * StackWalker vs Thread.currentThread().getStackTrace()
 *   getStackTrace()  — eagerly captures ENTIRE stack as array; expensive even if you
 *                      only need frame 0.
 *   USE StackWalker WHEN: inspecting stack lazily; specify RETAIN_CLASS_REFERENCE option
 *   if you need the actual Class object. 10–100x cheaper than getStackTrace() for
 *   partial inspection.
 *
 * try-with-resources on existing variable (JDK 9)
 *   BEFORE: had to redeclare: try (InputStream in2 = in) { ... }
 *   AFTER:  try (in) { ... }  — cleaner, no extra variable in scope.
 */
public class Jdk9Features {

    // ── Immutable collection factories ───────────────────────────────────────
    // BEFORE: Arrays.asList / Collections.unmodifiableList(new ArrayList<>(...))
    // AFTER:  null-hostile, compact, no copy overhead

    static final List<String> HTTP_METHODS  = List.of("GET","POST","PUT","PATCH","DELETE","HEAD");
    static final Set<String>  RESERVED      = Set.of("admin","root","system","null");
    static final Map<Integer,String> HTTP_STATUS = Map.of(
        200, "OK", 201, "Created", 400, "Bad Request",
        401, "Unauthorized", 403, "Forbidden", 404, "Not Found",
        409, "Conflict", 422, "Unprocessable Entity", 500, "Internal Server Error");

    // For > 10 map entries use ofEntries
    static final Map<String, Integer> WEIGHTS = Map.ofEntries(
        Map.entry("LOW",    1),
        Map.entry("MEDIUM", 2),
        Map.entry("HIGH",   3),
        Map.entry("CRITICAL",4)
    );

    // Defensive copy — snapshot mutable input into immutable
    record Config(Map<String, String> properties) {
        Config(Map<String, String> properties) {
            this.properties = Map.copyOf(properties);   // throws if any value is null
        }
    }

    // ── Stream additions ─────────────────────────────────────────────────────

    // takeWhile / dropWhile — ordered short-circuit
    List<Integer> topUntilNegative(List<Integer> nums) {
        return nums.stream()
            .takeWhile(n -> n >= 0)     // stop at first negative
            .toList();
    }

    List<Integer> skipHeader(List<String> lines) {
        return lines.stream()
            .dropWhile(l -> l.startsWith("#"))   // skip comment lines
            .map(Integer::parseInt)
            .toList();
    }

    // Stream.ofNullable — 0 or 1 element; replaces null-check + Stream.of
    // BEFORE: value != null ? Stream.of(value) : Stream.empty()
    // AFTER:
    Stream<String> maybeStream(String nullable) {
        return Stream.ofNullable(nullable);
    }

    // iterate with predicate — bounded infinite stream
    List<Integer> powersOfTwo(int limit) {
        return Stream.iterate(1, n -> n <= limit, n -> n * 2).toList();
        // 1, 2, 4, 8, ... up to limit
    }

    // ── Optional additions ───────────────────────────────────────────────────

    Optional<String> findConfig(String key) { return Optional.empty(); } // stub

    void demoOptionalAdditions(String key) {
        // ifPresentOrElse — single expression for both branches
        findConfig(key).ifPresentOrElse(
            v  -> System.out.println("Found: " + v),
            () -> System.out.println("Not found, using default"));

        // or() — chain to fallback Optional (lazy)
        String value = findConfig(key)
            .or(() -> findConfig("default." + key))  // try fallback key
            .orElse("hardcoded-default");

        // stream() — integrate into stream pipeline cleanly
        List<String> presentValues = List.of("k1","k2","k3").stream()
            .flatMap(k -> findConfig(k).stream())    // skip empties naturally
            .toList();
    }

    // ── Collectors.filtering + flatMapping ───────────────────────────────────

    record Employee(String dept, String name, boolean active, List<String> skills) {}

    // filtering inside groupingBy — count only active per dept
    Map<String, Long> activeCountByDept(List<Employee> employees) {
        return employees.stream()
            .collect(Collectors.groupingBy(
                Employee::dept,
                Collectors.filtering(Employee::active, Collectors.counting())));
    }

    // flatMapping inside groupingBy — all skills per dept (deduplicated)
    Map<String, Set<String>> skillsByDept(List<Employee> employees) {
        return employees.stream()
            .collect(Collectors.groupingBy(
                Employee::dept,
                Collectors.flatMapping(
                    e -> e.skills().stream(),
                    Collectors.toUnmodifiableSet())));
    }

    // ── try-with-resources on effectively-final variables ────────────────────
    // BEFORE (JDK 7-8): must redeclare in try(...)
    // AFTER (JDK 9): use existing final/effectively-final variable directly
    void copyStream(java.io.InputStream source, java.io.OutputStream dest) throws java.io.IOException {
        try (source; dest) {            // no new variable declarations needed
            source.transferTo(dest);
        }
    }

    // ── Private interface methods ────────────────────────────────────────────
    interface ResponseBuilder {
        default String ok(String body)       { return build(200, body); }
        default String created(String body)  { return build(201, body); }
        default String notFound(String msg)  { return build(404, msg); }
        default String error(String msg)     { return build(500, msg); }

        private String build(int status, String body) {
            // shared logic — not accessible to implementors
            return """
                HTTP/1.1 %d %s
                Content-Length: %d

                %s""".formatted(status, HTTP_STATUS.getOrDefault(status, "Unknown"), body.length(), body);
        }
    }

    // ── StackWalker — cheap lazy stack inspection ─────────────────────────────
    // BEFORE: Thread.currentThread().getStackTrace() — loads entire stack eagerly
    // AFTER:
    static String callerClassName() {
        return StackWalker.getInstance()
            .walk(frames -> frames
                .skip(1)                // skip callerClassName itself
                .findFirst()
                .map(StackWalker.StackFrame::getClassName)
                .orElse("unknown"));
    }

    static Optional<StackWalker.StackFrame> findCallerInPackage(String pkg) {
        return StackWalker.getInstance()
            .walk(frames -> frames
                .filter(f -> f.getClassName().startsWith(pkg))
                .findFirst());
    }

    // ── VarHandle — lock-free field operations without Unsafe ────────────────
    static class LockFreeCounter {
        private volatile int count = 0;

        private static final java.lang.invoke.VarHandle COUNT;
        static {
            try {
                COUNT = java.lang.invoke.MethodHandles.lookup()
                    .findVarHandle(LockFreeCounter.class, "count", int.class);
            } catch (ReflectiveOperationException e) {
                throw new ExceptionInInitializerError(e);
            }
        }

        void increment() {
            int current;
            do { current = (int) COUNT.getVolatile(this); }
            while (!COUNT.compareAndSet(this, current, current + 1));
        }

        int get() { return (int) COUNT.getVolatile(this); }
    }

    // ── HTTP Client (finalized JDK 11, available JDK 9+) ────────────────────
    static final HttpClient HTTP = HttpClient.newBuilder()
        .connectTimeout(Duration.ofSeconds(5))
        .followRedirects(HttpClient.Redirect.NORMAL)
        .build();

    CompletableFuture<String> getJson(String url) {
        var request = HttpRequest.newBuilder(URI.create(url))
            .header("Accept", "application/json")
            .timeout(Duration.ofSeconds(10))
            .GET()
            .build();
        return HTTP.sendAsync(request, HttpResponse.BodyHandlers.ofString())
            .thenApply(HttpResponse::body);
    }
}
