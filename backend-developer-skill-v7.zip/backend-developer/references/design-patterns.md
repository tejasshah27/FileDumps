# Design Patterns & Principles — Java + Spring Boot

Read this file when choosing between structural approaches or when the task involves
recognisable application-architecture patterns (builder, CQRS, outbox, circuit breaker, etc.).

Every pattern here is presented as a scenario with when to use it, not as a feature listing.

Cross-reference: `types-and-oop.md` · `spring-core.md` · `spring-data.md` · `optional-and-errors.md`

---

## Table of Contents

1. [SOLID — mapping to skill idioms](#solid--mapping-to-skill-idioms)
2. [Builder](#builder)
3. [Factory Method / Static Factory](#factory-method--static-factory)
4. [Strategy (via interfaces and sealed interfaces)](#strategy-via-interfaces-and-sealed-interfaces)
5. [Decorator](#decorator)
6. [Template Method](#template-method)
7. [Specification (dynamic queries)](#specification-dynamic-queries)
8. [CQRS — Command/Query Responsibility Segregation](#cqrs--commandquery-responsibility-segregation)
9. [Outbox Pattern — reliable event publishing](#outbox-pattern--reliable-event-publishing)
10. [Circuit Breaker and Retry (Resilience4j)](#circuit-breaker-and-retry-resilience4j)
11. [Pattern decision table](#pattern-decision-table)

---

## SOLID — mapping to skill idioms

Understanding how this skill's default idioms map to SOLID principles helps you reason about
*why* the rules exist rather than applying them mechanically.

| Principle | Definition | How it appears in this skill |
|---|---|---|
| **S** Single Responsibility | A class has one reason to change | Record DTOs carry data only; entities carry state-transition methods only; services orchestrate only |
| **O** Open/Closed | Open for extension, closed for modification | Sealed interfaces + pattern switch: add a new case without modifying existing logic |
| **L** Liskov Substitution | Subtypes are substitutable for their base type | Records implementing interfaces; sealed subtypes fulfilling interface contracts |
| **I** Interface Segregation | Clients depend only on methods they use | Spring Data repository interfaces expose only the methods each caller needs; projections expose only the fields a read path needs |
| **D** Dependency Inversion | High-level modules depend on abstractions | Constructor injection of interfaces; domain service depends on `OrderRepository` interface, not `JpaOrderRepository` |

---

## Builder

### When to use Builder vs other approaches

| Scenario | Approach |
|---|---|
| ≤ 4 fields, all required | Constructor or `record` canonical constructor |
| Many fields, several optional, construction logic matters | Builder (manual or Lombok) |
| Immutable object with complex validation | `record` + compact constructor; nested `Builder` class for ergonomics |
| Framework requires no-arg constructor (JPA entity) | Separate `Builder` class producing the entity via package-private setters |

### Manual Builder (idiomatic Java, no Lombok)

```java
public final class NotificationRequest {

    private final String  to;
    private final String  subject;
    private final String  body;
    private final boolean html;
    private final Instant scheduledAt;

    private NotificationRequest(Builder b) {
        this.to          = Objects.requireNonNull(b.to,      "to");
        this.subject     = Objects.requireNonNull(b.subject, "subject");
        this.body        = Objects.requireNonNull(b.body,    "body");
        this.html        = b.html;
        this.scheduledAt = b.scheduledAt != null ? b.scheduledAt : Instant.now();
    }

    // Accessors (no setters — immutable)
    public String  to()          { return to; }
    public String  subject()     { return subject; }
    public String  body()        { return body; }
    public boolean html()        { return html; }
    public Instant scheduledAt() { return scheduledAt; }

    public static Builder builder(String to) { return new Builder(to); }

    public static final class Builder {
        private final String to;
        private String  subject;
        private String  body;
        private boolean html;
        private Instant scheduledAt;

        private Builder(String to) { this.to = to; }

        public Builder subject(String subject) { this.subject = subject; return this; }
        public Builder body(String body)       { this.body    = body;    return this; }
        public Builder html(boolean html)      { this.html    = html;    return this; }
        public Builder scheduledAt(Instant at) { this.scheduledAt = at;  return this; }

        public NotificationRequest build()     { return new NotificationRequest(this); }
    }
}

// Usage
var req = NotificationRequest.builder("user@example.com")
    .subject("Order confirmed")
    .body("Your order #12345 is confirmed.")
    .html(false)
    .build();
```

### Lombok @Builder (reduces boilerplate, team must accept Lombok dependency)

```java
@Builder(toBuilder = true)   // toBuilder = true: req.toBuilder().subject("new").build()
@Value                       // Lombok: generates final fields + all-args constructor + accessors
public class NotificationRequest {
    @NonNull String  to;
    @NonNull String  subject;
    @NonNull String  body;
    boolean          html;
    Instant          scheduledAt;
}

// Usage — identical ergonomics as manual builder
var req = NotificationRequest.builder()
    .to("user@example.com")
    .subject("Order confirmed")
    .body("...")
    .build();
```

**Gotcha:** Lombok `@Builder` does not validate required fields at compile time. `@NonNull` adds a null check but throws at runtime. Manual builder allows required fields in the factory method signature — caught at compile time.

---

## Factory Method / Static Factory

Prefer static factory methods over constructors when:
- The method name communicates intent better than `new`
- Multiple creation paths need different names
- You want to return a subtype or cached instance

```java
// Record DTO — static from(Entity) keeps mapping logic in the DTO
record OrderResponse(UUID id, String status, long amountCents, Instant createdAt) {

    // Factory: name communicates transformation direction
    static OrderResponse from(Order entity) {
        return new OrderResponse(
            entity.getId(),
            entity.getStatus().name(),
            entity.getAmountCents(),
            entity.getCreatedAt()
        );
    }

    // Named constructor for a specific context
    static OrderResponse cancelled(UUID id) {
        return new OrderResponse(id, "CANCELLED", 0L, Instant.now());
    }
}

// Sealed hierarchy — each subtype is a named result
sealed interface TransferResult permits TransferResult.Ok, TransferResult.Failed {
    record Ok(String transactionId, Instant at) implements TransferResult {
        static Ok of(String txId) { return new Ok(txId, Instant.now()); }
    }
    record Failed(String reason, int code) implements TransferResult {}
}

// Call site — clear intent
return switch (gateway.transfer(amount)) {
    case TransferResult.Ok   ok  -> process(ok);
    case TransferResult.Failed f -> handleFailure(f);
};
```

---

## Strategy (via interfaces and sealed interfaces)

Encapsulate interchangeable algorithms or policies behind a common interface. Spring DI makes injection of the right strategy easy.

```java
// Strategy interface
public interface ShippingCalculator {
    long calculateCents(Order order);
}

// Implementations — each registered as a Spring bean
@Component("standard") class StandardShipping  implements ShippingCalculator { ... }
@Component("express")  class ExpressShipping   implements ShippingCalculator { ... }
@Component("freight")  class FreightShipping   implements ShippingCalculator { ... }

// Selector — picks the strategy at runtime (avoid if/else chains by using a Map)
@Service
public class ShippingService {

    private final Map<String, ShippingCalculator> calculators;

    ShippingService(Map<String, ShippingCalculator> calculators) {
        this.calculators = calculators;  // Spring autowires all beans by qualifier name
    }

    public long calculate(Order order) {
        var calculator = calculators.get(order.shippingTier());
        if (calculator == null)
            throw new IllegalArgumentException("Unknown shipping tier: " + order.shippingTier());
        return calculator.calculateCents(order);
    }
}
```

**Sealed interface as closed strategy set** — when the set of strategies is fixed and exhaustive handling is required at compile time:

```java
sealed interface PricingRule permits FixedDiscount, PercentageDiscount, BuyXGetY {
    long apply(long priceCents, int quantity);
}
record FixedDiscount(long discountCents) implements PricingRule {
    public long apply(long price, int qty) { return Math.max(0, price - discountCents); }
}
record PercentageDiscount(int percent) implements PricingRule {
    public long apply(long price, int qty) { return price - (price * percent / 100); }
}
record BuyXGetY(int buyQty, int freeQty) implements PricingRule {
    public long apply(long unitPrice, int qty) {
        var groups = qty / (buyQty + freeQty);
        return unitPrice * (qty - groups * freeQty);
    }
}

// Exhaustive switch — compiler enforces all cases
long priceAfterRule(PricingRule rule, long price, int qty) {
    return switch (rule) {
        case FixedDiscount   fd  -> fd.apply(price, qty);
        case PercentageDiscount p -> p.apply(price, qty);
        case BuyXGetY       bxgy -> bxgy.apply(price, qty);
    };
}
```

---

## Decorator

Adds behaviour to an existing object without modifying it. In Spring Boot, the Decorator pattern often appears as a wrapper around a service or repository.

```java
// Base interface
public interface NotificationSender {
    void send(NotificationRequest req);
}

// Real implementation
@Component
@Primary
public class SmtpNotificationSender implements NotificationSender {
    public void send(NotificationRequest req) { /* SMTP logic */ }
}

// Decorator — adds retry behaviour transparently
@Component
public class RetryingNotificationSender implements NotificationSender {

    private final NotificationSender delegate;
    private static final int MAX_RETRIES = 3;

    // Inject with @Qualifier to avoid circular injection with @Primary
    RetryingNotificationSender(@Qualifier("smtpNotificationSender") NotificationSender delegate) {
        this.delegate = delegate;
    }

    @Override
    public void send(NotificationRequest req) {
        for (int attempt = 1; attempt <= MAX_RETRIES; attempt++) {
            try {
                delegate.send(req);
                return;
            } catch (TransientMailException ex) {
                if (attempt == MAX_RETRIES) throw ex;
                log.warn("Send attempt {} failed, retrying", attempt, ex);
            }
        }
    }
}
```

**Spring AOP as transparent Decorator** — when behaviour (logging, metrics, retry) should be added without the caller or callee knowing:

```java
@Aspect
@Component
public class TimingAspect {

    private final MeterRegistry meters;

    @Around("@annotation(timed)")
    public Object time(ProceedingJoinPoint pjp, Timed timed) throws Throwable {
        return Timer.builder(timed.value())
            .description(timed.description())
            .register(meters)
            .record(pjp::proceed);
    }
}
```

---

## Template Method

Defines the skeleton of an algorithm in a base class; subclasses override specific steps.
In Spring Boot this often appears as abstract services for report generation, data import pipelines, or batch processing.

```java
// Abstract template — defines the algorithm steps
public abstract class ReportGenerationService<T> {

    // Template method — the invariant algorithm
    public final Report generate(ReportRequest req) {
        validate(req);                    // step 1 — always
        var rawData = fetchData(req);     // step 2 — subclass provides
        var processed = transform(rawData); // step 3 — default or override
        return buildReport(processed, req); // step 4 — always
    }

    protected void validate(ReportRequest req) {
        Objects.requireNonNull(req, "req");
        if (req.from().isAfter(req.to())) throw new IllegalArgumentException("from > to");
    }

    protected abstract List<T> fetchData(ReportRequest req);

    protected List<T> transform(List<T> data) { return data; }  // default: no-op

    private Report buildReport(List<T> data, ReportRequest req) {
        return new Report(req.title(), data.size(), Instant.now());
    }
}

// Concrete implementations
@Service
public class SalesReportService extends ReportGenerationService<SalesRecord> {
    @Override protected List<SalesRecord> fetchData(ReportRequest req) {
        return repo.findSalesInRange(req.from(), req.to());
    }
    @Override protected List<SalesRecord> transform(List<SalesRecord> data) {
        return data.stream().filter(r -> r.amount() > 0).toList();
    }
}

@Service
public class RefundReportService extends ReportGenerationService<RefundRecord> {
    @Override protected List<RefundRecord> fetchData(ReportRequest req) {
        return repo.findRefundsInRange(req.from(), req.to());
    }
}
```

---

## Specification (dynamic queries)

Use when: search screens, API filters, or admin dashboards where the WHERE clauses vary at runtime based on user input. Avoids a proliferation of repository methods for every combination of filters.

```java
// Specification interface is provided by Spring Data JPA
// Your repository extends JpaSpecificationExecutor
interface OrderRepository extends JpaRepository<Order, UUID>,
                                   JpaSpecificationExecutor<Order> {}

// Specification builder — compose conditions
public class OrderSpecs {

    public static Specification<Order> hasCustomerId(String customerId) {
        return (root, query, cb) ->
            customerId == null ? null : cb.equal(root.get("customerId"), customerId);
    }

    public static Specification<Order> hasStatus(OrderStatus status) {
        return (root, query, cb) ->
            status == null ? null : cb.equal(root.get("status"), status);
    }

    public static Specification<Order> createdAfter(Instant after) {
        return (root, query, cb) ->
            after == null ? null : cb.greaterThanOrEqualTo(root.get("createdAt"), after);
    }

    public static Specification<Order> amountGreaterThan(long cents) {
        return (root, query, cb) ->
            cb.greaterThan(root.get("amountCents"), cents);
    }
}

// Service layer — compose specs dynamically
@Service
public class OrderSearchService {

    public Page<Order> search(OrderSearchRequest req, Pageable pageable) {
        var spec = Specification
            .where(OrderSpecs.hasCustomerId(req.customerId()))
            .and(OrderSpecs.hasStatus(req.status()))
            .and(OrderSpecs.createdAfter(req.since()))
            .and(req.minAmount() != null ? OrderSpecs.amountGreaterThan(req.minAmount()) : null);

        return repo.findAll(spec, pageable);
    }
}
```

**When NOT to use Specification:**
- Simple, fixed-column lookup (use derived queries — more readable, no boilerplate)
- Native SQL needed (JSONB, window functions, CTEs — use `@Query` with native SQL)
- Report aggregation (projection + JPQL is faster and lighter)

---

## CQRS — Command/Query Responsibility Segregation

Separate the write model (commands that change state) from the read model (queries that return data).
In Spring Boot, CQRS is usually applied at the service layer using JPA projections — not necessarily with separate databases.

```
Write side (Command)          Read side (Query)
─────────────────────         ──────────────────────
CreateOrderCommand  ──►  OrderEntity (mutable, full)
ConfirmOrderCommand ──►  JpaRepository.save(entity)
                          ↓
                          OrderSummaryView (projection)
                          OrderDetailView  (projection)
                          ──► returned to API caller
```

```java
// Command (write) — operates on full entity, saves changes
@Service
@Transactional
public class OrderCommandService {

    public UUID create(CreateOrderRequest cmd) {
        var order = new Order(cmd.customerId(), cmd.amountCents());
        return repo.save(order).getId();
    }

    public void confirm(UUID id) {
        repo.findById(id).orElseThrow().confirm();
        // Hibernate dirty-check flushes the state change at commit — no explicit save
    }
}

// Query (read) — returns lightweight projections; never mutates
@Service
@Transactional(readOnly = true)
public class OrderQueryService {

    public Optional<OrderDetailView> findById(UUID id) {
        return repo.findDetailById(id);       // projection — only the columns needed
    }

    public Page<OrderSummaryView> listByCustomer(String customerId, Pageable pageable) {
        return repo.findSummariesByCustomerId(customerId, pageable);
    }
}

// Read model — projections (lighter than full entity; no first-level cache overhead)
interface OrderSummaryView {
    UUID    getId();
    String  getStatus();
    long    getAmountCents();
    Instant getCreatedAt();
}

record OrderDetailView(UUID id, String customerId, String status,
                       long amountCents, Instant createdAt) {}
```

**CQRS benefits:**
- Read paths are lighter and faster (projections, `readOnly = true`)
- Write paths are focused on invariant enforcement
- Scales independently — read replicas can serve queries, primary handles writes
- Aligns with the projection guidance in `references/spring-data.md`

---

## Outbox Pattern — reliable event publishing

**Problem:** Publishing a domain event after a database write has a dual-write race condition. If the service crashes after the DB commit but before the event is sent to the message broker, the event is lost. If the event is sent before the DB commit, it may refer to data that was never persisted.

**Solution:** Write the event to an `outbox` table in the **same transaction** as the domain entity. A separate process (scheduler or CDC) reliably delivers it to the broker.

```java
// Outbox entry — stored in same transaction as the business entity
@Entity
@Table(name = "outbox_events")
class OutboxEvent {
    @Id @GeneratedValue(strategy = GenerationType.UUID)
    private UUID id;

    @Column(nullable = false)
    private String aggregateType;   // e.g. "Order"

    @Column(nullable = false)
    private String aggregateId;     // e.g. order UUID

    @Column(nullable = false)
    private String eventType;       // e.g. "OrderCreated"

    @Column(columnDefinition = "jsonb", nullable = false)
    private String payload;         // serialised event JSON

    @Column(nullable = false, updatable = false)
    private Instant createdAt = Instant.now();

    private Instant processedAt;    // null = pending delivery
}

// Service — writes entity + outbox entry in one transaction
@Service
@Transactional
public class OrderCommandService {

    private final OrderRepository     repo;
    private final OutboxRepository    outbox;
    private final ObjectMapper        mapper;

    public UUID create(CreateOrderRequest cmd) throws JsonProcessingException {
        var order  = repo.save(new Order(cmd.customerId(), cmd.amountCents()));
        var event  = new OrderCreatedEvent(order.getId(), order.getCustomerId());
        var entry  = new OutboxEvent();
        entry.setAggregateType("Order");
        entry.setAggregateId(order.getId().toString());
        entry.setEventType("OrderCreated");
        entry.setPayload(mapper.writeValueAsString(event));
        outbox.save(entry);   // same transaction — atomically paired with entity save
        return order.getId();
    }
}

// Relay — polls outbox and publishes (or use Debezium CDC for true zero-latency)
@Component
public class OutboxRelay {

    private final OutboxRepository    outbox;
    private final KafkaTemplate<String, String> kafka;

    @Scheduled(fixedDelay = 1000)   // poll every second
    @Transactional
    public void relay() {
        outbox.findByProcessedAtIsNullOrderByCreatedAtAsc()
              .forEach(entry -> {
                  kafka.send("orders." + entry.getEventType(), entry.getAggregateId(), entry.getPayload());
                  entry.setProcessedAt(Instant.now());   // mark as delivered
              });
    }
}
```

**When to use Outbox:**
- Any service that writes to a DB *and* publishes to Kafka/RabbitMQ
- When at-least-once delivery is required (the relay can retry on failure)
- When `@TransactionalEventListener` is insufficient (crashes after commit lose the event)

**Simpler alternative for at-most-once:** use `@TransactionalEventListener(phase = AFTER_COMMIT)` — the event is published after the transaction commits. If the service crashes before the listener fires, the event is lost. Acceptable for non-critical side effects (send a notification email) but not for business-critical events.

---

## Circuit Breaker and Retry (Resilience4j)

Use when calling external services (HTTP APIs, payment gateways, 3rd-party providers) that may be slow or unavailable.

```xml
<!-- pom.xml -->
<dependency>
    <groupId>io.github.resilience4j</groupId>
    <artifactId>resilience4j-spring-boot3</artifactId>
</dependency>
```

```java
@Service
public class PaymentGatewayClient {

    private final WebClient webClient;

    // @Retry — retry on transient failures before giving up
    // @CircuitBreaker — open the circuit after repeated failures to fail fast
    // Order matters: CircuitBreaker wraps Retry — retry first, open circuit if retries exhausted
    @Retry(name = "payment", fallbackMethod = "payFallback")
    @CircuitBreaker(name = "payment", fallbackMethod = "payFallback")
    public PaymentResult pay(PaymentRequest req) {
        return webClient.post()
            .uri("/payments")
            .bodyValue(req)
            .retrieve()
            .bodyToMono(PaymentResult.class)
            .block();
    }

    // Fallback — same signature + the exception as last parameter
    PaymentResult payFallback(PaymentRequest req, Exception ex) {
        log.warn("Payment gateway unavailable, using fallback", ex);
        return PaymentResult.pending(req.orderId());   // or throw a domain exception
    }
}
```

```yaml
# application.yaml — Resilience4j configuration
resilience4j:
  retry:
    instances:
      payment:
        max-attempts: 3
        wait-duration: 500ms
        retry-exceptions:
          - java.net.ConnectException
          - java.util.concurrent.TimeoutException
        ignore-exceptions:
          - com.example.PaymentDeclinedException   # don't retry business rejections

  circuit-breaker:
    instances:
      payment:
        sliding-window-size: 10
        failure-rate-threshold: 50          # open circuit if 50%+ of last 10 calls fail
        wait-duration-in-open-state: 30s    # wait 30s in OPEN before trying again (HALF_OPEN)
        permitted-number-of-calls-in-half-open-state: 3
        record-exceptions:
          - java.lang.Exception
        ignore-exceptions:
          - com.example.PaymentDeclinedException

  rate-limiter:
    instances:
      payment:
        limit-for-period: 100         # max 100 calls per refresh period
        limit-refresh-period: 1s
        timeout-duration: 0           # fail immediately if rate limit hit (don't queue)
```

**Annotation stacking order** (outermost wraps innermost):
```
@RateLimiter → @CircuitBreaker → @Retry → @TimeLimiter → actual method call
```

**When to apply which:**

| Concern | Annotation |
|---|---|
| Transient network errors (retryable) | `@Retry` |
| Service unavailable (stop hammering) | `@CircuitBreaker` |
| Traffic throttle on outbound calls | `@RateLimiter` |
| Prevent calls hanging indefinitely | `@TimeLimiter` |

---

## Pattern decision table

| Situation | Pattern |
|---|---|
| Object with many optional fields, complex construction | Builder |
| Multiple creation paths with meaningful names | Static Factory |
| Named result types with different data shapes | Sealed interface + record subtypes |
| Swappable algorithms (pricing, shipping, discounting) | Strategy + Spring DI Map injection |
| Cross-cutting behaviour (logging, metrics, retry) without modifying callee | Decorator or Spring AOP |
| Invariant algorithm with customisable steps | Template Method (abstract class) |
| Dynamic search/filter queries at runtime | Specification + JpaSpecificationExecutor |
| Separate read performance from write complexity | CQRS (command service + query service + projections) |
| Reliable event delivery across DB + message broker | Outbox Pattern |
| External service resilience (retry, fail-fast) | Resilience4j @CircuitBreaker + @Retry |
