---
name: backend-developer
description: >
  Expert Java + Spring Boot backend code generation. Use whenever the user asks to write,
  review, refactor, or design any Java code, Spring Boot service, REST API, repository,
  config class, DTO, domain model, scheduler, event, exception handler, filter, interceptor,
  mapper, or any backend component. Triggers on: Java, Spring, Spring Boot, JPA, Hibernate,
  REST, microservice, controller, entity, repository, DTO, mapper, config, backend, endpoint,
  service layer. Apply for any Java code request — even tiny snippets benefit from modern idioms.
  Always default to newest LTS feature available. Always write Sonar-clean, zero-boilerplate code.
---

# Backend Developer — Java + Spring Boot

## North Star
Readable > Clever. Immutable by default. Fail fast. Zero waste (allocations, threads, locks, casts).
Prefer language features over boilerplate. Sonar-clean on first write. Newest LTS feature wins.

---

## How to Use This Skill

**Always read the relevant reference file(s) before writing code.**
Reference files contain full API listings, every method variant, before/after comparisons, and rules.
Working examples live in `examples/` — each file has a SCENARIO GUIDE at the top explaining
when to use each feature shown, what it replaces, and when NOT to use it.

**When deciding between two approaches, read `references/decision-guide.md` first.**

| Task involves… | Read before coding |
|---|---|
| Any JDK 7 feature (NIO.2, try-with-resources, Fork/Join) | `references/jdk7.md` |
| Streams, Collectors, Optional, lambdas, java.time, CompletableFuture, Map methods | `references/jdk8.md` |
| `List.of`, `takeWhile`, `Stream.ofNullable`, VarHandle, StackWalker | `references/jdk9.md` |
| `var`, String methods, `Files.readString`, `Predicate.not`, HTTP Client | `references/jdk10-11.md` |
| Switch expressions, text blocks, records, sealed classes, pattern `instanceof` | `references/jdk12-17.md` |
| Virtual threads, StructuredTaskScope, ScopedValue, Sequenced Collections, pattern switch | `references/jdk21.md` |
| Stream Gatherers, unnamed `_`, primitive patterns, flexible constructors | `references/jdk22-25.md` |
| String building, null safety, exceptions, immutability, concurrency, collections, I/O | `references/idioms.md` |
| Any Spring Boot: controller, service, repo, config, DTO, events, exception handling | `references/springboot.md` |
| Choosing between competing patterns (stream vs loop, record vs class, Optional vs throw, virtual threads vs pool, which collection, which concurrency primitive, projection vs entity, etc.) | `references/decision-guide.md` |

For full working code read the matching `examples/` file alongside the reference.

---

## JDK Version Index
*(feature names only — full detail + code in reference files)*

**JDK 7** — Diamond `<>` · try-with-resources · multi-catch · String switch · binary literals + `_` separators · `Objects` utility · NIO.2 (`Path`, `Files`, `WatchService`) · Fork/Join · `ThreadLocalRandom` · `Phaser`

**JDK 8** — Lambdas + 4 method-ref forms · functional interfaces + primitive specialisations · Streams (full intermediate/terminal/factory) · Collectors (full) · Optional (full) · default/static interface methods · `java.time` · `CompletableFuture` (full chain API) · Map new methods · Comparator fluent API · `LongAdder`/`LongAccumulator` · `StampedLock` · Math overflow-checked · Base64 · `@FunctionalInterface`

**JDK 9** — `List/Set/Map.of` + `Map.ofEntries` · `Map.copyOf` · try-with-resources on existing vars · `Stream.ofNullable` · `takeWhile`/`dropWhile` · 3-arg `Stream.iterate` · `Optional.ifPresentOrElse`/`or`/`stream` · `Collectors.flatMapping`/`filtering` · private interface methods · `@Deprecated(forRemoval)` · `VarHandle` · `StackWalker` · reactive `Flow` API · multi-release JARs

**JDK 10** — `var` (do/don't rules) · `List/Set/Map.copyOf` · `Collectors.toUnmodifiableList/Set/Map` · `Optional.orElseThrow()` no-arg

**JDK 11 (LTS)** — `var` in lambda params · `isBlank`/`strip`/`stripLeading`/`stripTrailing`/`lines`/`repeat` · `Files.readString`/`writeString` · `Path.of` · `Predicate.not` · `toArray(IntFunction)` · HTTP Client (sync + async) · `InputStream.readAllBytes`/`readNBytes`/`transferTo` · null streams · `Pattern.asMatchPredicate`

**JDK 12–16** — Switch expressions (`->` arrow + `yield` block) · Text blocks (`"""`) with `\` and `\s` escapes · Records (compact constructor, normalization, interfaces, generics) · Pattern `instanceof` · `Stream.toList()` · `Stream.mapMulti` · `Collectors.teeing` · `String.indent`/`transform` · `Files.mismatch` · compact number format · helpful NPE · enhanced pseudo-random

**JDK 17 (LTS)** — Sealed classes/interfaces + exhaustive switch · `permits` · `non-sealed`

**JDK 21 (LTS)** — Virtual threads + ReentrantLock rule + carrier-pin rule · Sequenced Collections (`getFirst`/`getLast`/`reversed`) · Pattern switch with guards + null · Record patterns (nested) · Unnamed `_` patterns + variables · `ScopedValue` · `StructuredTaskScope.ShutdownOnFailure`/`ShutdownOnSuccess`

**JDK 22–25** — Unnamed variables `_` (final, JEP 456) · Stream Gatherers: `windowFixed`/`windowSliding`/`scan`/`fold`/`mapConcurrent` + custom · Flexible constructor bodies (pre-`super()` statements) · Module import declarations · Primitive types in patterns · Compact object headers (`-XX:+UseCompactObjectHeaders`) · Class-file API

---

## Sonar Rules — Always Apply

```
S1481  Remove unused local variables
S1854  Remove useless variable assignments
S2095  Close resources in try-with-resources
S2789  Don't check Optional for null (always non-null)
S3776  Cognitive complexity > 15 → refactor
S4973  Compare Strings with equals(), not ==
S6201  Use pattern matching instanceof (not cast after check)
S6204  Use Stream.toList() over collect(toUnmodifiableList())
S6206  Use record for pure data classes
S1905  Remove redundant casts
S4266  Use isEmpty() over size() == 0
S1192  Extract duplicate string literals to constants
S2153  No boxing immediately followed by unboxing
S3518  Divisor must not be zero (validate)
S1135  No committed TODO/FIXME (use issue tracker)
S2055  Write-only fields should be removed
S3016  Avoid field injection (@Autowired on field)
```

---

## Quick Decision Reference

| Need | Best choice |
|------|-------------|
| Immutable data object | `record` |
| Closed type hierarchy | `sealed interface` + `record` subtypes |
| Absent return value | `Optional<T>` |
| Multiline string | Text block `"""..."""` |
| Complex conditional value | Switch expression `->` |
| High-contention counter | `LongAdder` |
| Async fan-out, cancel on failure | `StructuredTaskScope.ShutdownOnFailure` |
| Thread-inherited context (virtual) | `ScopedValue` |
| Async pipeline / chain | `CompletableFuture` |
| I/O-bound parallelism | Virtual thread executor |
| Immutable literal collection | `List.of` / `Set.of` / `Map.of` |
| Defensive immutable copy | `List.copyOf` / `Map.copyOf` |
| Custom stream intermediate op | `Stream.gather(Gatherer)` JDK 24 |
| File read/write | `Files.readString` / `Files.writeString` |
| HTTP call (no Spring) | `HttpClient` JDK 11 |
| Lock-free field CAS | `VarHandle` |
| Read-heavy shared struct | `StampedLock` optimistic |
| Enum-keyed map | `EnumMap` |
| Spring config group | `@ConfigurationProperties` + `record` |
| Spring DTO | `record` + static factory |
| Null-safe navigation | `Optional.map().flatMap()` |
| Ignore exception variable | `catch (Exception _)` JDK 22 |
| Ignore record component | `case Foo(int x, _)` JDK 22 |
