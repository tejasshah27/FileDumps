# Cross-Cutting Idioms

## String Building
```java
// Multiline:        text block (JDK 15+)
// Single concat:    + operator (JIT inlines via invokedynamic since JDK 9)
// Loops:            StringBuilder with size hint
var sb = new StringBuilder(items.size() * 20);
for (var item : items) sb.append(item).append(',');
String result = sb.deleteCharAt(sb.length() - 1).toString();

// Streams:          Collectors.joining (most concise)
items.stream().collect(Collectors.joining(", ", "[", "]"));

// Formatting:       .formatted() or String.format for structured output
// NEVER:            += in a loop (creates new String each iteration)
```

## Null Safety
```java
// Chain optional navigation
return Optional.ofNullable(user)
    .map(User::getAddress)
    .map(Address::getCity)
    .orElse("unknown");

// Null-safe utility
Objects.requireNonNull(param, () -> "param null in " + caller());
Objects.requireNonNullElse(value, fallback);
Objects.toString(nullable, "");
```

## Exception Handling
```java
// Fail fast with context
if (items.isEmpty()) throw new IllegalArgumentException("items must not be empty for " + operationName);

// Custom hierarchy — sealed for exhaustive handling
sealed interface AppError permits NotFoundError, ValidationError, ConflictError {}
record NotFoundError(String entity, Object id) implements AppError {}

// Wrap checked exceptions for stream compatibility
@FunctionalInterface
interface ThrowingFunction<T, R> {
    R apply(T t) throws Exception;
    static <T, R> Function<T, R> wrap(ThrowingFunction<T, R> f) {
        return t -> { try { return f.apply(t); }
                      catch (RuntimeException e) { throw e; }
                      catch (Exception e) { throw new RuntimeException(e); } };
    }
}
list.stream().map(ThrowingFunction.wrap(this::process))

// Multi-catch for unrelated exceptions sharing same handling
catch (TimeoutException | ConnectException e) { throw new ServiceUnavailableException(e); }
```

## Immutability Patterns
```java
// Literals:       List.of / Set.of / Map.of
// Defensive copy: List.copyOf / Set.copyOf / Map.copyOf
// Data objects:   record (compiler-enforced)
// Complex builds: builder pattern returning record or final class

record Config(String host, int port, boolean tls) {
    static Builder builder() { return new Builder(); }
    static final class Builder {
        private String host = "localhost"; private int port = 8080; private boolean tls = false;
        public Builder host(String h) { this.host = h; return this; }
        public Builder port(int p)   { this.port = p; return this; }
        public Builder tls(boolean t){ this.tls = t; return this; }
        public Config build()        { return new Config(host, port, tls); }
    }
}
```

## Concurrency Guide
```java
// I/O-bound parallelism:    Virtual threads (JDK 21+)
// Async fan-out:            StructuredTaskScope (JDK 21+) or CompletableFuture.allOf
// Async chain:              CompletableFuture
// Scheduled tasks:          ScheduledExecutorService (not Timer — not thread-safe)
// Read-heavy shared state:  StampedLock optimistic read
// Write-heavy counter:      LongAdder / LongAccumulator
// Once-per-request context: ScopedValue (JDK 21+) over InheritableThreadLocal

// Virtual thread: use ReentrantLock, not synchronized
private final ReentrantLock lock = new ReentrantLock();
lock.lock();
try { /* critical section */ } finally { lock.unlock(); }
```

## Collections Choice
```java
// ArrayList             — default; index access O(1); iteration fast (cache-friendly)
// LinkedList            — only when frequent head/tail insertion/removal; slower iteration
// ArrayDeque            — stack/queue; prefer over Stack and LinkedList
// HashMap               — default map
// LinkedHashMap         — insertion-order iteration
// TreeMap               — sorted key iteration (NavigableMap)
// EnumMap               — enum keys: bit-vector backed, fastest possible map
// ConcurrentHashMap     — thread-safe reads; segment-locked writes (no global lock)
// CopyOnWriteArrayList  — read-heavy, write-rare thread-safe list

// Pre-size maps to avoid rehash: new HashMap<>(expectedSize * 2)
// EnumSet for enum-value flag sets (bit operations internally)
```

## I/O
```java
// Small files:  Files.readString / Files.readAllBytes
// Large files:  Files.lines (streaming, buffered)
// Binary:       InputStream.readAllBytes / readNBytes / transferTo
// Write:        Files.writeString / Files.write
// Always specify charset explicitly: UTF_8 (StandardCharsets.UTF_8)
```

## Performance Checklist
```
☐ Avoid autoboxing in hot paths — use primitive streams (IntStream/LongStream)
☐ Pre-size collections when size is known
☐ EnumMap/EnumSet for enum keys/values
☐ Static final Pattern.compile() — not per-call
☐ static final DateTimeFormatter — thread-safe
☐ StringBuilder with capacity hint in loops
☐ Prefer Stream.toList() over collect(toList()) — no extra allocation
☐ Prefer List.copyOf() over new ArrayList<>(list) for read-only defensive copy
☐ LongAdder over AtomicLong for high-contention increments
☐ VarHandle over Unsafe for lock-free field access
```
