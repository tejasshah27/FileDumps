package examples.jdk21;

import java.util.*;
import java.util.concurrent.*;
import java.util.concurrent.locks.ReentrantLock;
import java.util.concurrent.StructuredTaskScope;

/**
 * JDK 21 (LTS) — Virtual threads, Sequenced Collections, Pattern switch,
 *                 Record patterns, Unnamed patterns, ScopedValue,
 *                 Structured Concurrency
 */
public class Jdk21Features {

    // ═══════════════════════════════════════════════════════════════════════
    // Virtual Threads (JEP 444)
    // ═══════════════════════════════════════════════════════════════════════

    // BEFORE: Thread.ofPlatform() or new Thread() — OS thread, ~1MB stack
    // AFTER:  Virtual thread — cheap (~1KB), JVM-managed, millions possible

    // Named virtual thread
    void singleVirtualThread() {
        Thread vt = Thread.ofVirtual()
            .name("worker-", 0)               // auto-numbered: worker-0, worker-1...
            .start(() -> processRequest());
        // vt.join() to wait
    }

    // Per-task executor — ONE virtual thread per submitted task (never reuse/pool)
    void virtualThreadExecutor(List<Runnable> tasks) throws InterruptedException {
        try (var exec = Executors.newVirtualThreadPerTaskExecutor()) {
            tasks.forEach(exec::submit);
        } // ExecutorService.close() = shutdown + awaitTermination
    }

    // Spring Boot 3.2+: spring.threads.virtual.enabled=true handles this automatically
    // Tomcat, @Async, @Scheduled all switch to virtual threads

    // ── Rule: Replace synchronized → ReentrantLock ───────────────────────────
    // synchronized pins the carrier thread (defeats virtual thread benefit)
    // ReentrantLock does NOT pin — virtual thread unmounts instead

    // BAD (with virtual threads):
    // synchronized (this) { ... }

    // GOOD:
    private final ReentrantLock lock = new ReentrantLock();

    void safeUpdate(Map<String, String> cache, String key, String value) {
        lock.lock();
        try {
            cache.put(key, value);
        } finally {
            lock.unlock();          // always in finally
        }
    }

    // ── Rule: Replace ThreadLocal → ScopedValue ──────────────────────────────
    // (shown below in ScopedValue section)

    // ── CPU-bound vs I/O-bound ───────────────────────────────────────────────
    // Virtual threads ONLY help when threads block on I/O (DB, HTTP, file, sleep)
    // CPU-bound tight loops: use ForkJoinPool / parallel streams instead

    void processRequest() { /* stub */ }

    // ═══════════════════════════════════════════════════════════════════════
    // Sequenced Collections (JEP 431)
    // ═══════════════════════════════════════════════════════════════════════

    void sequencedCollections() {
        List<String> list = new ArrayList<>(List.of("a", "b", "c"));

        // BEFORE: list.get(0)              AFTER:
        String first = list.getFirst();

        // BEFORE: list.get(list.size()-1)  AFTER:
        String last  = list.getLast();

        // BEFORE: list.add(0, "z")         AFTER:
        list.addFirst("z");

        // BEFORE: list.add("z")            AFTER:
        list.addLast("z");

        // Reversed view (not a copy)
        List<String> rev = list.reversed();
        rev.forEach(System.out::println);   // iterates in reverse

        // LinkedHashMap — also SequencedMap
        var map = new LinkedHashMap<>(Map.of("a",1,"b",2,"c",3));
        Map.Entry<String,Integer> firstEntry = map.firstEntry();
        Map.Entry<String,Integer> lastEntry  = map.lastEntry();
        SequencedMap<String,Integer> reversed = map.reversed();

        // Deque — now implements SequencedCollection
        Deque<String> deque = new ArrayDeque<>();
        deque.addFirst("head"); deque.addLast("tail");
        String head = deque.getFirst();
        String tail = deque.getLast();
    }

    // ═══════════════════════════════════════════════════════════════════════
    // Pattern matching for switch (JEP 441)
    // ═══════════════════════════════════════════════════════════════════════

    sealed interface Shape permits Shape.Circle, Shape.Rectangle, Shape.Triangle {
        record Circle(double radius)             implements Shape {}
        record Rectangle(double width, double height) implements Shape {}
        record Triangle(double a, double b, double c) implements Shape {}
    }

    // Exhaustive on sealed — no default required
    double area(Shape shape) {
        return switch (shape) {
            case Shape.Circle(double r)                -> Math.PI * r * r;
            case Shape.Rectangle(double w, double h)   -> w * h;
            case Shape.Triangle(double a, double b, double c) -> {
                double s = (a + b + c) / 2;
                yield Math.sqrt(s * (s-a) * (s-b) * (s-c));
            }
        };
    }

    // Guarded patterns — when clause
    String classifyAge(Object obj) {
        return switch (obj) {
            case null                          -> "null";
            case Integer i when i < 0          -> "invalid age";
            case Integer i when i < 18         -> "minor";
            case Integer i when i < 65         -> "adult";
            case Integer i                     -> "senior";
            case String  s when s.isBlank()    -> "empty";
            case String  s                     -> "string: " + s;
            default                            -> "unknown: " + obj.getClass().getSimpleName();
        };
    }

    // ── Record patterns ──────────────────────────────────────────────────────
    record Point(int x, int y) {}
    record Line(Point start, Point end) {}

    // Destructure in instanceof
    String describePoint(Object obj) {
        if (obj instanceof Point(int x, int y)) {
            return "point at (%d, %d)".formatted(x, y);
        }
        return "not a point";
    }

    // Nested record pattern
    String describeLine(Object obj) {
        if (obj instanceof Line(Point(int x1, int y1), Point(int x2, int y2))) {
            return "line from (%d,%d) to (%d,%d)".formatted(x1, y1, x2, y2);
        }
        return "not a line";
    }

    // Record pattern in switch
    String renderShape(Shape shape) {
        return switch (shape) {
            case Shape.Circle(double r)    -> "○ r=%.2f".formatted(r);
            case Shape.Rectangle(double w, double h) -> "□ %.2fx%.2f".formatted(w, h);
            case Shape.Triangle(double a, double b, double c) ->
                "△ sides=%.2f,%.2f,%.2f".formatted(a, b, c);
        };
    }

    // ── Unnamed patterns and variables (JEP 443/456) ─────────────────────────

    void unnamedExamples(List<String> list, Object obj) {
        // Unnamed variable _ — intentionally unused
        for (var _ : list) {
            System.out.println("tick");   // iterating for side effect
        }

        // Unnamed catch variable — intentional swallow (still log in production!)
        try {
            riskyOperation();
        } catch (Exception _) {
            // intentionally ignored — known safe fallback
        }

        // Unnamed pattern component — don't need y
        if (obj instanceof Point(int x, _)) {
            System.out.println("x = " + x);
        }

        // Unnamed in switch
        String result = switch (obj) {
            case Point(int x, _) -> "x-coord: " + x;
            default              -> "other";
        };
    }

    void riskyOperation() throws Exception {}

    // ═══════════════════════════════════════════════════════════════════════
    // Scoped Values (JEP 446)
    // ═══════════════════════════════════════════════════════════════════════

    // BEFORE: ThreadLocal (mutable, leaks with virtual thread pools)
    // AFTER:  ScopedValue (immutable, bounded lifetime, inherited by child virtual threads)

    record RequestContext(String traceId, String userId, String role) {}

    static final ScopedValue<RequestContext> REQUEST_CTX = ScopedValue.newInstance();

    // Bind — value visible for duration of the Runnable's call tree
    void handleRequest(RequestContext ctx, Runnable handler) {
        ScopedValue.where(REQUEST_CTX, ctx).run(handler);
    }

    // With return value
    <T> T handleRequestWithResult(RequestContext ctx, Callable<T> handler) throws Exception {
        return ScopedValue.where(REQUEST_CTX, ctx).call(handler);
    }

    // Read anywhere in the call tree (no parameter drilling)
    void deepServiceMethod() {
        RequestContext ctx = REQUEST_CTX.get();    // always bound if called from handleRequest
        System.out.println("TraceId: " + ctx.traceId());
    }

    // Child virtual threads inherit the binding automatically
    void parallelWithContext(RequestContext ctx) {
        ScopedValue.where(REQUEST_CTX, ctx).run(() -> {
            try (var scope = new StructuredTaskScope.ShutdownOnFailure()) {
                scope.fork(() -> { deepServiceMethod(); return null; });  // ctx visible here
                scope.fork(() -> { deepServiceMethod(); return null; });  // and here
                scope.join();
            } catch (InterruptedException e) { Thread.currentThread().interrupt(); }
        });
    }

    // ═══════════════════════════════════════════════════════════════════════
    // Structured Concurrency (JEP 453)
    // ═══════════════════════════════════════════════════════════════════════

    // BEFORE: CompletableFuture.allOf(...) — error handling is complex, cancellation manual
    // AFTER:  StructuredTaskScope — fork/join with automatic cancellation

    record UserProfile(String userId, String name, List<String> orders, String tier) {}

    // ShutdownOnFailure — cancel all if any subtask throws
    UserProfile buildProfile(String userId) throws Exception {
        try (var scope = new StructuredTaskScope.ShutdownOnFailure()) {

            StructuredTaskScope.Subtask<String>       name   = scope.fork(() -> fetchName(userId));
            StructuredTaskScope.Subtask<List<String>> orders = scope.fork(() -> fetchOrders(userId));
            StructuredTaskScope.Subtask<String>       tier   = scope.fork(() -> fetchTier(userId));

            scope.join()             // wait for all to complete (or one to fail)
                 .throwIfFailed();   // re-throws first failure as ExecutionException

            // All succeeded — get results
            return new UserProfile(userId, name.get(), orders.get(), tier.get());
        }
        // scope.close() cancels any still-running subtasks
    }

    // ShutdownOnSuccess — return first successful result, cancel the rest
    String fastestService(String query) throws Exception {
        try (var scope = new StructuredTaskScope.ShutdownOnSuccess<String>()) {
            scope.fork(() -> serviceA(query));
            scope.fork(() -> serviceB(query));
            scope.fork(() -> serviceC(query));
            return scope.join().result();   // first to succeed wins; others cancelled
        }
    }

    // Comparison with CompletableFuture fan-out (JDK 8 style)
    // BEFORE:
    CompletableFuture<UserProfile> buildProfileAsync(String userId) {
        return CompletableFuture.supplyAsync(() -> fetchName(userId))
            .thenCombine(
                CompletableFuture.supplyAsync(() -> fetchOrders(userId)),
                (name, orders) -> new UserProfile(userId, name, orders, null))
            // ^ fetchTier not included, cancellation on failure is manual, error handling verbose
            ;
    }

    // stubs
    private String fetchName(String id)       throws Exception { return "Alice"; }
    private List<String> fetchOrders(String id) throws Exception { return List.of("O1","O2"); }
    private String fetchTier(String id)       throws Exception { return "GOLD"; }
    private String serviceA(String q)         throws Exception { Thread.sleep(100); return "A"; }
    private String serviceB(String q)         throws Exception { Thread.sleep(200); return "B"; }
    private String serviceC(String q)         throws Exception { Thread.sleep(300); return "C"; }
}
