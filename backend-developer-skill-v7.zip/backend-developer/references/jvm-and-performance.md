# JVM Configuration and Performance

## Key JVM flags for production

```bash
# Show which variable was null in NullPointerException messages (JDK 14+)
-XX:+ShowCodeDetailsInExceptionMessages

# Compact object headers: 12-16 bytes → 8 bytes (JDK 24 experimental, JEP 450)
-XX:+UseCompactObjectHeaders

# GC selection
-XX:+UseZGC          # Low-latency; sub-millisecond pauses; good for large heaps (JDK 15+)
-XX:+UseG1GC         # Balanced; default since JDK 9; good general-purpose choice
-XX:+UseShenandoahGC # Low-pause; concurrent compaction (JDK 12+, OpenJDK)

# Heap sizing — always set both; prevents JVM from under-allocating
-Xms512m -Xmx2g

# Virtual thread pinning detection (JDK 21+) — log when synchronized pins carrier
-Djdk.tracePinnedThreads=full   # or =short
# Also visible as JFR event: jdk.VirtualThreadPinned

# Enable JFR (Java Flight Recorder) — low overhead profiling
-XX:StartFlightRecording=duration=60s,filename=recording.jfr
```

---

## Static final — hot path constants

Every `static final` field is: computed once at class load, JIT-inlined at call sites, zero
allocation per call, shared across all threads safely.

```java
// Pattern — recompiles NFA/DFA automaton on every call without static final
// BAD
boolean isUuid(String s) { return s.matches("[0-9a-f-]{36}"); }       // new automaton each call

// GOOD — compile once
private static final Pattern UUID_RE = Pattern.compile(
    "[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}");
boolean isUuid(String s) { return UUID_RE.asMatchPredicate().test(s); }

// DateTimeFormatter — thread-safe; expensive to build; always static final
private static final DateTimeFormatter ISO_FMT = DateTimeFormatter.ISO_OFFSET_DATE_TIME;

// ObjectMapper (Jackson) — extremely expensive to instantiate (builds type cache)
// BAD: new ObjectMapper() per request
// GOOD: singleton Spring bean or static final
private static final ObjectMapper MAPPER = new ObjectMapper()
    .configure(DeserializationFeature.FAIL_ON_UNKNOWN_PROPERTIES, false);

// Logger — always static final; per-method lookup wastes time and loses class context
private static final Logger log = LoggerFactory.getLogger(MyClass.class);

// Random — seed init overhead; ThreadLocalRandom per thread; no locking
// BAD: new Random() per call
// GOOD:
int port = ThreadLocalRandom.current().nextInt(1024, 65536);
```

---

## Autoboxing — the silent GC killer

Every autobox creates a heap object. Cache for small values exists (-128 to 127 for `Integer`),
but outside that range every box is a new allocation.

```java
// BAD — one Long object per iteration; 1M iterations = 1M allocations → GC pressure
Long sum = 0L;
for (Long value : largeList) { sum += value; }  // unbox + add + rebox each iteration

// GOOD — primitives on stack; zero heap allocation
long sum = 0L;
for (long value : largeList) { sum += value; }

// GOOD — primitive stream avoids boxing entirely
long total = largeList.stream().mapToLong(Long::longValue).sum();

// In collections: primitives can't go into List<int>; use int[] or IntStream for hot paths
int[] counts = new int[100];
IntStream.range(0, data.length).forEach(i -> counts[classify(data[i])]++);
```

GC impact: boxed objects → Eden fills faster → more Minor GC → Stop-The-World pauses.
Under very high allocation rate: objects promoted to Old Gen → expensive Major GC.

---

## Stream vs for-loop — collection size matters

Stream infrastructure cost: `Spliterator` allocation, lambda capture objects, internal boxing
for primitive streams not using `IntStream`/`LongStream`.

```
< 10 elements  — plain for-each; stream overhead exceeds iteration cost
10–100 elements — stream acceptable; minimal overhead
100+ elements  — stream is fine; overhead negligible relative to work
10,000+ elements — parallelStream() MAY help for CPU-bound work only
```

```java
// Small collection (config lookup, enum values) — use for-each or direct access
List<String> roles = List.of("ADMIN","USER","GUEST");
for (String role : roles) { /* minimal overhead */ }

// Large collection — stream declarative pipeline pays off
employees.stream()
    .filter(Employee::isActive)
    .collect(Collectors.groupingBy(Employee::department));
```

---

## String building on hot paths

```java
// + operator in loop — each += allocates a new String; O(n²) heap growth
// BAD
String result = "";
for (String item : items) result += item + ",";  // N new String objects

// GOOD — StringBuilder linear; pre-size to avoid internal array resize
var sb = new StringBuilder(items.size() * 20);
for (var item : items) sb.append(item).append(',');

// String.format() / .formatted() — parses format string on every call; slow on hot path
// Use for: error messages, log messages (cold path)
// Avoid for: per-request string building in tight loops
```

---

## Collection sizing — avoid rehash

`HashMap` default initial capacity = 16; rehash threshold = 0.75 (75% full).
Each rehash: allocate new array 2×, rehash all entries — O(n) work.

```java
// Known size — allocate upfront; no rehash
int expected = 1000;
Map<String, User> map = new HashMap<>(expected * 2);   // capacity > expected / 0.75

// ArrayList — default capacity 10; grows 1.5× on overflow
List<String> lines = new ArrayList<>(estimatedLineCount);
```

---

## Memory leak patterns

**Static collection accumulating forever:**
```java
// BAD — entries never removed; JVM can't GC them (GC root)
private static final Map<String, byte[]> cache = new HashMap<>();
// FIX: bounded cache (LinkedHashMap + removeEldestEntry, or Caffeine/Guava)
```

**ThreadLocal not removed in thread pool:**
```java
// BAD — Tomcat reuses threads; ThreadLocal set per request, never removed
static ThreadLocal<RequestData> context = new ThreadLocal<>();
// Must always:
try { context.set(data); doWork(); }
finally { context.remove(); }   // ← critical; omit = slow memory leak
// BETTER: ScopedValue (JDK 21+) — bounded by design, can't leak
```

**Non-static inner class leaking outer:**
```java
// BAD — MyInner holds implicit reference to MyOuter; MyOuter never GC'd if inner escapes
class MyOuter {
    class MyInner { void doWork() { MyOuter.this.help(); } }
}
// FIX: static inner class if outer reference not needed
class MyOuter {
    static class MyInner { void doWork() { /* no outer ref */ } }
}
```

**Event listener never deregistered:**
```java
eventBus.register(listener);   // listener holds reference to outer object
// Fix: deregister in lifecycle method (@PreDestroy, bean destruction, scope end)
```

---

## Performance checklist
```
☐ static final Pattern — never compile per call
☐ static final DateTimeFormatter — thread-safe, expensive to build
☐ static final ObjectMapper — singleton; very expensive to instantiate
☐ static final Logger — per-class; never per-method
☐ Primitives over wrappers in loops and hot paths
☐ IntStream/LongStream over Stream<Integer>/Stream<Long>
☐ StringBuilder with capacity hint in loops
☐ Pre-size HashMap/ArrayList when size is known
☐ EnumMap for enum keys; EnumSet for enum value sets
☐ LongAdder over AtomicLong for high-write counters
☐ Stream only when collection is meaningful size (> ~10 elements)
☐ Parameterised logging — never string concat in log call
☐ ThreadLocal.remove() in finally — always; or use ScopedValue
☐ try-with-resources for Files.walk/lines/list — always
☐ -XX:+ShowCodeDetailsInExceptionMessages in production
```

---

See also: `examples/jdk7/Jdk7Features.java`, `examples/jdk8/Jdk8Features.java`, `examples/jdk21/Jdk21Features.java`
