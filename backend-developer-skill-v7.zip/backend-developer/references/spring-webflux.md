# Spring WebFlux — Reactive Programming

Read this file for any reactive/WebFlux task. Covers: Mono/Flux operators, WebClient,
R2DBC, router functions, error handling, testing, security, and production gotchas.

For imperative (Spring MVC) patterns, read `references/spring-web.md` and `references/spring-data.md`.

Cross-reference: `concurrency.md` · `optional-and-errors.md` · `spring-web.md`

---

## Table of Contents

1. [MVC vs WebFlux — when to choose which](#mvc-vs-webflux--when-to-choose-which)
2. [Mono and Flux — the two core types](#mono-and-flux--the-two-core-types)
3. [Key operators](#key-operators)
4. [Error handling in reactive pipelines](#error-handling-in-reactive-pipelines)
5. [@RestController reactive style](#restcontroller-reactive-style)
6. [Router functions (functional endpoint style)](#router-functions-functional-endpoint-style)
7. [WebClient — reactive HTTP client](#webclient--reactive-http-client)
8. [R2DBC — reactive database access](#r2dbc--reactive-database-access)
9. [Reactive Context (replacing ThreadLocal)](#reactive-context--replacing-threadlocal)
10. [WebFilter](#webfilter)
11. [Backpressure](#backpressure)
12. [Testing — StepVerifier and WebTestClient](#testing--stepverifier-and-webtestclient)
13. [Security — SecurityWebFilterChain](#security--securitywebfilterchain)
14. [Production gotchas](#production-gotchas)
15. [WebFlux design decisions](#webflux-design-decisions)

---

## MVC vs WebFlux — when to choose which

This is an architectural decision that should be made **once per service**, not per endpoint.
Do not mix MVC and WebFlux in the same application — choose one model and be consistent.

**Choose Spring MVC (imperative) when:**
- Team is primarily experienced with blocking Java — MVC is easier to reason about, debug, and test
- You use Spring Data JPA (Hibernate) — JPA is inherently blocking; using it with WebFlux requires workarounds
- Latency per request matters more than raw throughput — JDK 21 virtual threads close the throughput gap
- Stack traces matter — imperative code produces readable stack traces; reactive pipelines produce long, operator-filled traces
- Service is mostly CPU-bound or does minimal concurrent I/O

**Choose Spring WebFlux (reactive) when:**
- Streaming responses: Server-Sent Events (SSE), chunked file streaming, real-time feeds
- Extremely high concurrency with limited threads: WebSocket servers, chat, real-time dashboards
- Downstream calls are all reactive (R2DBC, reactive Redis, reactive MongoDB, WebClient)
- Your team is already proficient with reactive programming or using Kotlin coroutines
- True backpressure control is required (consumer controls the rate of data from producer)

**Rule:** If you are on JDK 21+ with Spring Boot 3.2+ and `spring.threads.virtual.enabled=true`, Spring MVC with virtual threads handles the same I/O-bound concurrency that drove many teams to WebFlux. Prefer MVC unless you specifically need streaming, WebSockets, or a fully reactive stack.

---

## Mono and Flux — the two core types

```
Mono<T>   — 0 or 1 element; analogous to Optional + CompletableFuture combined
Flux<T>   — 0 to N elements; analogous to a stream that can be lazy and backpressure-aware
```

**Nothing executes until you subscribe.** Mono and Flux are declarative pipelines — calling `.map()` or `.filter()` does not run any code. Execution starts when a subscriber attaches (the framework does this for you when you return Mono/Flux from a controller method).

```java
// Mono factories
Mono.just(value)                        // single eager value
Mono.justOrEmpty(nullableValue)         // 0 or 1 — handles null without NPE
Mono.empty()                            // completes immediately with no value
Mono.error(new RuntimeException())      // terminal error signal
Mono.fromCallable(() -> blockingCall()) // wrap a blocking call — subscribe on a thread pool!
Mono.fromSupplier(this::compute)        // lazy evaluation
Mono.defer(() -> Mono.just(compute()))  // re-evaluates on each subscription

// Flux factories
Flux.just(a, b, c)                      // fixed elements
Flux.fromIterable(list)                 // from any Iterable
Flux.fromStream(stream)                 // from Java Stream (consumed once)
Flux.range(1, 10)                       // 1 to 10 inclusive
Flux.interval(Duration.ofSeconds(1))    // infinite; one element per second
Flux.empty()
Flux.error(ex)
```

---

## Key operators

```java
// TRANSFORM
Mono<String> name   = mono.map(User::name);             // synchronous transform
Mono<Order>  order  = mono.flatMap(u -> repo.findOrder(u.id()));  // async transform (returns Mono)
Flux<Item>   items  = flux.flatMap(o -> repo.findItems(o.id())); // each element → Flux, merged

// TRANSFORM with order preserved (flatMapSequential) or concurrency limited (flatMap(fn, N))
flux.flatMapSequential(o -> fetchAsync(o));              // preserves order, still concurrent
flux.flatMap(o -> fetchAsync(o), 4);                     // max 4 concurrent subscriptions

// FILTER
Flux<User> active   = flux.filter(User::isActive);
Mono<User> first    = flux.next();                       // first element as Mono
Mono<User> any      = flux.filter(User::isActive).next();

// COMBINE
Mono<Profile> both  = Mono.zip(fetchUser(id), fetchOrders(id))
                          .map(t -> new Profile(t.getT1(), t.getT2()));

Flux<Result> merged = Flux.merge(fluxA, fluxB);         // merge, no order guarantee
Flux<Result> concat = Flux.concat(fluxA, fluxB);        // concat, sequential

// COLLECT
Mono<List<User>> list = flux.collectList();
Mono<Map<UUID,User>> map = flux.collectMap(User::id);

// SIDE EFFECTS (don't mutate — use for logging, metrics only)
flux.doOnNext(u -> log.debug("Processing user {}", u.id()))
    .doOnError(ex -> log.error("Pipeline error", ex))
    .doOnComplete(() -> log.info("All users processed"))
    .doFinally(signal -> metrics.record(signal));

// DEFAULT AND FALLBACK
Mono<User> withDefault = mono.defaultIfEmpty(User.anonymous());
Mono<User> withFallback = mono.switchIfEmpty(Mono.fromCallable(this::findFromCache));

// TIMEOUT AND RETRY
mono.timeout(Duration.ofSeconds(5))
    .retry(3)                                           // retry on any error
    .retryWhen(Retry.backoff(3, Duration.ofMillis(100)) // exponential backoff
                    .filter(ex -> ex instanceof TransientException));

// WINDOWING (like Gatherers for reactive streams)
flux.buffer(10)                                        // emit List<T> of 10 elements
flux.buffer(Duration.ofSeconds(1))                     // emit batch per second
flux.window(5)                                         // emit Flux<T> windows of 5
```

---

## Error handling in reactive pipelines

Never use try/catch in reactive pipelines — it breaks the operator chain. Use reactive error operators.

```java
// onErrorReturn — replace error with a fallback value
Mono<Order> order = repo.findById(id)
    .onErrorReturn(DatabaseException.class, Order.unknown());

// onErrorResume — replace error with a fallback Mono/Flux
Mono<User> user = primaryRepo.findById(id)
    .onErrorResume(ex -> {
        log.warn("Primary failed, trying fallback", ex);
        return fallbackRepo.findById(id);
    });

// onErrorMap — translate error type (e.g. infrastructure → domain)
Mono<Order> order2 = repo.findById(id)
    .onErrorMap(DatabaseException.class, ex -> new ServiceException("DB unavailable", ex));

// doOnError — side effect only (log, metrics); does NOT recover
flux.doOnError(ex -> metrics.counter("errors").increment());

// Global error handling via @RestControllerAdvice (works for WebFlux too)
@RestControllerAdvice
public class GlobalExceptionHandler {

    @ExceptionHandler(NotFoundException.class)
    Mono<ResponseEntity<ProblemDetail>> handleNotFound(NotFoundException ex) {
        var pd = ProblemDetail.forStatusAndDetail(HttpStatus.NOT_FOUND, ex.getMessage());
        return Mono.just(ResponseEntity.status(HttpStatus.NOT_FOUND).body(pd));
    }

    @ExceptionHandler(ValidationException.class)
    Mono<ResponseEntity<ProblemDetail>> handleValidation(ValidationException ex) {
        var pd = ProblemDetail.forStatusAndDetail(HttpStatus.BAD_REQUEST, ex.getMessage());
        return Mono.just(ResponseEntity.badRequest().body(pd));
    }
}
```

---

## @RestController reactive style

Return `Mono<T>` or `Flux<T>` from controller methods — the framework subscribes and streams the response.

```java
@RestController
@RequestMapping("/api/v1/orders")
@Validated
public class OrderController {

    private final OrderService service;

    OrderController(OrderService service) { this.service = service; }

    @PostMapping
    @ResponseStatus(HttpStatus.CREATED)
    Mono<OrderResponse> create(@RequestBody @Valid Mono<CreateOrderRequest> req) {
        return req.flatMap(service::create);
    }

    @GetMapping("/{id}")
    Mono<OrderResponse> getById(@PathVariable UUID id) {
        return service.findById(id)
            .switchIfEmpty(Mono.error(new NotFoundException("Order not found: " + id)));
    }

    @GetMapping
    Flux<OrderResponse> listByCustomer(@RequestParam String customerId) {
        return service.streamByCustomer(customerId);
    }

    // Server-Sent Events — streams live updates to the client
    @GetMapping(value = "/stream", produces = MediaType.TEXT_EVENT_STREAM_VALUE)
    Flux<OrderEvent> stream() {
        return eventPublisher.orderEvents()
            .doOnCancel(() -> log.info("Client disconnected from event stream"));
    }

    // File/binary streaming — returns Flux<DataBuffer> for large payloads
    @GetMapping(value = "/{id}/invoice", produces = MediaType.APPLICATION_PDF_VALUE)
    Mono<ResponseEntity<Flux<DataBuffer>>> downloadInvoice(@PathVariable UUID id) {
        return service.getInvoiceResource(id)
            .map(resource -> ResponseEntity.ok()
                .contentType(APPLICATION_PDF)
                .body(DataBufferUtils.read(resource, new DefaultDataBufferFactory(), 4096)));
    }
}
```

---

## Router functions (functional endpoint style)

Alternative to `@RestController`. Better for: highly dynamic routing, programmatic route composition, or when you want to keep routing and handler logic fully separate.

```java
// Handler — business logic, no routing annotations
@Component
public class OrderHandler {

    private final OrderService service;

    OrderHandler(OrderService service) { this.service = service; }

    public Mono<ServerResponse> create(ServerRequest req) {
        return req.bodyToMono(CreateOrderRequest.class)
            .flatMap(service::create)
            .flatMap(order -> ServerResponse.created(URI.create("/api/v1/orders/" + order.id()))
                                            .bodyValue(order));
    }

    public Mono<ServerResponse> getById(ServerRequest req) {
        var id = UUID.fromString(req.pathVariable("id"));
        return service.findById(id)
            .flatMap(o -> ServerResponse.ok().bodyValue(o))
            .switchIfEmpty(ServerResponse.notFound().build());
    }

    public Mono<ServerResponse> list(ServerRequest req) {
        var customerId = req.queryParam("customerId").orElseThrow();
        return ServerResponse.ok()
            .contentType(APPLICATION_JSON)
            .body(service.streamByCustomer(customerId), OrderResponse.class);
    }
}

// Router — declarative route registration
@Configuration
public class OrderRouter {

    @Bean
    RouterFunction<ServerResponse> orderRoutes(OrderHandler handler) {
        return RouterFunctions.route()
            .POST("/api/v1/orders",           handler::create)
            .GET("/api/v1/orders/{id}",        handler::getById)
            .GET("/api/v1/orders",             handler::list)
            .filter((req, next) -> {           // inline WebFilter for this route group
                log.debug("Order API: {} {}", req.method(), req.uri());
                return next.handle(req);
            })
            .build();
    }
}
```

**@RestController vs Router functions:**
- `@RestController` — familiar, less boilerplate for standard REST; annotation processing at startup
- Router functions — explicit, composable, no annotation scanning; better for complex route nesting or programmatic route registration; more testable in isolation

---

## WebClient — reactive HTTP client

`WebClient` is the reactive replacement for `RestTemplate`. Always declare it as a `static final` bean or `@Bean` — never instantiate per request.

```java
@Configuration
public class WebClientConfig {

    @Bean
    WebClient paymentClient(@Value("${app.payment.base-url}") String baseUrl) {
        return WebClient.builder()
            .baseUrl(baseUrl)
            .defaultHeader(HttpHeaders.CONTENT_TYPE, MediaType.APPLICATION_JSON_VALUE)
            .defaultHeader(HttpHeaders.ACCEPT, MediaType.APPLICATION_JSON_VALUE)
            .codecs(c -> c.defaultCodecs().maxInMemorySize(2 * 1024 * 1024))  // 2MB response buffer
            .filter(ExchangeFilterFunctions.basicAuthentication("user", "secret"))
            .filter(logRequest())
            .build();
    }

    private ExchangeFilterFunction logRequest() {
        return ExchangeFilterFunction.ofRequestProcessor(req -> {
            log.debug("WebClient → {} {}", req.method(), req.url());
            return Mono.just(req);
        });
    }
}

@Service
public class PaymentGatewayClient {

    private final WebClient client;

    PaymentGatewayClient(WebClient paymentClient) { this.client = paymentClient; }

    // POST with request body
    public Mono<PaymentResult> charge(PaymentRequest req) {
        return client.post()
            .uri("/charges")
            .bodyValue(req)
            .retrieve()
            .onStatus(HttpStatusCode::is4xxClientError,
                      res -> res.bodyToMono(String.class)
                                .map(body -> new PaymentDeclinedException("Declined: " + body)))
            .onStatus(HttpStatusCode::is5xxServerError,
                      res -> Mono.error(new GatewayUnavailableException("Gateway error")))
            .bodyToMono(PaymentResult.class)
            .timeout(Duration.ofSeconds(10))
            .retryWhen(Retry.backoff(2, Duration.ofMillis(200))
                            .filter(ex -> ex instanceof GatewayUnavailableException));
    }

    // GET with query params
    public Mono<PaymentStatus> getStatus(String transactionId) {
        return client.get()
            .uri(b -> b.path("/status/{id}").build(transactionId))
            .retrieve()
            .bodyToMono(PaymentStatus.class);
    }

    // Streaming response
    public Flux<TransactionEvent> streamEvents(String customerId) {
        return client.get()
            .uri("/events?customerId={id}", customerId)
            .accept(MediaType.TEXT_EVENT_STREAM)
            .retrieve()
            .bodyToFlux(TransactionEvent.class);
    }

    // Parallel fan-out — call N endpoints simultaneously
    public Mono<List<PaymentMethod>> getPaymentMethods(List<String> methodIds) {
        return Flux.fromIterable(methodIds)
            .flatMap(id -> client.get().uri("/methods/{id}", id)
                                 .retrieve().bodyToMono(PaymentMethod.class), 4)  // max 4 concurrent
            .collectList();
    }
}
```

---

## R2DBC — reactive database access

R2DBC provides non-blocking database access. Use with Spring Data R2DBC for repository support.
Choose R2DBC when building a fully reactive stack (WebFlux + R2DBC). Do not mix JPA + WebFlux.

```xml
<dependency>
    <groupId>org.springframework.boot</groupId>
    <artifactId>spring-boot-starter-data-r2dbc</artifactId>
</dependency>
<dependency>
    <groupId>org.postgresql</groupId>
    <artifactId>r2dbc-postgresql</artifactId>
</dependency>
```

```properties
spring.r2dbc.url=r2dbc:postgresql://localhost:5432/mydb
spring.r2dbc.username=user
spring.r2dbc.password=secret
```

```java
// Entity — simpler than JPA; no proxies, no lazy loading
@Table("orders")
public class Order {
    @Id private UUID id;
    private String customerId;
    private String status;
    private long amountCents;
    private Instant createdAt;
    // No-arg constructor required; getters and setters
}

// Repository — extends ReactiveCrudRepository
public interface OrderRepository extends ReactiveCrudRepository<Order, UUID> {

    Flux<Order> findByCustomerId(String customerId);

    @Query("SELECT * FROM orders WHERE customer_id = :customerId AND status = :status")
    Flux<Order> findByCustomerIdAndStatus(String customerId, String status);

    Mono<Boolean> existsByCustomerIdAndStatus(String customerId, String status);
}

// Service — fully reactive pipeline
@Service
public class OrderService {

    private final OrderRepository repo;
    private final ApplicationEventPublisher events;

    @Transactional   // R2DBC supports reactive @Transactional via R2dbcTransactionManager
    public Mono<OrderResponse> create(CreateOrderRequest req) {
        var order = new Order();
        order.setCustomerId(req.customerId());
        order.setAmountCents(req.amountCents());
        order.setStatus("PENDING");
        order.setCreatedAt(Instant.now());

        return repo.save(order)
            .doOnSuccess(saved -> events.publishEvent(new OrderCreatedEvent(saved.getId(), saved.getCustomerId())))
            .map(OrderResponse::from);
    }

    public Mono<OrderResponse> findById(UUID id) {
        return repo.findById(id)
            .map(OrderResponse::from)
            .switchIfEmpty(Mono.error(new NotFoundException("Order not found: " + id)));
    }

    public Flux<OrderResponse> streamByCustomer(String customerId) {
        return repo.findByCustomerId(customerId)
            .map(OrderResponse::from);
    }
}
```

**R2DBC vs JPA:**
| | JPA / Hibernate | R2DBC |
|---|---|---|
| Threading model | Blocking; works with virtual threads | Non-blocking; designed for reactive |
| Features | Full ORM, lazy loading, caching, criteria | Basic CRUD + custom @Query; no lazy loading |
| Maturity | Mature, rich ecosystem | Younger; fewer third-party integrations |
| Choose when | Spring MVC stack; complex domain model | WebFlux stack; high-concurrency I/O |

---

## Reactive Context (replacing ThreadLocal)

In reactive pipelines, a single request can cross multiple threads. `ThreadLocal` is unreliable.
Use Reactor's `Context` — the reactive equivalent of request-scoped storage.

```java
// Write to context in a WebFilter
public class CorrelationIdFilter implements WebFilter {

    private static final String CORRELATION_KEY = "correlationId";

    @Override
    public Mono<Void> filter(ServerWebExchange exchange, WebFilterChain chain) {
        var id = Optional.ofNullable(exchange.getRequest().getHeaders().getFirst("X-Correlation-Id"))
                         .orElseGet(() -> UUID.randomUUID().toString());
        exchange.getResponse().getHeaders().set("X-Correlation-Id", id);

        return chain.filter(exchange)
            .contextWrite(Context.of(CORRELATION_KEY, id));   // attach to reactive context
    }
}

// Read from context anywhere in the pipeline
public Mono<OrderResponse> create(CreateOrderRequest req) {
    return Mono.deferContextual(ctx -> {
        var correlationId = ctx.<String>getOrDefault("correlationId", "unset");
        log.info("Creating order, correlationId={}", correlationId);
        return doCreate(req);
    });
}
```

**Bridge context to MDC for Logback:**
```java
// Reactor hook — propagates Reactor Context into MDC for logging frameworks
Hooks.enableAutomaticContextPropagation();  // call once at startup (Spring Boot 3.x configures this)
// Requires: io.micrometer:context-propagation on the classpath
```

---

## WebFilter

The reactive equivalent of a Servlet `Filter`. Applies to all routes unless narrowed.

```java
@Component
@Order(-1)   // negative = higher priority
public class SecurityHeadersFilter implements WebFilter {

    @Override
    public Mono<Void> filter(ServerWebExchange exchange, WebFilterChain chain) {
        exchange.getResponse().getHeaders()
            .add("X-Content-Type-Options", "nosniff");
        exchange.getResponse().getHeaders()
            .add("X-Frame-Options", "DENY");
        return chain.filter(exchange);
    }
}
```

---

## Backpressure

Backpressure lets the consumer tell the producer how much data it can handle. It prevents a fast producer from overwhelming a slow consumer.

```java
// Flux from a DB cursor — producer is fast; consumer (HTTP) is slow
Flux<Order> orders = repo.findAll();  // R2DBC Flux with backpressure

// limitRate — request N elements at a time from upstream; replenish when consumed
orders.limitRate(100)   // fetch 100, once 75% consumed (default low tide) fetch next 100
      .map(OrderResponse::from)
      .subscribe();

// onBackpressureBuffer — buffer if subscriber is slower than publisher
eventPublisher.orderEvents()
    .onBackpressureBuffer(1000,
        dropped -> log.warn("Event buffer overflow, dropped: {}", dropped),
        BufferOverflowStrategy.DROP_OLDEST);

// onBackpressureDrop — drop elements the subscriber can't keep up with
flux.onBackpressureDrop(dropped -> log.warn("Dropped: {}", dropped));

// onBackpressureLatest — keep only the latest element when consumer is slow
flux.onBackpressureLatest();
```

**When backpressure matters:**
- SSE or WebSocket streams where the client controls consumption speed
- File or database export streams where the writer is slower than the reader
- Message consumer pipelines where the downstream processor has limited capacity

---

## Testing — StepVerifier and WebTestClient

### StepVerifier (unit/integration testing of reactive pipelines)

```java
@ExtendWith(MockitoExtension.class)
class OrderServiceTest {

    @Mock OrderRepository repo;
    @InjectMocks OrderService service;

    @Test
    void findById_found_emitsOrderResponse() {
        var order = new Order(UUID.randomUUID(), "cust-1", "PENDING", 5000L, Instant.now());
        when(repo.findById(order.getId())).thenReturn(Mono.just(order));

        StepVerifier.create(service.findById(order.getId()))
            .assertNext(res -> {
                assertThat(res.id()).isEqualTo(order.getId());
                assertThat(res.status()).isEqualTo("PENDING");
            })
            .verifyComplete();    // assert no error, then completes
    }

    @Test
    void findById_notFound_emitsNotFoundException() {
        when(repo.findById(any())).thenReturn(Mono.empty());

        StepVerifier.create(service.findById(UUID.randomUUID()))
            .verifyError(NotFoundException.class);
    }

    @Test
    void streamByCustomer_emitsAllOrders() {
        var orders = List.of(
            new Order(UUID.randomUUID(), "cust-1", "PENDING", 1000L, Instant.now()),
            new Order(UUID.randomUUID(), "cust-1", "CONFIRMED", 2000L, Instant.now())
        );
        when(repo.findByCustomerId("cust-1")).thenReturn(Flux.fromIterable(orders));

        StepVerifier.create(service.streamByCustomer("cust-1"))
            .expectNextCount(2)
            .verifyComplete();
    }

    @Test
    void create_timesOut_propagatesError() {
        when(repo.save(any())).thenReturn(Mono.never());  // simulate hung DB

        StepVerifier.withVirtualTime(() -> service.create(new CreateOrderRequest("cust-1", 1000L, "USD")))
            .thenAwait(Duration.ofSeconds(11))           // advance virtual clock
            .verifyError(TimeoutException.class);
    }
}
```

### WebTestClient (HTTP-level integration testing)

```java
@SpringBootTest(webEnvironment = SpringBootTest.WebEnvironment.RANDOM_PORT)
class OrderControllerTest {

    @Autowired WebTestClient client;   // auto-configured by @SpringBootTest

    @Test
    void create_validRequest_returns201() {
        client.post().uri("/api/v1/orders")
            .contentType(MediaType.APPLICATION_JSON)
            .bodyValue(new CreateOrderRequest("cust-1", 5000L, "USD"))
            .exchange()
            .expectStatus().isCreated()
            .expectBody(OrderResponse.class)
            .value(res -> assertThat(res.status()).isEqualTo("PENDING"));
    }

    @Test
    void getById_notFound_returns404() {
        client.get().uri("/api/v1/orders/{id}", UUID.randomUUID())
            .exchange()
            .expectStatus().isNotFound()
            .expectBody()
            .jsonPath("$.status").isEqualTo(404);
    }

    @Test
    void stream_receivesEvents() {
        client.get().uri("/api/v1/orders/stream")
            .accept(MediaType.TEXT_EVENT_STREAM)
            .exchange()
            .expectStatus().isOk()
            .returnResult(OrderEvent.class)
            .getResponseBody()
            .take(3)   // consume only 3 events then cancel
            .as(StepVerifier::create)
            .expectNextCount(3)
            .thenCancel()
            .verify(Duration.ofSeconds(5));
    }
}

// @WebFluxTest — slice test (web layer only, mock services)
@WebFluxTest(OrderController.class)
class OrderControllerSliceTest {

    @Autowired WebTestClient client;
    @MockBean  OrderService   service;

    @Test
    void create_blankCustomerId_returns400() {
        client.post().uri("/api/v1/orders")
            .contentType(MediaType.APPLICATION_JSON)
            .bodyValue(Map.of("customerId", "", "amountCents", 100, "currencyCode", "USD"))
            .exchange()
            .expectStatus().isBadRequest();

        verify(service, never()).create(any());
    }
}
```

---

## Security — SecurityWebFilterChain

```java
@Configuration
@EnableWebFluxSecurity
@EnableReactiveMethodSecurity   // enables @PreAuthorize on reactive methods
public class SecurityConfig {

    @Bean
    SecurityWebFilterChain securityFilterChain(ServerHttpSecurity http) {
        return http
            .csrf(ServerHttpSecurity.CsrfSpec::disable)   // stateless API — no CSRF needed
            .authorizeExchange(ex -> ex
                .pathMatchers("/actuator/health/**", "/actuator/info").permitAll()
                .pathMatchers(HttpMethod.POST, "/api/v1/orders").hasRole("USER")
                .pathMatchers("/api/v1/admin/**").hasRole("ADMIN")
                .anyExchange().authenticated()
            )
            .oauth2ResourceServer(o -> o.jwt(Customizer.withDefaults()))
            .build();
    }
}

// Method-level security on reactive service methods
@Service
public class OrderService {

    @PreAuthorize("hasRole('ADMIN') or #customerId == authentication.name")
    public Flux<OrderResponse> streamByCustomer(String customerId) { ... }
}
```

---

## Production gotchas

**1. Blocking inside a reactive pipeline — the worst mistake**
```java
// BAD — blocks the event loop thread; starves all other reactive tasks
Mono<Order> bad = Mono.fromCallable(() -> blockingRepo.findById(id));  // blocks!

// GOOD — offload blocking work to a bounded elastic thread pool
Mono<Order> good = Mono.fromCallable(() -> blockingRepo.findById(id))
    .subscribeOn(Schedulers.boundedElastic());  // runs on a separate, expandable pool
```

**2. Forgetting to subscribe (cold publishers)**
Returning a `Mono` from a service is not enough — if nothing subscribes, nothing executes. A controller returning `Mono<Void>` from a `void` service method returns a completed empty signal unless the service method itself returns `Mono<Void>`.

**3. Context not propagating across async boundaries**
If you use `CompletableFuture` or `new Thread()` inside a reactive pipeline, the Reactor `Context` does not automatically propagate. Use `Mono.fromFuture(cf)` or `Schedulers.boundedElastic()` and pass context explicitly.

**4. Collecting the entire Flux into a List for large datasets**
```java
// BAD for large result sets — loads all rows into heap
Mono<List<Order>> all = repo.findAll().collectList();

// GOOD — stream row by row; backpressure prevents heap overflow
Flux<OrderResponse> streamed = repo.findAll().map(OrderResponse::from);
```

**5. Using `block()` in a WebFlux application**
`block()` is prohibited on Netty's event loop threads. It causes a `BlockingOperationError`. Never call `.block()` from within a reactive pipeline or a controller method. Use it only in tests or in main/startup code running on a separate thread.

**6. Missing `@EnableTransactionManagement` for R2DBC transactions**
R2DBC `@Transactional` requires `@EnableTransactionManagement` and a `ReactiveTransactionManager` bean. Spring Boot auto-configures `R2dbcTransactionManager` when `spring-boot-starter-data-r2dbc` is on the classpath — but verify it is active if transactions seem not to work.

---

## WebFlux design decisions

| Choosing between… | Decision |
|---|---|
| `@RestController` vs Router functions | Use `@RestController` for standard REST; Router functions for programmatic/dynamic routing or complex nested route groups |
| `flatMap` vs `flatMapSequential` | `flatMap` when order doesn't matter (faster); `flatMapSequential` when order must be preserved |
| `Mono.zip` vs sequential `flatMap` | `Mono.zip` for truly independent parallel calls; sequential `flatMap` only when each step depends on the previous result |
| `onErrorResume` vs `onErrorReturn` | `onErrorReturn` for simple fallback values; `onErrorResume` for fallback reactive pipelines (e.g., try cache on DB failure) |
| `buffer(N)` vs `window(N)` | `buffer(N)` emits `List<T>` batches (simpler); `window(N)` emits `Flux<T>` sub-streams (composable, lazy) |
| R2DBC vs JPA | R2DBC for fully reactive WebFlux stack; JPA for Spring MVC or when domain model complexity is high |
| Reactor `Context` vs MDC | Always use `Context` in WebFlux; bridge to MDC only for logging via `Hooks.enableAutomaticContextPropagation()` |

See also: `examples/springboot/WebFluxStack.java`
